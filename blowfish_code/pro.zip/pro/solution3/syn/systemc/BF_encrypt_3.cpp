#include "BF_encrypt.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void BF_encrypt::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[0];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[1];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage10() {
    ap_CS_fsm_pp0_stage10 = ap_CS_fsm.read()[10];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage11() {
    ap_CS_fsm_pp0_stage11 = ap_CS_fsm.read()[11];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage12() {
    ap_CS_fsm_pp0_stage12 = ap_CS_fsm.read()[12];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage13() {
    ap_CS_fsm_pp0_stage13 = ap_CS_fsm.read()[13];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage14() {
    ap_CS_fsm_pp0_stage14 = ap_CS_fsm.read()[14];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage15() {
    ap_CS_fsm_pp0_stage15 = ap_CS_fsm.read()[15];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage16() {
    ap_CS_fsm_pp0_stage16 = ap_CS_fsm.read()[16];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage17() {
    ap_CS_fsm_pp0_stage17 = ap_CS_fsm.read()[17];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage18() {
    ap_CS_fsm_pp0_stage18 = ap_CS_fsm.read()[18];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage19() {
    ap_CS_fsm_pp0_stage19 = ap_CS_fsm.read()[19];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage2() {
    ap_CS_fsm_pp0_stage2 = ap_CS_fsm.read()[2];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage20() {
    ap_CS_fsm_pp0_stage20 = ap_CS_fsm.read()[20];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage21() {
    ap_CS_fsm_pp0_stage21 = ap_CS_fsm.read()[21];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage22() {
    ap_CS_fsm_pp0_stage22 = ap_CS_fsm.read()[22];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage23() {
    ap_CS_fsm_pp0_stage23 = ap_CS_fsm.read()[23];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage24() {
    ap_CS_fsm_pp0_stage24 = ap_CS_fsm.read()[24];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage25() {
    ap_CS_fsm_pp0_stage25 = ap_CS_fsm.read()[25];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage26() {
    ap_CS_fsm_pp0_stage26 = ap_CS_fsm.read()[26];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage27() {
    ap_CS_fsm_pp0_stage27 = ap_CS_fsm.read()[27];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage28() {
    ap_CS_fsm_pp0_stage28 = ap_CS_fsm.read()[28];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage29() {
    ap_CS_fsm_pp0_stage29 = ap_CS_fsm.read()[29];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage3() {
    ap_CS_fsm_pp0_stage3 = ap_CS_fsm.read()[3];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage30() {
    ap_CS_fsm_pp0_stage30 = ap_CS_fsm.read()[30];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage31() {
    ap_CS_fsm_pp0_stage31 = ap_CS_fsm.read()[31];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage4() {
    ap_CS_fsm_pp0_stage4 = ap_CS_fsm.read()[4];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage5() {
    ap_CS_fsm_pp0_stage5 = ap_CS_fsm.read()[5];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage6() {
    ap_CS_fsm_pp0_stage6 = ap_CS_fsm.read()[6];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage7() {
    ap_CS_fsm_pp0_stage7 = ap_CS_fsm.read()[7];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage8() {
    ap_CS_fsm_pp0_stage8 = ap_CS_fsm.read()[8];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage9() {
    ap_CS_fsm_pp0_stage9 = ap_CS_fsm.read()[9];
}

void BF_encrypt::thread_ap_block_pp0_stage0_flag00000000() {
    ap_block_pp0_stage0_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage0_flag00011001() {
    ap_block_pp0_stage0_flag00011001 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void BF_encrypt::thread_ap_block_pp0_stage0_flag00011011() {
    ap_block_pp0_stage0_flag00011011 = (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0) || (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())));
}

void BF_encrypt::thread_ap_block_pp0_stage10_flag00000000() {
    ap_block_pp0_stage10_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage10_flag00011001() {
    ap_block_pp0_stage10_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage10_flag00011011() {
    ap_block_pp0_stage10_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage11_flag00000000() {
    ap_block_pp0_stage11_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage11_flag00011001() {
    ap_block_pp0_stage11_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage11_flag00011011() {
    ap_block_pp0_stage11_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage12_flag00000000() {
    ap_block_pp0_stage12_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage12_flag00011001() {
    ap_block_pp0_stage12_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage12_flag00011011() {
    ap_block_pp0_stage12_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage13_flag00000000() {
    ap_block_pp0_stage13_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage13_flag00011001() {
    ap_block_pp0_stage13_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage13_flag00011011() {
    ap_block_pp0_stage13_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage14_flag00000000() {
    ap_block_pp0_stage14_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage14_flag00011001() {
    ap_block_pp0_stage14_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage14_flag00011011() {
    ap_block_pp0_stage14_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage15_flag00000000() {
    ap_block_pp0_stage15_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage15_flag00011001() {
    ap_block_pp0_stage15_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage15_flag00011011() {
    ap_block_pp0_stage15_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage16_flag00000000() {
    ap_block_pp0_stage16_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage16_flag00011001() {
    ap_block_pp0_stage16_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage16_flag00011011() {
    ap_block_pp0_stage16_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage17_flag00000000() {
    ap_block_pp0_stage17_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage17_flag00011001() {
    ap_block_pp0_stage17_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage17_flag00011011() {
    ap_block_pp0_stage17_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage18_flag00000000() {
    ap_block_pp0_stage18_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage18_flag00011001() {
    ap_block_pp0_stage18_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage18_flag00011011() {
    ap_block_pp0_stage18_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage19_flag00000000() {
    ap_block_pp0_stage19_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage19_flag00011001() {
    ap_block_pp0_stage19_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage19_flag00011011() {
    ap_block_pp0_stage19_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage1_flag00000000() {
    ap_block_pp0_stage1_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage1_flag00011001() {
    ap_block_pp0_stage1_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage1_flag00011011() {
    ap_block_pp0_stage1_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage20_flag00000000() {
    ap_block_pp0_stage20_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage20_flag00011001() {
    ap_block_pp0_stage20_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage20_flag00011011() {
    ap_block_pp0_stage20_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage21_flag00000000() {
    ap_block_pp0_stage21_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage21_flag00011001() {
    ap_block_pp0_stage21_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage21_flag00011011() {
    ap_block_pp0_stage21_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage22_flag00000000() {
    ap_block_pp0_stage22_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage22_flag00011001() {
    ap_block_pp0_stage22_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage22_flag00011011() {
    ap_block_pp0_stage22_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage23_flag00000000() {
    ap_block_pp0_stage23_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage23_flag00011001() {
    ap_block_pp0_stage23_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage23_flag00011011() {
    ap_block_pp0_stage23_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage24_flag00000000() {
    ap_block_pp0_stage24_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage24_flag00011001() {
    ap_block_pp0_stage24_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage24_flag00011011() {
    ap_block_pp0_stage24_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage25_flag00000000() {
    ap_block_pp0_stage25_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage25_flag00011001() {
    ap_block_pp0_stage25_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage25_flag00011011() {
    ap_block_pp0_stage25_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage26_flag00000000() {
    ap_block_pp0_stage26_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage26_flag00011001() {
    ap_block_pp0_stage26_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage26_flag00011011() {
    ap_block_pp0_stage26_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage27_flag00000000() {
    ap_block_pp0_stage27_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage27_flag00011001() {
    ap_block_pp0_stage27_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage27_flag00011011() {
    ap_block_pp0_stage27_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage28_flag00000000() {
    ap_block_pp0_stage28_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage28_flag00011001() {
    ap_block_pp0_stage28_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage28_flag00011011() {
    ap_block_pp0_stage28_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage29_flag00000000() {
    ap_block_pp0_stage29_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage29_flag00011001() {
    ap_block_pp0_stage29_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage29_flag00011011() {
    ap_block_pp0_stage29_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage2_flag00000000() {
    ap_block_pp0_stage2_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage2_flag00011001() {
    ap_block_pp0_stage2_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage2_flag00011011() {
    ap_block_pp0_stage2_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage30_flag00000000() {
    ap_block_pp0_stage30_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage30_flag00011001() {
    ap_block_pp0_stage30_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage30_flag00011011() {
    ap_block_pp0_stage30_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage31_flag00000000() {
    ap_block_pp0_stage31_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage31_flag00011001() {
    ap_block_pp0_stage31_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage31_flag00011011() {
    ap_block_pp0_stage31_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage3_flag00000000() {
    ap_block_pp0_stage3_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage3_flag00011001() {
    ap_block_pp0_stage3_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage3_flag00011011() {
    ap_block_pp0_stage3_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage4_flag00000000() {
    ap_block_pp0_stage4_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage4_flag00011001() {
    ap_block_pp0_stage4_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage4_flag00011011() {
    ap_block_pp0_stage4_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage5_flag00000000() {
    ap_block_pp0_stage5_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage5_flag00011001() {
    ap_block_pp0_stage5_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage5_flag00011011() {
    ap_block_pp0_stage5_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage6_flag00000000() {
    ap_block_pp0_stage6_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage6_flag00011001() {
    ap_block_pp0_stage6_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage6_flag00011011() {
    ap_block_pp0_stage6_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage7_flag00000000() {
    ap_block_pp0_stage7_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage7_flag00011001() {
    ap_block_pp0_stage7_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage7_flag00011011() {
    ap_block_pp0_stage7_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage8_flag00000000() {
    ap_block_pp0_stage8_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage8_flag00011001() {
    ap_block_pp0_stage8_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage8_flag00011011() {
    ap_block_pp0_stage8_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage9_flag00000000() {
    ap_block_pp0_stage9_flag00000000 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage9_flag00011001() {
    ap_block_pp0_stage9_flag00011001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage9_flag00011011() {
    ap_block_pp0_stage9_flag00011011 = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_state10_pp0_stage9_iter0() {
    ap_block_state10_pp0_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state11_pp0_stage10_iter0() {
    ap_block_state11_pp0_stage10_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state12_pp0_stage11_iter0() {
    ap_block_state12_pp0_stage11_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state13_pp0_stage12_iter0() {
    ap_block_state13_pp0_stage12_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state14_pp0_stage13_iter0() {
    ap_block_state14_pp0_stage13_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state15_pp0_stage14_iter0() {
    ap_block_state15_pp0_stage14_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state16_pp0_stage15_iter0() {
    ap_block_state16_pp0_stage15_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state17_pp0_stage16_iter0() {
    ap_block_state17_pp0_stage16_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state18_pp0_stage17_iter0() {
    ap_block_state18_pp0_stage17_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state19_pp0_stage18_iter0() {
    ap_block_state19_pp0_stage18_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state1_pp0_stage0_iter0() {
    ap_block_state1_pp0_stage0_iter0 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void BF_encrypt::thread_ap_block_state20_pp0_stage19_iter0() {
    ap_block_state20_pp0_stage19_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state21_pp0_stage20_iter0() {
    ap_block_state21_pp0_stage20_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state22_pp0_stage21_iter0() {
    ap_block_state22_pp0_stage21_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state23_pp0_stage22_iter0() {
    ap_block_state23_pp0_stage22_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state24_pp0_stage23_iter0() {
    ap_block_state24_pp0_stage23_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state25_pp0_stage24_iter0() {
    ap_block_state25_pp0_stage24_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state26_pp0_stage25_iter0() {
    ap_block_state26_pp0_stage25_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state27_pp0_stage26_iter0() {
    ap_block_state27_pp0_stage26_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state28_pp0_stage27_iter0() {
    ap_block_state28_pp0_stage27_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state29_pp0_stage28_iter0() {
    ap_block_state29_pp0_stage28_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state2_pp0_stage1_iter0() {
    ap_block_state2_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state30_pp0_stage29_iter0() {
    ap_block_state30_pp0_stage29_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state31_pp0_stage30_iter0() {
    ap_block_state31_pp0_stage30_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state32_pp0_stage31_iter0() {
    ap_block_state32_pp0_stage31_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state33_pp0_stage0_iter1() {
    ap_block_state33_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state34_pp0_stage1_iter1() {
    ap_block_state34_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state35_pp0_stage2_iter1() {
    ap_block_state35_pp0_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state36_pp0_stage3_iter1() {
    ap_block_state36_pp0_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state37_pp0_stage4_iter1() {
    ap_block_state37_pp0_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state38_pp0_stage5_iter1() {
    ap_block_state38_pp0_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state39_pp0_stage6_iter1() {
    ap_block_state39_pp0_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state3_pp0_stage2_iter0() {
    ap_block_state3_pp0_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state40_pp0_stage7_iter1() {
    ap_block_state40_pp0_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state41_pp0_stage8_iter1() {
    ap_block_state41_pp0_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state42_pp0_stage9_iter1() {
    ap_block_state42_pp0_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state43_pp0_stage10_iter1() {
    ap_block_state43_pp0_stage10_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state44_pp0_stage11_iter1() {
    ap_block_state44_pp0_stage11_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state45_pp0_stage12_iter1() {
    ap_block_state45_pp0_stage12_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state46_pp0_stage13_iter1() {
    ap_block_state46_pp0_stage13_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state47_pp0_stage14_iter1() {
    ap_block_state47_pp0_stage14_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state48_pp0_stage15_iter1() {
    ap_block_state48_pp0_stage15_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state49_pp0_stage16_iter1() {
    ap_block_state49_pp0_stage16_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state4_pp0_stage3_iter0() {
    ap_block_state4_pp0_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state50_pp0_stage17_iter1() {
    ap_block_state50_pp0_stage17_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state51_pp0_stage18_iter1() {
    ap_block_state51_pp0_stage18_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state52_pp0_stage19_iter1() {
    ap_block_state52_pp0_stage19_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state53_pp0_stage20_iter1() {
    ap_block_state53_pp0_stage20_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state54_pp0_stage21_iter1() {
    ap_block_state54_pp0_stage21_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state55_pp0_stage22_iter1() {
    ap_block_state55_pp0_stage22_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state56_pp0_stage23_iter1() {
    ap_block_state56_pp0_stage23_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state57_pp0_stage24_iter1() {
    ap_block_state57_pp0_stage24_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state58_pp0_stage25_iter1() {
    ap_block_state58_pp0_stage25_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state59_pp0_stage26_iter1() {
    ap_block_state59_pp0_stage26_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state5_pp0_stage4_iter0() {
    ap_block_state5_pp0_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state60_pp0_stage27_iter1() {
    ap_block_state60_pp0_stage27_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state61_pp0_stage28_iter1() {
    ap_block_state61_pp0_stage28_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state62_pp0_stage29_iter1() {
    ap_block_state62_pp0_stage29_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state63_pp0_stage30_iter1() {
    ap_block_state63_pp0_stage30_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state64_pp0_stage31_iter1() {
    ap_block_state64_pp0_stage31_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state6_pp0_stage5_iter0() {
    ap_block_state6_pp0_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state7_pp0_stage6_iter0() {
    ap_block_state7_pp0_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state8_pp0_stage7_iter0() {
    ap_block_state8_pp0_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state9_pp0_stage8_iter0() {
    ap_block_state9_pp0_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_condition_148() {
    ap_condition_148 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00011001.read(), ap_const_boolean_0));
}

void BF_encrypt::thread_ap_condition_314() {
    ap_condition_314 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage9_flag00011001.read(), ap_const_boolean_0));
}

void BF_encrypt::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00000000.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void BF_encrypt::thread_ap_enable_reg_pp0_iter0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read())) {
        ap_enable_reg_pp0_iter0 = ap_start.read();
    } else {
        ap_enable_reg_pp0_iter0 = ap_enable_reg_pp0_iter0_reg.read();
    }
}

void BF_encrypt::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0_0to0() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read())) {
        ap_idle_pp0_0to0 = ap_const_logic_1;
    } else {
        ap_idle_pp0_0to0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0_1to1() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read())) {
        ap_idle_pp0_1to1 = ap_const_logic_1;
    } else {
        ap_idle_pp0_1to1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00011001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to0.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_return_0() {
    ap_return_0 = r_8_reg_5501.read();
}

void BF_encrypt::thread_ap_return_1() {
    ap_return_1 = l_8_fu_4338_p2.read();
}

void BF_encrypt::thread_grp_fu_634_p2() {
    grp_fu_634_p2 = (!key_S_q1.read().is_01() || !key_S_q0.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(key_S_q0.read()));
}

void BF_encrypt::thread_key_P_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_10;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_E;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_C;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_A;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_8;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_6;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_4;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_2;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_0;
    } else {
        key_P_address0 = "XXXXX";
    }
}

void BF_encrypt::thread_key_P_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_11;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_F;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_D;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_B;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_9;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_7;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_5;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_3;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00000000.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_1;
    } else {
        key_P_address1 = "XXXXX";
    }
}

void BF_encrypt::thread_key_P_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00011001.read(), ap_const_boolean_0)))) {
        key_P_ce0 = ap_const_logic_1;
    } else {
        key_P_ce0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_P_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00011001.read(), ap_const_boolean_0)))) {
        key_P_ce1 = ap_const_logic_1;
    } else {
        key_P_ce1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_S_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage30_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_207_cast_fu_4304_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage27_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_541_fu_4281_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage24_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_195_cast_fu_4109_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage21_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_513_fu_4044_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_183_cast_fu_3876_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_20_fu_3811_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_171_cast_fu_3643_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_19_fu_3578_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_159_cast_fu_3406_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_18_fu_3341_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00000000.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        key_S_address0 =  (sc_lv<10>) (tmp_147_cast_fu_3155_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_11_fu_3108_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage29_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_135_cast_fu_2918_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage28_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_10_fu_2871_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage26_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_123_cast_fu_2685_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage25_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_9_fu_2638_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage23_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_111_cast_fu_2452_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage22_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_8_fu_2405_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage20_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_99_cast_fu_2219_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_7_fu_2172_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_87_cast_fu_1986_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_6_fu_1939_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_75_cast_fu_1753_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_5_fu_1706_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_63_cast_fu_1516_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_4_fu_1469_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_51_cast_fu_1279_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_3_fu_1232_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_39_cast_fu_1042_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_2_fu_995_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_27_cast_fu_789_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (tmp_1_fu_720_p1.read());
    } else {
        key_S_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void BF_encrypt::thread_key_S_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage30_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_210_cast_fu_4316_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage27_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_203_cast_fu_4292_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage24_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_198_cast_fu_4121_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage21_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_191_cast_fu_4055_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_186_cast_fu_3888_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_179_cast_fu_3822_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_174_cast_fu_3655_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_167_cast_fu_3589_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_162_cast_fu_3418_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_155_cast_fu_3352_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00000000.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        key_S_address1 =  (sc_lv<10>) (tmp_150_cast_fu_3185_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_143_cast_fu_3119_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage29_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_138_cast_fu_2948_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage28_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_131_cast_fu_2882_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage26_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_126_cast_fu_2715_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage25_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_119_cast_fu_2649_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage23_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_114_cast_fu_2482_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage22_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_107_cast_fu_2416_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage20_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_102_cast_fu_2249_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_95_cast_fu_2183_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_90_cast_fu_2016_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_83_cast_fu_1950_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_78_cast_fu_1783_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_71_cast_fu_1717_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_66_cast_fu_1546_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_59_cast_fu_1480_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_54_cast_fu_1309_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_47_cast_fu_1243_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_42_cast_fu_1072_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_35_cast_fu_1006_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_30_cast_fu_819_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00000000.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (tmp_23_cast_fu_743_p1.read());
    } else {
        key_S_address1 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void BF_encrypt::thread_key_S_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage23_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage26_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage29_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage22_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage25_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage28_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage21_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage24_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage27_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage30_flag00011001.read(), ap_const_boolean_0)))) {
        key_S_ce0 = ap_const_logic_1;
    } else {
        key_S_ce0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_S_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage23_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage26_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage29_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage22_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage25_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage28_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_flag00011001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage21_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage24_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage27_flag00011001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage30_flag00011001.read(), ap_const_boolean_0)))) {
        key_S_ce1 = ap_const_logic_1;
    } else {
        key_S_ce1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_l_10_cast26_cast_fu_3066_p2() {
    l_10_cast26_cast_fu_3066_p2 = (tmp_401_fu_3036_p2.read() ^ tmp_408_fu_3041_p1.read());
}

void BF_encrypt::thread_l_10_cast_cast_fu_3072_p2() {
    l_10_cast_cast_fu_3072_p2 = (tmp_399_fu_3027_p2.read() ^ tmp_407_fu_3032_p1.read());
}

void BF_encrypt::thread_l_10_cast_fu_3060_p2() {
    l_10_cast_fu_3060_p2 = (tmp_403_fu_3045_p2.read() ^ tmp_409_fu_3050_p1.read());
}

void BF_encrypt::thread_l_11_cast22_cast_fu_3536_p2() {
    l_11_cast22_cast_fu_3536_p2 = (tmp_455_fu_3506_p2.read() ^ tmp_462_fu_3511_p1.read());
}

void BF_encrypt::thread_l_11_cast_cast_fu_3542_p2() {
    l_11_cast_cast_fu_3542_p2 = (tmp_453_fu_3497_p2.read() ^ tmp_461_fu_3502_p1.read());
}

void BF_encrypt::thread_l_11_cast_fu_3530_p2() {
    l_11_cast_fu_3530_p2 = (tmp_457_fu_3515_p2.read() ^ tmp_463_fu_3520_p1.read());
}

void BF_encrypt::thread_l_13_cast18_cast_fu_4002_p2() {
    l_13_cast18_cast_fu_4002_p2 = (tmp_509_fu_3975_p2.read() ^ tmp_517_fu_3980_p1.read());
}

void BF_encrypt::thread_l_13_cast_cast_fu_4008_p2() {
    l_13_cast_cast_fu_4008_p2 = (tmp_507_fu_3967_p2.read() ^ tmp_516_fu_3972_p1.read());
}

void BF_encrypt::thread_l_13_cast_fu_3996_p2() {
    l_13_cast_fu_3996_p2 = (tmp_511_fu_3983_p2.read() ^ tmp_518_fu_3988_p1.read());
}

void BF_encrypt::thread_l_1_fu_1178_p2() {
    l_1_fu_1178_p2 = (tmp1_fu_1146_p2.read() ^ reg_649.read());
}

void BF_encrypt::thread_l_2_cast42_cast_fu_1190_p2() {
    l_2_cast42_cast_fu_1190_p2 = (tmp_146_fu_1160_p2.read() ^ tmp_165_fu_1165_p1.read());
}

void BF_encrypt::thread_l_2_cast_cast_fu_1196_p2() {
    l_2_cast_cast_fu_1196_p2 = (tmp_142_fu_1151_p2.read() ^ tmp_161_fu_1156_p1.read());
}

void BF_encrypt::thread_l_2_cast_fu_1184_p2() {
    l_2_cast_fu_1184_p2 = (tmp_153_fu_1169_p2.read() ^ tmp_166_fu_1174_p1.read());
}

void BF_encrypt::thread_l_2_fu_1652_p2() {
    l_2_fu_1652_p2 = (tmp3_fu_1620_p2.read() ^ reg_640.read());
}

void BF_encrypt::thread_l_3_fu_2119_p2() {
    l_3_fu_2119_p2 = (tmp5_fu_2090_p2.read() ^ key_P_load_6_reg_4470.read());
}

void BF_encrypt::thread_l_4_cast38_cast_fu_1664_p2() {
    l_4_cast38_cast_fu_1664_p2 = (tmp_239_fu_1634_p2.read() ^ tmp_246_fu_1639_p1.read());
}

void BF_encrypt::thread_l_4_cast_cast_fu_1670_p2() {
    l_4_cast_cast_fu_1670_p2 = (tmp_237_fu_1625_p2.read() ^ tmp_245_fu_1630_p1.read());
}

void BF_encrypt::thread_l_4_cast_fu_1658_p2() {
    l_4_cast_fu_1658_p2 = (tmp_241_fu_1643_p2.read() ^ tmp_247_fu_1648_p1.read());
}

void BF_encrypt::thread_l_4_fu_2585_p2() {
    l_4_fu_2585_p2 = (tmp7_fu_2556_p2.read() ^ key_P_load_8_reg_4511.read());
}

void BF_encrypt::thread_l_5_fu_3054_p2() {
    l_5_fu_3054_p2 = (tmp9_fu_3022_p2.read() ^ reg_649.read());
}

void BF_encrypt::thread_l_6_cast34_cast_fu_2130_p2() {
    l_6_cast34_cast_fu_2130_p2 = (tmp_293_fu_2103_p2.read() ^ tmp_300_fu_2108_p1.read());
}

void BF_encrypt::thread_l_6_cast_cast_fu_2136_p2() {
    l_6_cast_cast_fu_2136_p2 = (tmp_291_fu_2095_p2.read() ^ tmp_299_fu_2100_p1.read());
}

void BF_encrypt::thread_l_6_cast_fu_2124_p2() {
    l_6_cast_fu_2124_p2 = (tmp_295_fu_2111_p2.read() ^ tmp_301_fu_2116_p1.read());
}

void BF_encrypt::thread_l_6_fu_3524_p2() {
    l_6_fu_3524_p2 = (tmp11_fu_3492_p2.read() ^ key_P_q0.read());
}

void BF_encrypt::thread_l_7_fu_3991_p2() {
    l_7_fu_3991_p2 = (tmp13_fu_3962_p2.read() ^ key_P_load_14_reg_5289.read());
}

void BF_encrypt::thread_l_8_cast30_cast_fu_2596_p2() {
    l_8_cast30_cast_fu_2596_p2 = (tmp_347_fu_2569_p2.read() ^ tmp_354_fu_2574_p1.read());
}

void BF_encrypt::thread_l_8_cast_cast_fu_2602_p2() {
    l_8_cast_cast_fu_2602_p2 = (tmp_345_fu_2561_p2.read() ^ tmp_353_fu_2566_p1.read());
}

void BF_encrypt::thread_l_8_cast_fu_2590_p2() {
    l_8_cast_fu_2590_p2 = (tmp_349_fu_2577_p2.read() ^ tmp_355_fu_2582_p1.read());
}

void BF_encrypt::thread_l_8_fu_4338_p2() {
    l_8_fu_4338_p2 = (tmp15_fu_4333_p2.read() ^ reg_653.read());
}

void BF_encrypt::thread_l_cast46_cast_fu_698_p2() {
    l_cast46_cast_fu_698_p2 = (tmp_23_fu_670_p1.read() ^ tmp_25_fu_674_p1.read());
}

void BF_encrypt::thread_l_cast_cast_fu_704_p2() {
    l_cast_cast_fu_704_p2 = (tmp_17_fu_662_p1.read() ^ tmp_22_fu_666_p1.read());
}

void BF_encrypt::thread_l_cast_fu_692_p2() {
    l_cast_fu_692_p2 = (tmp_26_fu_678_p1.read() ^ tmp_29_fu_682_p1.read());
}

void BF_encrypt::thread_l_fu_686_p2() {
    l_fu_686_p2 = (key_P_q0.read() ^ ap_port_reg_data_0_read.read());
}

void BF_encrypt::thread_r_10_cast24_cast_fu_3299_p2() {
    r_10_cast24_cast_fu_3299_p2 = (tmp_428_fu_3272_p2.read() ^ tmp_435_fu_3277_p1.read());
}

void BF_encrypt::thread_r_10_cast_cast_fu_3305_p2() {
    r_10_cast_cast_fu_3305_p2 = (tmp_426_fu_3264_p2.read() ^ tmp_434_fu_3269_p1.read());
}

void BF_encrypt::thread_r_10_cast_fu_3293_p2() {
    r_10_cast_fu_3293_p2 = (tmp_430_fu_3280_p2.read() ^ tmp_436_fu_3285_p1.read());
}

void BF_encrypt::thread_r_12_cast20_cast_fu_3769_p2() {
    r_12_cast20_cast_fu_3769_p2 = (tmp_482_fu_3742_p2.read() ^ tmp_489_fu_3747_p1.read());
}

void BF_encrypt::thread_r_12_cast_cast_fu_3775_p2() {
    r_12_cast_cast_fu_3775_p2 = (tmp_480_fu_3734_p2.read() ^ tmp_488_fu_3739_p1.read());
}

void BF_encrypt::thread_r_12_cast_fu_3763_p2() {
    r_12_cast_fu_3763_p2 = (tmp_484_fu_3750_p2.read() ^ tmp_490_fu_3755_p1.read());
}

void BF_encrypt::thread_r_14_cast16_cast_fu_4235_p2() {
    r_14_cast16_cast_fu_4235_p2 = (tmp_537_fu_4208_p2.read() ^ tmp_545_fu_4213_p1.read());
}

void BF_encrypt::thread_r_14_cast_cast_fu_4241_p2() {
    r_14_cast_cast_fu_4241_p2 = (tmp_535_fu_4200_p2.read() ^ tmp_544_fu_4205_p1.read());
}

void BF_encrypt::thread_r_14_cast_fu_4229_p2() {
    r_14_cast_fu_4229_p2 = (tmp_539_fu_4216_p2.read() ^ tmp_546_fu_4221_p1.read());
}

void BF_encrypt::thread_r_1_cast44_cast_fu_953_p2() {
    r_1_cast44_cast_fu_953_p2 = (tmp_82_fu_921_p2.read() ^ tmp_98_fu_927_p1.read());
}

void BF_encrypt::thread_r_1_cast_cast_fu_959_p2() {
    r_1_cast_cast_fu_959_p2 = (tmp_77_fu_911_p2.read() ^ tmp_97_fu_917_p1.read());
}

void BF_encrypt::thread_r_1_cast_fu_947_p2() {
    r_1_cast_fu_947_p2 = (tmp_86_fu_931_p2.read() ^ tmp_101_fu_937_p1.read());
}

void BF_encrypt::thread_r_1_fu_1415_p2() {
    r_1_fu_1415_p2 = (tmp2_fu_1383_p2.read() ^ reg_653.read());
}

void BF_encrypt::thread_r_2_fu_1886_p2() {
    r_2_fu_1886_p2 = (tmp4_fu_1857_p2.read() ^ key_P_load_5_reg_4452.read());
}

void BF_encrypt::thread_r_3_cast40_cast_fu_1427_p2() {
    r_3_cast40_cast_fu_1427_p2 = (tmp_212_fu_1397_p2.read() ^ tmp_219_fu_1402_p1.read());
}

void BF_encrypt::thread_r_3_cast_cast_fu_1433_p2() {
    r_3_cast_cast_fu_1433_p2 = (tmp_206_fu_1388_p2.read() ^ tmp_218_fu_1393_p1.read());
}

void BF_encrypt::thread_r_3_cast_fu_1421_p2() {
    r_3_cast_fu_1421_p2 = (tmp_214_fu_1406_p2.read() ^ tmp_220_fu_1411_p1.read());
}

void BF_encrypt::thread_r_3_fu_2352_p2() {
    r_3_fu_2352_p2 = (tmp6_fu_2323_p2.read() ^ key_P_load_7_reg_4478.read());
}

void BF_encrypt::thread_r_4_fu_2818_p2() {
    r_4_fu_2818_p2 = (tmp8_fu_2789_p2.read() ^ key_P_load_9_reg_4519.read());
}

void BF_encrypt::thread_r_5_cast36_cast_fu_1897_p2() {
    r_5_cast36_cast_fu_1897_p2 = (tmp_266_fu_1870_p2.read() ^ tmp_273_fu_1875_p1.read());
}

void BF_encrypt::thread_r_5_cast_cast_fu_1903_p2() {
    r_5_cast_cast_fu_1903_p2 = (tmp_264_fu_1862_p2.read() ^ tmp_272_fu_1867_p1.read());
}

void BF_encrypt::thread_r_5_cast_fu_1891_p2() {
    r_5_cast_fu_1891_p2 = (tmp_268_fu_1878_p2.read() ^ tmp_274_fu_1883_p1.read());
}

void BF_encrypt::thread_r_5_fu_3288_p2() {
    r_5_fu_3288_p2 = (tmp10_fu_3259_p2.read() ^ key_P_load_11_reg_4563.read());
}

void BF_encrypt::thread_r_6_fu_3758_p2() {
    r_6_fu_3758_p2 = (tmp12_fu_3729_p2.read() ^ key_P_load_13_reg_5266.read());
}

void BF_encrypt::thread_r_7_cast32_cast_fu_2363_p2() {
    r_7_cast32_cast_fu_2363_p2 = (tmp_320_fu_2336_p2.read() ^ tmp_327_fu_2341_p1.read());
}

void BF_encrypt::thread_r_7_cast_cast_fu_2369_p2() {
    r_7_cast_cast_fu_2369_p2 = (tmp_318_fu_2328_p2.read() ^ tmp_326_fu_2333_p1.read());
}

void BF_encrypt::thread_r_7_cast_fu_2357_p2() {
    r_7_cast_fu_2357_p2 = (tmp_322_fu_2344_p2.read() ^ tmp_328_fu_2349_p1.read());
}

void BF_encrypt::thread_r_7_fu_4224_p2() {
    r_7_fu_4224_p2 = (tmp14_fu_4195_p2.read() ^ key_P_load_15_reg_5297.read());
}

void BF_encrypt::thread_r_8_fu_4277_p2() {
    r_8_fu_4277_p2 = (key_P_load_17_reg_5315.read() ^ r_7_reg_5476.read());
}

void BF_encrypt::thread_r_9_cast28_cast_fu_2829_p2() {
    r_9_cast28_cast_fu_2829_p2 = (tmp_374_fu_2802_p2.read() ^ tmp_381_fu_2807_p1.read());
}

void BF_encrypt::thread_r_9_cast_cast_fu_2835_p2() {
    r_9_cast_cast_fu_2835_p2 = (tmp_372_fu_2794_p2.read() ^ tmp_380_fu_2799_p1.read());
}

void BF_encrypt::thread_r_9_cast_fu_2823_p2() {
    r_9_cast_fu_2823_p2 = (tmp_376_fu_2810_p2.read() ^ tmp_382_fu_2815_p1.read());
}

void BF_encrypt::thread_r_fu_941_p2() {
    r_fu_941_p2 = (tmp_fu_905_p2.read() ^ reg_640.read());
}

void BF_encrypt::thread_tmp10_fu_3259_p2() {
    tmp10_fu_3259_p2 = (r_4_reg_5032.read() ^ tmp_151_fu_3235_p2.read());
}

void BF_encrypt::thread_tmp11_fu_3492_p2() {
    tmp11_fu_3492_p2 = (l_5_reg_5103.read() ^ tmp_163_fu_3468_p2.read());
}

void BF_encrypt::thread_tmp12_fu_3729_p2() {
    tmp12_fu_3729_p2 = (r_5_reg_5174.read() ^ tmp_175_fu_3705_p2.read());
}

void BF_encrypt::thread_tmp13_fu_3962_p2() {
    tmp13_fu_3962_p2 = (l_6_reg_5245.read() ^ tmp_187_fu_3938_p2.read());
}

void BF_encrypt::thread_tmp14_fu_4195_p2() {
    tmp14_fu_4195_p2 = (r_6_reg_5345.read() ^ tmp_199_fu_4171_p2.read());
}

void BF_encrypt::thread_tmp15_fu_4333_p2() {
    tmp15_fu_4333_p2 = (l_7_reg_5416.read() ^ tmp_211_fu_4327_p2.read());
}

void BF_encrypt::thread_tmp1_fu_1146_p2() {
    tmp1_fu_1146_p2 = (l_reg_4355.read() ^ tmp_43_fu_1122_p2.read());
}

void BF_encrypt::thread_tmp2_fu_1383_p2() {
    tmp2_fu_1383_p2 = (r_reg_4416.read() ^ tmp_55_fu_1359_p2.read());
}

void BF_encrypt::thread_tmp3_fu_1620_p2() {
    tmp3_fu_1620_p2 = (l_1_reg_4527.read() ^ tmp_67_fu_1596_p2.read());
}

void BF_encrypt::thread_tmp4_fu_1857_p2() {
    tmp4_fu_1857_p2 = (r_1_reg_4606.read() ^ tmp_79_fu_1833_p2.read());
}

void BF_encrypt::thread_tmp5_fu_2090_p2() {
    tmp5_fu_2090_p2 = (l_2_reg_4677.read() ^ tmp_91_fu_2066_p2.read());
}

void BF_encrypt::thread_tmp6_fu_2323_p2() {
    tmp6_fu_2323_p2 = (r_2_reg_4748.read() ^ tmp_103_fu_2299_p2.read());
}

void BF_encrypt::thread_tmp7_fu_2556_p2() {
    tmp7_fu_2556_p2 = (l_3_reg_4819.read() ^ tmp_115_fu_2532_p2.read());
}

void BF_encrypt::thread_tmp8_fu_2789_p2() {
    tmp8_fu_2789_p2 = (r_3_reg_4890.read() ^ tmp_127_fu_2765_p2.read());
}

void BF_encrypt::thread_tmp9_fu_3022_p2() {
    tmp9_fu_3022_p2 = (l_4_reg_4961.read() ^ tmp_139_fu_2998_p2.read());
}

void BF_encrypt::thread_tmp_100_fu_2266_p2() {
    tmp_100_fu_2266_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_101_fu_937_p1() {
    tmp_101_fu_937_p1 = reg_640.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_102_cast_fu_2249_p1() {
    tmp_102_cast_fu_2249_p1 = esl_zext<32,10>(tmp_102_fu_2242_p3.read());
}

void BF_encrypt::thread_tmp_102_fu_2242_p3() {
    tmp_102_fu_2242_p3 = esl_concat<2,8>(ap_const_lv2_3, l_6_cast_reg_4824.read());
}

void BF_encrypt::thread_tmp_103_fu_2299_p2() {
    tmp_103_fu_2299_p2 = (!key_S_q1.read().is_01() || !tmp_100_fu_2266_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_100_fu_2266_p2.read()));
}

void BF_encrypt::thread_tmp_105_fu_1011_p1() {
    tmp_105_fu_1011_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_106_fu_1015_p1() {
    tmp_106_fu_1015_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_107_cast_fu_2416_p1() {
    tmp_107_cast_fu_2416_p1 = esl_zext<32,9>(tmp_107_fu_2409_p3.read());
}

void BF_encrypt::thread_tmp_107_fu_2409_p3() {
    tmp_107_fu_2409_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_105_cast_reg_4916.read());
}

void BF_encrypt::thread_tmp_109_fu_1047_p2() {
    tmp_109_fu_1047_p2 = (!tmp_125_fu_1031_p1.read().is_01() || !tmp_121_fu_1027_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_125_fu_1031_p1.read()) + sc_biguint<8>(tmp_121_fu_1027_p1.read()));
}

void BF_encrypt::thread_tmp_10_fu_2871_p1() {
    tmp_10_fu_2871_p1 = esl_zext<32,8>(tmp_128_reg_5053.read());
}

void BF_encrypt::thread_tmp_110_fu_1019_p1() {
    tmp_110_fu_1019_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_111_cast_fu_2452_p1() {
    tmp_111_cast_fu_2452_p1 = esl_zext<32,10>(tmp_111_fu_2445_p3.read());
}

void BF_encrypt::thread_tmp_111_fu_2445_p3() {
    tmp_111_fu_2445_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_109_cast_reg_4921.read());
}

void BF_encrypt::thread_tmp_112_fu_2499_p2() {
    tmp_112_fu_2499_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_113_fu_1053_p2() {
    tmp_113_fu_1053_p2 = (!tmp_117_fu_1023_p1.read().is_01() || !tmp_110_fu_1019_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_117_fu_1023_p1.read()) + sc_biguint<16>(tmp_110_fu_1019_p1.read()));
}

void BF_encrypt::thread_tmp_114_cast_fu_2482_p1() {
    tmp_114_cast_fu_2482_p1 = esl_zext<32,10>(tmp_114_fu_2475_p3.read());
}

void BF_encrypt::thread_tmp_114_fu_2475_p3() {
    tmp_114_fu_2475_p3 = esl_concat<2,8>(ap_const_lv2_3, r_7_cast_reg_4895.read());
}

void BF_encrypt::thread_tmp_115_fu_2532_p2() {
    tmp_115_fu_2532_p2 = (!key_S_q1.read().is_01() || !tmp_112_fu_2499_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_112_fu_2499_p2.read()));
}

void BF_encrypt::thread_tmp_117_fu_1023_p1() {
    tmp_117_fu_1023_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_118_fu_1059_p2() {
    tmp_118_fu_1059_p2 = (!tmp_106_fu_1015_p1.read().is_01() || !tmp_105_fu_1011_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_106_fu_1015_p1.read()) + sc_biguint<24>(tmp_105_fu_1011_p1.read()));
}

void BF_encrypt::thread_tmp_119_cast_fu_2649_p1() {
    tmp_119_cast_fu_2649_p1 = esl_zext<32,9>(tmp_119_fu_2642_p3.read());
}

void BF_encrypt::thread_tmp_119_fu_2642_p3() {
    tmp_119_fu_2642_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_117_cast_reg_4987.read());
}

void BF_encrypt::thread_tmp_11_fu_3108_p1() {
    tmp_11_fu_3108_p1 = esl_zext<32,8>(tmp_140_reg_5124.read());
}

void BF_encrypt::thread_tmp_121_fu_1027_p1() {
    tmp_121_fu_1027_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_122_fu_1099_p2() {
    tmp_122_fu_1099_p2 = (tmp_149_fu_1085_p1.read() ^ tmp_118_reg_4501.read());
}

void BF_encrypt::thread_tmp_123_cast_fu_2685_p1() {
    tmp_123_cast_fu_2685_p1 = esl_zext<32,10>(tmp_123_fu_2678_p3.read());
}

void BF_encrypt::thread_tmp_123_fu_2678_p3() {
    tmp_123_fu_2678_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_121_cast_reg_4992.read());
}

void BF_encrypt::thread_tmp_124_fu_2732_p2() {
    tmp_124_fu_2732_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_125_fu_1031_p1() {
    tmp_125_fu_1031_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_126_cast_fu_2715_p1() {
    tmp_126_cast_fu_2715_p1 = esl_zext<32,10>(tmp_126_fu_2708_p3.read());
}

void BF_encrypt::thread_tmp_126_fu_2708_p3() {
    tmp_126_fu_2708_p3 = esl_concat<2,8>(ap_const_lv2_3, l_8_cast_reg_4966.read());
}

void BF_encrypt::thread_tmp_127_fu_2765_p2() {
    tmp_127_fu_2765_p2 = (!key_S_q1.read().is_01() || !tmp_124_fu_2732_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_124_fu_2732_p2.read()));
}

void BF_encrypt::thread_tmp_129_fu_1108_p2() {
    tmp_129_fu_1108_p2 = (tmp_145_fu_1081_p1.read() ^ tmp_113_reg_4496.read());
}

void BF_encrypt::thread_tmp_130_fu_1077_p1() {
    tmp_130_fu_1077_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_131_cast_fu_2882_p1() {
    tmp_131_cast_fu_2882_p1 = esl_zext<32,9>(tmp_131_fu_2875_p3.read());
}

void BF_encrypt::thread_tmp_131_fu_2875_p3() {
    tmp_131_fu_2875_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_129_cast_reg_5058.read());
}

void BF_encrypt::thread_tmp_133_fu_1117_p2() {
    tmp_133_fu_1117_p2 = (tmp_130_fu_1077_p1.read() ^ tmp_109_reg_4491.read());
}

void BF_encrypt::thread_tmp_134_fu_1128_p2() {
    tmp_134_fu_1128_p2 = (!tmp_133_fu_1117_p2.read().is_01() || !tmp_158_fu_1113_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_133_fu_1117_p2.read()) + sc_biguint<8>(tmp_158_fu_1113_p1.read()));
}

void BF_encrypt::thread_tmp_135_cast_fu_2918_p1() {
    tmp_135_cast_fu_2918_p1 = esl_zext<32,10>(tmp_135_fu_2911_p3.read());
}

void BF_encrypt::thread_tmp_135_fu_2911_p3() {
    tmp_135_fu_2911_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_133_cast_reg_5063.read());
}

void BF_encrypt::thread_tmp_136_fu_2965_p2() {
    tmp_136_fu_2965_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_137_fu_1134_p2() {
    tmp_137_fu_1134_p2 = (!tmp_129_fu_1108_p2.read().is_01() || !tmp_157_fu_1104_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_129_fu_1108_p2.read()) + sc_biguint<16>(tmp_157_fu_1104_p1.read()));
}

void BF_encrypt::thread_tmp_138_cast_fu_2948_p1() {
    tmp_138_cast_fu_2948_p1 = esl_zext<32,10>(tmp_138_fu_2941_p3.read());
}

void BF_encrypt::thread_tmp_138_fu_2941_p3() {
    tmp_138_fu_2941_p3 = esl_concat<2,8>(ap_const_lv2_3, r_9_cast_reg_5037.read());
}

void BF_encrypt::thread_tmp_139_fu_2998_p2() {
    tmp_139_fu_2998_p2 = (!key_S_q1.read().is_01() || !tmp_136_fu_2965_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_136_fu_2965_p2.read()));
}

void BF_encrypt::thread_tmp_141_fu_1140_p2() {
    tmp_141_fu_1140_p2 = (!tmp_122_fu_1099_p2.read().is_01() || !tmp_154_fu_1095_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_122_fu_1099_p2.read()) + sc_biguint<24>(tmp_154_fu_1095_p1.read()));
}

void BF_encrypt::thread_tmp_142_fu_1151_p2() {
    tmp_142_fu_1151_p2 = (l_cast_cast_reg_4371.read() ^ tmp_141_fu_1140_p2.read());
}

void BF_encrypt::thread_tmp_143_cast_fu_3119_p1() {
    tmp_143_cast_fu_3119_p1 = esl_zext<32,9>(tmp_143_fu_3112_p3.read());
}

void BF_encrypt::thread_tmp_143_fu_3112_p3() {
    tmp_143_fu_3112_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_141_cast_reg_5129.read());
}

void BF_encrypt::thread_tmp_145_fu_1081_p1() {
    tmp_145_fu_1081_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_146_fu_1160_p2() {
    tmp_146_fu_1160_p2 = (l_cast46_cast_reg_4366.read() ^ tmp_137_fu_1134_p2.read());
}

void BF_encrypt::thread_tmp_147_cast_fu_3155_p1() {
    tmp_147_cast_fu_3155_p1 = esl_zext<32,10>(tmp_147_fu_3148_p3.read());
}

void BF_encrypt::thread_tmp_147_fu_3148_p3() {
    tmp_147_fu_3148_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_145_cast_reg_5134.read());
}

void BF_encrypt::thread_tmp_148_fu_3202_p2() {
    tmp_148_fu_3202_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_149_fu_1085_p1() {
    tmp_149_fu_1085_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_150_cast_fu_3185_p1() {
    tmp_150_cast_fu_3185_p1 = esl_zext<32,10>(tmp_150_fu_3178_p3.read());
}

void BF_encrypt::thread_tmp_150_fu_3178_p3() {
    tmp_150_fu_3178_p3 = esl_concat<2,8>(ap_const_lv2_3, l_10_cast_reg_5108.read());
}

void BF_encrypt::thread_tmp_151_fu_3235_p2() {
    tmp_151_fu_3235_p2 = (!key_S_q1.read().is_01() || !tmp_148_fu_3202_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_148_fu_3202_p2.read()));
}

void BF_encrypt::thread_tmp_153_fu_1169_p2() {
    tmp_153_fu_1169_p2 = (l_cast_reg_4360.read() ^ tmp_134_fu_1128_p2.read());
}

void BF_encrypt::thread_tmp_154_fu_1095_p1() {
    tmp_154_fu_1095_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_155_cast_fu_3352_p1() {
    tmp_155_cast_fu_3352_p1 = esl_zext<32,9>(tmp_155_fu_3345_p3.read());
}

void BF_encrypt::thread_tmp_155_fu_3345_p3() {
    tmp_155_fu_3345_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_153_cast_reg_5200.read());
}

void BF_encrypt::thread_tmp_157_fu_1104_p1() {
    tmp_157_fu_1104_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_158_fu_1113_p1() {
    tmp_158_fu_1113_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_159_cast_fu_3406_p1() {
    tmp_159_cast_fu_3406_p1 = esl_zext<32,10>(tmp_159_fu_3399_p3.read());
}

void BF_encrypt::thread_tmp_159_fu_3399_p3() {
    tmp_159_fu_3399_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_157_cast_reg_5205.read());
}

void BF_encrypt::thread_tmp_160_fu_3435_p2() {
    tmp_160_fu_3435_p2 = (key_S_q0.read() ^ reg_658.read());
}

void BF_encrypt::thread_tmp_161_fu_1156_p1() {
    tmp_161_fu_1156_p1 = reg_649.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_162_cast_fu_3418_p1() {
    tmp_162_cast_fu_3418_p1 = esl_zext<32,10>(tmp_162_fu_3411_p3.read());
}

void BF_encrypt::thread_tmp_162_fu_3411_p3() {
    tmp_162_fu_3411_p3 = esl_concat<2,8>(ap_const_lv2_3, r_10_cast_reg_5179.read());
}

void BF_encrypt::thread_tmp_163_fu_3468_p2() {
    tmp_163_fu_3468_p2 = (!key_S_q1.read().is_01() || !tmp_160_fu_3435_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_160_fu_3435_p2.read()));
}

void BF_encrypt::thread_tmp_165_fu_1165_p1() {
    tmp_165_fu_1165_p1 = reg_649.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_166_fu_1174_p1() {
    tmp_166_fu_1174_p1 = reg_649.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_167_cast_fu_3589_p1() {
    tmp_167_cast_fu_3589_p1 = esl_zext<32,9>(tmp_167_fu_3582_p3.read());
}

void BF_encrypt::thread_tmp_167_fu_3582_p3() {
    tmp_167_fu_3582_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_165_cast_reg_5279.read());
}

void BF_encrypt::thread_tmp_169_fu_1248_p1() {
    tmp_169_fu_1248_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_170_fu_1252_p1() {
    tmp_170_fu_1252_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_171_cast_fu_3643_p1() {
    tmp_171_cast_fu_3643_p1 = esl_zext<32,10>(tmp_171_fu_3636_p3.read());
}

void BF_encrypt::thread_tmp_171_fu_3636_p3() {
    tmp_171_fu_3636_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_169_cast_reg_5284.read());
}

void BF_encrypt::thread_tmp_172_fu_3672_p2() {
    tmp_172_fu_3672_p2 = (key_S_q0.read() ^ reg_658.read());
}

void BF_encrypt::thread_tmp_173_fu_1284_p2() {
    tmp_173_fu_1284_p2 = (!tmp_190_fu_1268_p1.read().is_01() || !tmp_185_fu_1264_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_190_fu_1268_p1.read()) + sc_biguint<8>(tmp_185_fu_1264_p1.read()));
}

void BF_encrypt::thread_tmp_174_cast_fu_3655_p1() {
    tmp_174_cast_fu_3655_p1 = esl_zext<32,10>(tmp_174_fu_3648_p3.read());
}

void BF_encrypt::thread_tmp_174_fu_3648_p3() {
    tmp_174_fu_3648_p3 = esl_concat<2,8>(ap_const_lv2_3, l_11_cast_reg_5250.read());
}

void BF_encrypt::thread_tmp_175_fu_3705_p2() {
    tmp_175_fu_3705_p2 = (!key_S_q1.read().is_01() || !tmp_172_fu_3672_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_172_fu_3672_p2.read()));
}

void BF_encrypt::thread_tmp_177_fu_1256_p1() {
    tmp_177_fu_1256_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_178_fu_1290_p2() {
    tmp_178_fu_1290_p2 = (!tmp_181_fu_1260_p1.read().is_01() || !tmp_177_fu_1256_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_181_fu_1260_p1.read()) + sc_biguint<16>(tmp_177_fu_1256_p1.read()));
}

void BF_encrypt::thread_tmp_179_cast_fu_3822_p1() {
    tmp_179_cast_fu_3822_p1 = esl_zext<32,9>(tmp_179_fu_3815_p3.read());
}

void BF_encrypt::thread_tmp_179_fu_3815_p3() {
    tmp_179_fu_3815_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_177_cast_reg_5371.read());
}

void BF_encrypt::thread_tmp_17_fu_662_p1() {
    tmp_17_fu_662_p1 = key_P_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_181_fu_1260_p1() {
    tmp_181_fu_1260_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_182_fu_1296_p2() {
    tmp_182_fu_1296_p2 = (!tmp_170_fu_1252_p1.read().is_01() || !tmp_169_fu_1248_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_170_fu_1252_p1.read()) + sc_biguint<24>(tmp_169_fu_1248_p1.read()));
}

void BF_encrypt::thread_tmp_183_cast_fu_3876_p1() {
    tmp_183_cast_fu_3876_p1 = esl_zext<32,10>(tmp_183_fu_3869_p3.read());
}

void BF_encrypt::thread_tmp_183_fu_3869_p3() {
    tmp_183_fu_3869_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_181_cast_reg_5376.read());
}

void BF_encrypt::thread_tmp_184_fu_3905_p2() {
    tmp_184_fu_3905_p2 = (key_S_q0.read() ^ reg_658.read());
}

void BF_encrypt::thread_tmp_185_fu_1264_p1() {
    tmp_185_fu_1264_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_186_cast_fu_3888_p1() {
    tmp_186_cast_fu_3888_p1 = esl_zext<32,10>(tmp_186_fu_3881_p3.read());
}

void BF_encrypt::thread_tmp_186_fu_3881_p3() {
    tmp_186_fu_3881_p3 = esl_concat<2,8>(ap_const_lv2_3, r_12_cast_reg_5350.read());
}

void BF_encrypt::thread_tmp_187_fu_3938_p2() {
    tmp_187_fu_3938_p2 = (!key_S_q1.read().is_01() || !tmp_184_fu_3905_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_184_fu_3905_p2.read()));
}

void BF_encrypt::thread_tmp_189_fu_1336_p2() {
    tmp_189_fu_1336_p2 = (tmp_213_fu_1322_p1.read() ^ tmp_182_reg_4596.read());
}

void BF_encrypt::thread_tmp_18_fu_3341_p1() {
    tmp_18_fu_3341_p1 = esl_zext<32,8>(tmp_152_reg_5195.read());
}

void BF_encrypt::thread_tmp_190_fu_1268_p1() {
    tmp_190_fu_1268_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_191_cast_fu_4055_p1() {
    tmp_191_cast_fu_4055_p1 = esl_zext<32,9>(tmp_191_fu_4048_p3.read());
}

void BF_encrypt::thread_tmp_191_fu_4048_p3() {
    tmp_191_fu_4048_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_189_cast_reg_5431.read());
}

void BF_encrypt::thread_tmp_193_fu_1345_p2() {
    tmp_193_fu_1345_p2 = (tmp_209_fu_1318_p1.read() ^ tmp_178_reg_4591.read());
}

void BF_encrypt::thread_tmp_194_fu_1314_p1() {
    tmp_194_fu_1314_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_195_cast_fu_4109_p1() {
    tmp_195_cast_fu_4109_p1 = esl_zext<32,10>(tmp_195_fu_4102_p3.read());
}

void BF_encrypt::thread_tmp_195_fu_4102_p3() {
    tmp_195_fu_4102_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_193_cast_reg_5436.read());
}

void BF_encrypt::thread_tmp_196_fu_4138_p2() {
    tmp_196_fu_4138_p2 = (key_S_q0.read() ^ reg_658.read());
}

void BF_encrypt::thread_tmp_197_fu_1354_p2() {
    tmp_197_fu_1354_p2 = (tmp_194_fu_1314_p1.read() ^ tmp_173_reg_4586.read());
}

void BF_encrypt::thread_tmp_198_cast_fu_4121_p1() {
    tmp_198_cast_fu_4121_p1 = esl_zext<32,10>(tmp_198_fu_4114_p3.read());
}

void BF_encrypt::thread_tmp_198_fu_4114_p3() {
    tmp_198_fu_4114_p3 = esl_concat<2,8>(ap_const_lv2_3, l_13_cast_reg_5421.read());
}

void BF_encrypt::thread_tmp_199_fu_4171_p2() {
    tmp_199_fu_4171_p2 = (!key_S_q1.read().is_01() || !tmp_196_fu_4138_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_196_fu_4138_p2.read()));
}

void BF_encrypt::thread_tmp_19_fu_3578_p1() {
    tmp_19_fu_3578_p1 = esl_zext<32,8>(tmp_164_reg_5274.read());
}

void BF_encrypt::thread_tmp_1_fu_720_p1() {
    tmp_1_fu_720_p1 = esl_zext<32,8>(tmp_s_fu_710_p4.read());
}

void BF_encrypt::thread_tmp_201_fu_1365_p2() {
    tmp_201_fu_1365_p2 = (!tmp_197_fu_1354_p2.read().is_01() || !tmp_217_fu_1350_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_197_fu_1354_p2.read()) + sc_biguint<8>(tmp_217_fu_1350_p1.read()));
}

void BF_encrypt::thread_tmp_202_fu_1371_p2() {
    tmp_202_fu_1371_p2 = (!tmp_193_fu_1345_p2.read().is_01() || !tmp_216_fu_1341_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_193_fu_1345_p2.read()) + sc_biguint<16>(tmp_216_fu_1341_p1.read()));
}

void BF_encrypt::thread_tmp_203_cast_fu_4292_p1() {
    tmp_203_cast_fu_4292_p1 = esl_zext<32,9>(tmp_203_fu_4285_p3.read());
}

void BF_encrypt::thread_tmp_203_fu_4285_p3() {
    tmp_203_fu_4285_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_201_cast_reg_5491.read());
}

void BF_encrypt::thread_tmp_205_fu_1377_p2() {
    tmp_205_fu_1377_p2 = (!tmp_189_fu_1336_p2.read().is_01() || !tmp_215_fu_1332_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_189_fu_1336_p2.read()) + sc_biguint<24>(tmp_215_fu_1332_p1.read()));
}

void BF_encrypt::thread_tmp_206_fu_1388_p2() {
    tmp_206_fu_1388_p2 = (r_1_cast_cast_reg_4432.read() ^ tmp_205_fu_1377_p2.read());
}

void BF_encrypt::thread_tmp_207_cast_fu_4304_p1() {
    tmp_207_cast_fu_4304_p1 = esl_zext<32,10>(tmp_207_fu_4297_p3.read());
}

void BF_encrypt::thread_tmp_207_fu_4297_p3() {
    tmp_207_fu_4297_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_205_cast_reg_5496.read());
}

void BF_encrypt::thread_tmp_208_fu_4321_p2() {
    tmp_208_fu_4321_p2 = (key_S_q0.read() ^ reg_658.read());
}

void BF_encrypt::thread_tmp_209_fu_1318_p1() {
    tmp_209_fu_1318_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_20_fu_3811_p1() {
    tmp_20_fu_3811_p1 = esl_zext<32,8>(tmp_176_reg_5366.read());
}

void BF_encrypt::thread_tmp_210_cast_fu_4316_p1() {
    tmp_210_cast_fu_4316_p1 = esl_zext<32,10>(tmp_210_fu_4309_p3.read());
}

void BF_encrypt::thread_tmp_210_fu_4309_p3() {
    tmp_210_fu_4309_p3 = esl_concat<2,8>(ap_const_lv2_3, r_14_cast_reg_5481.read());
}

void BF_encrypt::thread_tmp_211_fu_4327_p2() {
    tmp_211_fu_4327_p2 = (!key_S_q1.read().is_01() || !tmp_208_fu_4321_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_208_fu_4321_p2.read()));
}

void BF_encrypt::thread_tmp_212_fu_1397_p2() {
    tmp_212_fu_1397_p2 = (r_1_cast44_cast_reg_4427.read() ^ tmp_202_fu_1371_p2.read());
}

void BF_encrypt::thread_tmp_213_fu_1322_p1() {
    tmp_213_fu_1322_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_214_fu_1406_p2() {
    tmp_214_fu_1406_p2 = (r_1_cast_reg_4421.read() ^ tmp_201_fu_1365_p2.read());
}

void BF_encrypt::thread_tmp_215_fu_1332_p1() {
    tmp_215_fu_1332_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_216_fu_1341_p1() {
    tmp_216_fu_1341_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_217_fu_1350_p1() {
    tmp_217_fu_1350_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_218_fu_1393_p1() {
    tmp_218_fu_1393_p1 = reg_653.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_219_fu_1402_p1() {
    tmp_219_fu_1402_p1 = reg_653.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_21_cast_fu_725_p4() {
    tmp_21_cast_fu_725_p4 = l_cast_cast_fu_704_p2.read().range(23, 16);
}

void BF_encrypt::thread_tmp_21_fu_735_p3() {
    tmp_21_fu_735_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_21_cast_fu_725_p4.read());
}

void BF_encrypt::thread_tmp_220_fu_1411_p1() {
    tmp_220_fu_1411_p1 = reg_653.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_221_fu_1485_p1() {
    tmp_221_fu_1485_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_222_fu_1489_p1() {
    tmp_222_fu_1489_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_223_fu_1521_p2() {
    tmp_223_fu_1521_p2 = (!tmp_230_fu_1505_p1.read().is_01() || !tmp_228_fu_1501_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_230_fu_1505_p1.read()) + sc_biguint<8>(tmp_228_fu_1501_p1.read()));
}

void BF_encrypt::thread_tmp_224_fu_1493_p1() {
    tmp_224_fu_1493_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_225_fu_1527_p2() {
    tmp_225_fu_1527_p2 = (!tmp_226_fu_1497_p1.read().is_01() || !tmp_224_fu_1493_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_226_fu_1497_p1.read()) + sc_biguint<16>(tmp_224_fu_1493_p1.read()));
}

void BF_encrypt::thread_tmp_226_fu_1497_p1() {
    tmp_226_fu_1497_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_227_fu_1533_p2() {
    tmp_227_fu_1533_p2 = (!tmp_222_fu_1489_p1.read().is_01() || !tmp_221_fu_1485_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_222_fu_1489_p1.read()) + sc_biguint<24>(tmp_221_fu_1485_p1.read()));
}

void BF_encrypt::thread_tmp_228_fu_1501_p1() {
    tmp_228_fu_1501_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_229_fu_1573_p2() {
    tmp_229_fu_1573_p2 = (tmp_240_fu_1559_p1.read() ^ tmp_227_reg_4667.read());
}

void BF_encrypt::thread_tmp_22_fu_666_p1() {
    tmp_22_fu_666_p1 = ap_port_reg_data_0_read.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_230_fu_1505_p1() {
    tmp_230_fu_1505_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_231_fu_1582_p2() {
    tmp_231_fu_1582_p2 = (tmp_238_fu_1555_p1.read() ^ tmp_225_reg_4662.read());
}

void BF_encrypt::thread_tmp_232_fu_1551_p1() {
    tmp_232_fu_1551_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_233_fu_1591_p2() {
    tmp_233_fu_1591_p2 = (tmp_232_fu_1551_p1.read() ^ tmp_223_reg_4657.read());
}

void BF_encrypt::thread_tmp_234_fu_1602_p2() {
    tmp_234_fu_1602_p2 = (!tmp_233_fu_1591_p2.read().is_01() || !tmp_244_fu_1587_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_233_fu_1591_p2.read()) + sc_biguint<8>(tmp_244_fu_1587_p1.read()));
}

void BF_encrypt::thread_tmp_235_fu_1608_p2() {
    tmp_235_fu_1608_p2 = (!tmp_231_fu_1582_p2.read().is_01() || !tmp_243_fu_1578_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_231_fu_1582_p2.read()) + sc_biguint<16>(tmp_243_fu_1578_p1.read()));
}

void BF_encrypt::thread_tmp_236_fu_1614_p2() {
    tmp_236_fu_1614_p2 = (!tmp_229_fu_1573_p2.read().is_01() || !tmp_242_fu_1569_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_229_fu_1573_p2.read()) + sc_biguint<24>(tmp_242_fu_1569_p1.read()));
}

void BF_encrypt::thread_tmp_237_fu_1625_p2() {
    tmp_237_fu_1625_p2 = (l_2_cast_cast_reg_4543.read() ^ tmp_236_fu_1614_p2.read());
}

void BF_encrypt::thread_tmp_238_fu_1555_p1() {
    tmp_238_fu_1555_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_239_fu_1634_p2() {
    tmp_239_fu_1634_p2 = (l_2_cast42_cast_reg_4538.read() ^ tmp_235_fu_1608_p2.read());
}

void BF_encrypt::thread_tmp_23_cast_fu_743_p1() {
    tmp_23_cast_fu_743_p1 = esl_zext<32,9>(tmp_21_fu_735_p3.read());
}

void BF_encrypt::thread_tmp_23_fu_670_p1() {
    tmp_23_fu_670_p1 = key_P_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_240_fu_1559_p1() {
    tmp_240_fu_1559_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_241_fu_1643_p2() {
    tmp_241_fu_1643_p2 = (l_2_cast_reg_4532.read() ^ tmp_234_fu_1602_p2.read());
}

void BF_encrypt::thread_tmp_242_fu_1569_p1() {
    tmp_242_fu_1569_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_243_fu_1578_p1() {
    tmp_243_fu_1578_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_244_fu_1587_p1() {
    tmp_244_fu_1587_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_245_fu_1630_p1() {
    tmp_245_fu_1630_p1 = reg_640.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_246_fu_1639_p1() {
    tmp_246_fu_1639_p1 = reg_640.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_247_fu_1648_p1() {
    tmp_247_fu_1648_p1 = reg_640.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_248_fu_1722_p1() {
    tmp_248_fu_1722_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_249_fu_1726_p1() {
    tmp_249_fu_1726_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_250_fu_1758_p2() {
    tmp_250_fu_1758_p2 = (!tmp_257_fu_1742_p1.read().is_01() || !tmp_255_fu_1738_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_257_fu_1742_p1.read()) + sc_biguint<8>(tmp_255_fu_1738_p1.read()));
}

void BF_encrypt::thread_tmp_251_fu_1730_p1() {
    tmp_251_fu_1730_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_252_fu_1764_p2() {
    tmp_252_fu_1764_p2 = (!tmp_253_fu_1734_p1.read().is_01() || !tmp_251_fu_1730_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_253_fu_1734_p1.read()) + sc_biguint<16>(tmp_251_fu_1730_p1.read()));
}

void BF_encrypt::thread_tmp_253_fu_1734_p1() {
    tmp_253_fu_1734_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_254_fu_1770_p2() {
    tmp_254_fu_1770_p2 = (!tmp_249_fu_1726_p1.read().is_01() || !tmp_248_fu_1722_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_249_fu_1726_p1.read()) + sc_biguint<24>(tmp_248_fu_1722_p1.read()));
}

void BF_encrypt::thread_tmp_255_fu_1738_p1() {
    tmp_255_fu_1738_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_256_fu_1810_p2() {
    tmp_256_fu_1810_p2 = (tmp_267_fu_1796_p1.read() ^ tmp_254_reg_4738.read());
}

void BF_encrypt::thread_tmp_257_fu_1742_p1() {
    tmp_257_fu_1742_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_258_fu_1819_p2() {
    tmp_258_fu_1819_p2 = (tmp_265_fu_1792_p1.read() ^ tmp_252_reg_4733.read());
}

void BF_encrypt::thread_tmp_259_fu_1788_p1() {
    tmp_259_fu_1788_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_25_fu_674_p1() {
    tmp_25_fu_674_p1 = ap_port_reg_data_0_read.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_260_fu_1828_p2() {
    tmp_260_fu_1828_p2 = (tmp_259_fu_1788_p1.read() ^ tmp_250_reg_4728.read());
}

void BF_encrypt::thread_tmp_261_fu_1839_p2() {
    tmp_261_fu_1839_p2 = (!tmp_260_fu_1828_p2.read().is_01() || !tmp_271_fu_1824_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_260_fu_1828_p2.read()) + sc_biguint<8>(tmp_271_fu_1824_p1.read()));
}

void BF_encrypt::thread_tmp_262_fu_1845_p2() {
    tmp_262_fu_1845_p2 = (!tmp_258_fu_1819_p2.read().is_01() || !tmp_270_fu_1815_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_258_fu_1819_p2.read()) + sc_biguint<16>(tmp_270_fu_1815_p1.read()));
}

void BF_encrypt::thread_tmp_263_fu_1851_p2() {
    tmp_263_fu_1851_p2 = (!tmp_256_fu_1810_p2.read().is_01() || !tmp_269_fu_1806_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_256_fu_1810_p2.read()) + sc_biguint<24>(tmp_269_fu_1806_p1.read()));
}

void BF_encrypt::thread_tmp_264_fu_1862_p2() {
    tmp_264_fu_1862_p2 = (r_3_cast_cast_reg_4622.read() ^ tmp_263_fu_1851_p2.read());
}

void BF_encrypt::thread_tmp_265_fu_1792_p1() {
    tmp_265_fu_1792_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_266_fu_1870_p2() {
    tmp_266_fu_1870_p2 = (r_3_cast40_cast_reg_4617.read() ^ tmp_262_fu_1845_p2.read());
}

void BF_encrypt::thread_tmp_267_fu_1796_p1() {
    tmp_267_fu_1796_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_268_fu_1878_p2() {
    tmp_268_fu_1878_p2 = (r_3_cast_reg_4611.read() ^ tmp_261_fu_1839_p2.read());
}

void BF_encrypt::thread_tmp_269_fu_1806_p1() {
    tmp_269_fu_1806_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_26_fu_678_p1() {
    tmp_26_fu_678_p1 = key_P_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_270_fu_1815_p1() {
    tmp_270_fu_1815_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_271_fu_1824_p1() {
    tmp_271_fu_1824_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_272_fu_1867_p1() {
    tmp_272_fu_1867_p1 = key_P_load_5_reg_4452.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_273_fu_1875_p1() {
    tmp_273_fu_1875_p1 = key_P_load_5_reg_4452.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_274_fu_1883_p1() {
    tmp_274_fu_1883_p1 = key_P_load_5_reg_4452.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_275_fu_1955_p1() {
    tmp_275_fu_1955_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_276_fu_1959_p1() {
    tmp_276_fu_1959_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_277_fu_1991_p2() {
    tmp_277_fu_1991_p2 = (!tmp_284_fu_1975_p1.read().is_01() || !tmp_282_fu_1971_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_284_fu_1975_p1.read()) + sc_biguint<8>(tmp_282_fu_1971_p1.read()));
}

void BF_encrypt::thread_tmp_278_fu_1963_p1() {
    tmp_278_fu_1963_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_279_fu_1997_p2() {
    tmp_279_fu_1997_p2 = (!tmp_280_fu_1967_p1.read().is_01() || !tmp_278_fu_1963_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_280_fu_1967_p1.read()) + sc_biguint<16>(tmp_278_fu_1963_p1.read()));
}

void BF_encrypt::thread_tmp_27_cast_fu_789_p1() {
    tmp_27_cast_fu_789_p1 = esl_zext<32,10>(tmp_27_fu_782_p3.read());
}

void BF_encrypt::thread_tmp_27_fu_782_p3() {
    tmp_27_fu_782_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_25_cast_reg_4386.read());
}

void BF_encrypt::thread_tmp_280_fu_1967_p1() {
    tmp_280_fu_1967_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_281_fu_2003_p2() {
    tmp_281_fu_2003_p2 = (!tmp_276_fu_1959_p1.read().is_01() || !tmp_275_fu_1955_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_276_fu_1959_p1.read()) + sc_biguint<24>(tmp_275_fu_1955_p1.read()));
}

void BF_encrypt::thread_tmp_282_fu_1971_p1() {
    tmp_282_fu_1971_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_283_fu_2043_p2() {
    tmp_283_fu_2043_p2 = (tmp_294_fu_2029_p1.read() ^ tmp_281_reg_4809.read());
}

void BF_encrypt::thread_tmp_284_fu_1975_p1() {
    tmp_284_fu_1975_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_285_fu_2052_p2() {
    tmp_285_fu_2052_p2 = (tmp_292_fu_2025_p1.read() ^ tmp_279_reg_4804.read());
}

void BF_encrypt::thread_tmp_286_fu_2021_p1() {
    tmp_286_fu_2021_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_287_fu_2061_p2() {
    tmp_287_fu_2061_p2 = (tmp_286_fu_2021_p1.read() ^ tmp_277_reg_4799.read());
}

void BF_encrypt::thread_tmp_288_fu_2072_p2() {
    tmp_288_fu_2072_p2 = (!tmp_287_fu_2061_p2.read().is_01() || !tmp_298_fu_2057_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_287_fu_2061_p2.read()) + sc_biguint<8>(tmp_298_fu_2057_p1.read()));
}

void BF_encrypt::thread_tmp_289_fu_2078_p2() {
    tmp_289_fu_2078_p2 = (!tmp_285_fu_2052_p2.read().is_01() || !tmp_297_fu_2048_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_285_fu_2052_p2.read()) + sc_biguint<16>(tmp_297_fu_2048_p1.read()));
}

void BF_encrypt::thread_tmp_28_fu_836_p2() {
    tmp_28_fu_836_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_290_fu_2084_p2() {
    tmp_290_fu_2084_p2 = (!tmp_283_fu_2043_p2.read().is_01() || !tmp_296_fu_2039_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_283_fu_2043_p2.read()) + sc_biguint<24>(tmp_296_fu_2039_p1.read()));
}

void BF_encrypt::thread_tmp_291_fu_2095_p2() {
    tmp_291_fu_2095_p2 = (l_4_cast_cast_reg_4693.read() ^ tmp_290_fu_2084_p2.read());
}

void BF_encrypt::thread_tmp_292_fu_2025_p1() {
    tmp_292_fu_2025_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_293_fu_2103_p2() {
    tmp_293_fu_2103_p2 = (l_4_cast38_cast_reg_4688.read() ^ tmp_289_fu_2078_p2.read());
}

void BF_encrypt::thread_tmp_294_fu_2029_p1() {
    tmp_294_fu_2029_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_295_fu_2111_p2() {
    tmp_295_fu_2111_p2 = (l_4_cast_reg_4682.read() ^ tmp_288_fu_2072_p2.read());
}

void BF_encrypt::thread_tmp_296_fu_2039_p1() {
    tmp_296_fu_2039_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_297_fu_2048_p1() {
    tmp_297_fu_2048_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_298_fu_2057_p1() {
    tmp_298_fu_2057_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_299_fu_2100_p1() {
    tmp_299_fu_2100_p1 = key_P_load_6_reg_4470.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_29_fu_682_p1() {
    tmp_29_fu_682_p1 = ap_port_reg_data_0_read.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_2_fu_995_p1() {
    tmp_2_fu_995_p1 = esl_zext<32,8>(tmp_32_reg_4437.read());
}

void BF_encrypt::thread_tmp_300_fu_2108_p1() {
    tmp_300_fu_2108_p1 = key_P_load_6_reg_4470.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_301_fu_2116_p1() {
    tmp_301_fu_2116_p1 = key_P_load_6_reg_4470.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_302_fu_2188_p1() {
    tmp_302_fu_2188_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_303_fu_2192_p1() {
    tmp_303_fu_2192_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_304_fu_2224_p2() {
    tmp_304_fu_2224_p2 = (!tmp_311_fu_2208_p1.read().is_01() || !tmp_309_fu_2204_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_311_fu_2208_p1.read()) + sc_biguint<8>(tmp_309_fu_2204_p1.read()));
}

void BF_encrypt::thread_tmp_305_fu_2196_p1() {
    tmp_305_fu_2196_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_306_fu_2230_p2() {
    tmp_306_fu_2230_p2 = (!tmp_307_fu_2200_p1.read().is_01() || !tmp_305_fu_2196_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_307_fu_2200_p1.read()) + sc_biguint<16>(tmp_305_fu_2196_p1.read()));
}

void BF_encrypt::thread_tmp_307_fu_2200_p1() {
    tmp_307_fu_2200_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_308_fu_2236_p2() {
    tmp_308_fu_2236_p2 = (!tmp_303_fu_2192_p1.read().is_01() || !tmp_302_fu_2188_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_303_fu_2192_p1.read()) + sc_biguint<24>(tmp_302_fu_2188_p1.read()));
}

void BF_encrypt::thread_tmp_309_fu_2204_p1() {
    tmp_309_fu_2204_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_30_cast_fu_819_p1() {
    tmp_30_cast_fu_819_p1 = esl_zext<32,10>(tmp_30_fu_812_p3.read());
}

void BF_encrypt::thread_tmp_30_fu_812_p3() {
    tmp_30_fu_812_p3 = esl_concat<2,8>(ap_const_lv2_3, l_cast_reg_4360.read());
}

void BF_encrypt::thread_tmp_310_fu_2276_p2() {
    tmp_310_fu_2276_p2 = (tmp_321_fu_2262_p1.read() ^ tmp_308_reg_4880.read());
}

void BF_encrypt::thread_tmp_311_fu_2208_p1() {
    tmp_311_fu_2208_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_312_fu_2285_p2() {
    tmp_312_fu_2285_p2 = (tmp_319_fu_2258_p1.read() ^ tmp_306_reg_4875.read());
}

void BF_encrypt::thread_tmp_313_fu_2254_p1() {
    tmp_313_fu_2254_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_314_fu_2294_p2() {
    tmp_314_fu_2294_p2 = (tmp_313_fu_2254_p1.read() ^ tmp_304_reg_4870.read());
}

void BF_encrypt::thread_tmp_315_fu_2305_p2() {
    tmp_315_fu_2305_p2 = (!tmp_314_fu_2294_p2.read().is_01() || !tmp_325_fu_2290_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_314_fu_2294_p2.read()) + sc_biguint<8>(tmp_325_fu_2290_p1.read()));
}

void BF_encrypt::thread_tmp_316_fu_2311_p2() {
    tmp_316_fu_2311_p2 = (!tmp_312_fu_2285_p2.read().is_01() || !tmp_324_fu_2281_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_312_fu_2285_p2.read()) + sc_biguint<16>(tmp_324_fu_2281_p1.read()));
}

void BF_encrypt::thread_tmp_317_fu_2317_p2() {
    tmp_317_fu_2317_p2 = (!tmp_310_fu_2276_p2.read().is_01() || !tmp_323_fu_2272_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_310_fu_2276_p2.read()) + sc_biguint<24>(tmp_323_fu_2272_p1.read()));
}

void BF_encrypt::thread_tmp_318_fu_2328_p2() {
    tmp_318_fu_2328_p2 = (r_5_cast_cast_reg_4764.read() ^ tmp_317_fu_2317_p2.read());
}

void BF_encrypt::thread_tmp_319_fu_2258_p1() {
    tmp_319_fu_2258_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_31_fu_869_p2() {
    tmp_31_fu_869_p2 = (!key_S_q1.read().is_01() || !tmp_28_fu_836_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_28_fu_836_p2.read()));
}

void BF_encrypt::thread_tmp_320_fu_2336_p2() {
    tmp_320_fu_2336_p2 = (r_5_cast36_cast_reg_4759.read() ^ tmp_316_fu_2311_p2.read());
}

void BF_encrypt::thread_tmp_321_fu_2262_p1() {
    tmp_321_fu_2262_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_322_fu_2344_p2() {
    tmp_322_fu_2344_p2 = (r_5_cast_reg_4753.read() ^ tmp_315_fu_2305_p2.read());
}

void BF_encrypt::thread_tmp_323_fu_2272_p1() {
    tmp_323_fu_2272_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_324_fu_2281_p1() {
    tmp_324_fu_2281_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_325_fu_2290_p1() {
    tmp_325_fu_2290_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_326_fu_2333_p1() {
    tmp_326_fu_2333_p1 = key_P_load_7_reg_4478.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_327_fu_2341_p1() {
    tmp_327_fu_2341_p1 = key_P_load_7_reg_4478.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_328_fu_2349_p1() {
    tmp_328_fu_2349_p1 = key_P_load_7_reg_4478.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_329_fu_2421_p1() {
    tmp_329_fu_2421_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_330_fu_2425_p1() {
    tmp_330_fu_2425_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_331_fu_2457_p2() {
    tmp_331_fu_2457_p2 = (!tmp_338_fu_2441_p1.read().is_01() || !tmp_336_fu_2437_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_338_fu_2441_p1.read()) + sc_biguint<8>(tmp_336_fu_2437_p1.read()));
}

void BF_encrypt::thread_tmp_332_fu_2429_p1() {
    tmp_332_fu_2429_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_333_fu_2463_p2() {
    tmp_333_fu_2463_p2 = (!tmp_334_fu_2433_p1.read().is_01() || !tmp_332_fu_2429_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_334_fu_2433_p1.read()) + sc_biguint<16>(tmp_332_fu_2429_p1.read()));
}

void BF_encrypt::thread_tmp_334_fu_2433_p1() {
    tmp_334_fu_2433_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_335_fu_2469_p2() {
    tmp_335_fu_2469_p2 = (!tmp_330_fu_2425_p1.read().is_01() || !tmp_329_fu_2421_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_330_fu_2425_p1.read()) + sc_biguint<24>(tmp_329_fu_2421_p1.read()));
}

void BF_encrypt::thread_tmp_336_fu_2437_p1() {
    tmp_336_fu_2437_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_337_fu_2509_p2() {
    tmp_337_fu_2509_p2 = (tmp_348_fu_2495_p1.read() ^ tmp_335_reg_4951.read());
}

void BF_encrypt::thread_tmp_338_fu_2441_p1() {
    tmp_338_fu_2441_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_339_fu_2518_p2() {
    tmp_339_fu_2518_p2 = (tmp_346_fu_2491_p1.read() ^ tmp_333_reg_4946.read());
}

void BF_encrypt::thread_tmp_33_fu_758_p1() {
    tmp_33_fu_758_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_340_fu_2487_p1() {
    tmp_340_fu_2487_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_341_fu_2527_p2() {
    tmp_341_fu_2527_p2 = (tmp_340_fu_2487_p1.read() ^ tmp_331_reg_4941.read());
}

void BF_encrypt::thread_tmp_342_fu_2538_p2() {
    tmp_342_fu_2538_p2 = (!tmp_341_fu_2527_p2.read().is_01() || !tmp_352_fu_2523_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_341_fu_2527_p2.read()) + sc_biguint<8>(tmp_352_fu_2523_p1.read()));
}

void BF_encrypt::thread_tmp_343_fu_2544_p2() {
    tmp_343_fu_2544_p2 = (!tmp_339_fu_2518_p2.read().is_01() || !tmp_351_fu_2514_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_339_fu_2518_p2.read()) + sc_biguint<16>(tmp_351_fu_2514_p1.read()));
}

void BF_encrypt::thread_tmp_344_fu_2550_p2() {
    tmp_344_fu_2550_p2 = (!tmp_337_fu_2509_p2.read().is_01() || !tmp_350_fu_2505_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_337_fu_2509_p2.read()) + sc_biguint<24>(tmp_350_fu_2505_p1.read()));
}

void BF_encrypt::thread_tmp_345_fu_2561_p2() {
    tmp_345_fu_2561_p2 = (l_6_cast_cast_reg_4835.read() ^ tmp_344_fu_2550_p2.read());
}

void BF_encrypt::thread_tmp_346_fu_2491_p1() {
    tmp_346_fu_2491_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_347_fu_2569_p2() {
    tmp_347_fu_2569_p2 = (l_6_cast34_cast_reg_4830.read() ^ tmp_343_fu_2544_p2.read());
}

void BF_encrypt::thread_tmp_348_fu_2495_p1() {
    tmp_348_fu_2495_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_349_fu_2577_p2() {
    tmp_349_fu_2577_p2 = (l_6_cast_reg_4824.read() ^ tmp_342_fu_2538_p2.read());
}

void BF_encrypt::thread_tmp_34_fu_762_p1() {
    tmp_34_fu_762_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_350_fu_2505_p1() {
    tmp_350_fu_2505_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_351_fu_2514_p1() {
    tmp_351_fu_2514_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_352_fu_2523_p1() {
    tmp_352_fu_2523_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_353_fu_2566_p1() {
    tmp_353_fu_2566_p1 = key_P_load_8_reg_4511.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_354_fu_2574_p1() {
    tmp_354_fu_2574_p1 = key_P_load_8_reg_4511.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_355_fu_2582_p1() {
    tmp_355_fu_2582_p1 = key_P_load_8_reg_4511.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_356_fu_2654_p1() {
    tmp_356_fu_2654_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_357_fu_2658_p1() {
    tmp_357_fu_2658_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_358_fu_2690_p2() {
    tmp_358_fu_2690_p2 = (!tmp_365_fu_2674_p1.read().is_01() || !tmp_363_fu_2670_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_365_fu_2674_p1.read()) + sc_biguint<8>(tmp_363_fu_2670_p1.read()));
}

void BF_encrypt::thread_tmp_359_fu_2662_p1() {
    tmp_359_fu_2662_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_35_cast_fu_1006_p1() {
    tmp_35_cast_fu_1006_p1 = esl_zext<32,9>(tmp_35_fu_999_p3.read());
}

void BF_encrypt::thread_tmp_35_fu_999_p3() {
    tmp_35_fu_999_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_33_cast_reg_4442.read());
}

void BF_encrypt::thread_tmp_360_fu_2696_p2() {
    tmp_360_fu_2696_p2 = (!tmp_361_fu_2666_p1.read().is_01() || !tmp_359_fu_2662_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_361_fu_2666_p1.read()) + sc_biguint<16>(tmp_359_fu_2662_p1.read()));
}

void BF_encrypt::thread_tmp_361_fu_2666_p1() {
    tmp_361_fu_2666_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_362_fu_2702_p2() {
    tmp_362_fu_2702_p2 = (!tmp_357_fu_2658_p1.read().is_01() || !tmp_356_fu_2654_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_357_fu_2658_p1.read()) + sc_biguint<24>(tmp_356_fu_2654_p1.read()));
}

void BF_encrypt::thread_tmp_363_fu_2670_p1() {
    tmp_363_fu_2670_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_364_fu_2742_p2() {
    tmp_364_fu_2742_p2 = (tmp_375_fu_2728_p1.read() ^ tmp_362_reg_5022.read());
}

void BF_encrypt::thread_tmp_365_fu_2674_p1() {
    tmp_365_fu_2674_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_366_fu_2751_p2() {
    tmp_366_fu_2751_p2 = (tmp_373_fu_2724_p1.read() ^ tmp_360_reg_5017.read());
}

void BF_encrypt::thread_tmp_367_fu_2720_p1() {
    tmp_367_fu_2720_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_368_fu_2760_p2() {
    tmp_368_fu_2760_p2 = (tmp_367_fu_2720_p1.read() ^ tmp_358_reg_5012.read());
}

void BF_encrypt::thread_tmp_369_fu_2771_p2() {
    tmp_369_fu_2771_p2 = (!tmp_368_fu_2760_p2.read().is_01() || !tmp_379_fu_2756_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_368_fu_2760_p2.read()) + sc_biguint<8>(tmp_379_fu_2756_p1.read()));
}

void BF_encrypt::thread_tmp_370_fu_2777_p2() {
    tmp_370_fu_2777_p2 = (!tmp_366_fu_2751_p2.read().is_01() || !tmp_378_fu_2747_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_366_fu_2751_p2.read()) + sc_biguint<16>(tmp_378_fu_2747_p1.read()));
}

void BF_encrypt::thread_tmp_371_fu_2783_p2() {
    tmp_371_fu_2783_p2 = (!tmp_364_fu_2742_p2.read().is_01() || !tmp_377_fu_2738_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_364_fu_2742_p2.read()) + sc_biguint<24>(tmp_377_fu_2738_p1.read()));
}

void BF_encrypt::thread_tmp_372_fu_2794_p2() {
    tmp_372_fu_2794_p2 = (r_7_cast_cast_reg_4906.read() ^ tmp_371_fu_2783_p2.read());
}

void BF_encrypt::thread_tmp_373_fu_2724_p1() {
    tmp_373_fu_2724_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_374_fu_2802_p2() {
    tmp_374_fu_2802_p2 = (r_7_cast32_cast_reg_4901.read() ^ tmp_370_fu_2777_p2.read());
}

void BF_encrypt::thread_tmp_375_fu_2728_p1() {
    tmp_375_fu_2728_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_376_fu_2810_p2() {
    tmp_376_fu_2810_p2 = (r_7_cast_reg_4895.read() ^ tmp_369_fu_2771_p2.read());
}

void BF_encrypt::thread_tmp_377_fu_2738_p1() {
    tmp_377_fu_2738_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_378_fu_2747_p1() {
    tmp_378_fu_2747_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_379_fu_2756_p1() {
    tmp_379_fu_2756_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_37_fu_794_p2() {
    tmp_37_fu_794_p2 = (!tmp_53_fu_778_p1.read().is_01() || !tmp_49_fu_774_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_53_fu_778_p1.read()) + sc_biguint<8>(tmp_49_fu_774_p1.read()));
}

void BF_encrypt::thread_tmp_380_fu_2799_p1() {
    tmp_380_fu_2799_p1 = key_P_load_9_reg_4519.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_381_fu_2807_p1() {
    tmp_381_fu_2807_p1 = key_P_load_9_reg_4519.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_382_fu_2815_p1() {
    tmp_382_fu_2815_p1 = key_P_load_9_reg_4519.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_383_fu_2887_p1() {
    tmp_383_fu_2887_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_384_fu_2891_p1() {
    tmp_384_fu_2891_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_385_fu_2923_p2() {
    tmp_385_fu_2923_p2 = (!tmp_392_fu_2907_p1.read().is_01() || !tmp_390_fu_2903_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_392_fu_2907_p1.read()) + sc_biguint<8>(tmp_390_fu_2903_p1.read()));
}

void BF_encrypt::thread_tmp_386_fu_2895_p1() {
    tmp_386_fu_2895_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_387_fu_2929_p2() {
    tmp_387_fu_2929_p2 = (!tmp_388_fu_2899_p1.read().is_01() || !tmp_386_fu_2895_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_388_fu_2899_p1.read()) + sc_biguint<16>(tmp_386_fu_2895_p1.read()));
}

void BF_encrypt::thread_tmp_388_fu_2899_p1() {
    tmp_388_fu_2899_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_389_fu_2935_p2() {
    tmp_389_fu_2935_p2 = (!tmp_384_fu_2891_p1.read().is_01() || !tmp_383_fu_2887_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_384_fu_2891_p1.read()) + sc_biguint<24>(tmp_383_fu_2887_p1.read()));
}

void BF_encrypt::thread_tmp_38_fu_766_p1() {
    tmp_38_fu_766_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_390_fu_2903_p1() {
    tmp_390_fu_2903_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_391_fu_2975_p2() {
    tmp_391_fu_2975_p2 = (tmp_402_fu_2961_p1.read() ^ tmp_389_reg_5093.read());
}

void BF_encrypt::thread_tmp_392_fu_2907_p1() {
    tmp_392_fu_2907_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_393_fu_2984_p2() {
    tmp_393_fu_2984_p2 = (tmp_400_fu_2957_p1.read() ^ tmp_387_reg_5088.read());
}

void BF_encrypt::thread_tmp_394_fu_2953_p1() {
    tmp_394_fu_2953_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_395_fu_2993_p2() {
    tmp_395_fu_2993_p2 = (tmp_394_fu_2953_p1.read() ^ tmp_385_reg_5083.read());
}

void BF_encrypt::thread_tmp_396_fu_3004_p2() {
    tmp_396_fu_3004_p2 = (!tmp_395_fu_2993_p2.read().is_01() || !tmp_406_fu_2989_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_395_fu_2993_p2.read()) + sc_biguint<8>(tmp_406_fu_2989_p1.read()));
}

void BF_encrypt::thread_tmp_397_fu_3010_p2() {
    tmp_397_fu_3010_p2 = (!tmp_393_fu_2984_p2.read().is_01() || !tmp_405_fu_2980_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_393_fu_2984_p2.read()) + sc_biguint<16>(tmp_405_fu_2980_p1.read()));
}

void BF_encrypt::thread_tmp_398_fu_3016_p2() {
    tmp_398_fu_3016_p2 = (!tmp_391_fu_2975_p2.read().is_01() || !tmp_404_fu_2971_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_391_fu_2975_p2.read()) + sc_biguint<24>(tmp_404_fu_2971_p1.read()));
}

void BF_encrypt::thread_tmp_399_fu_3027_p2() {
    tmp_399_fu_3027_p2 = (l_8_cast_cast_reg_4977.read() ^ tmp_398_fu_3016_p2.read());
}

void BF_encrypt::thread_tmp_39_cast_fu_1042_p1() {
    tmp_39_cast_fu_1042_p1 = esl_zext<32,10>(tmp_39_fu_1035_p3.read());
}

void BF_encrypt::thread_tmp_39_fu_1035_p3() {
    tmp_39_fu_1035_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_37_cast_reg_4447.read());
}

void BF_encrypt::thread_tmp_3_fu_1232_p1() {
    tmp_3_fu_1232_p1 = esl_zext<32,8>(tmp_44_reg_4548.read());
}

void BF_encrypt::thread_tmp_400_fu_2957_p1() {
    tmp_400_fu_2957_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_401_fu_3036_p2() {
    tmp_401_fu_3036_p2 = (l_8_cast30_cast_reg_4972.read() ^ tmp_397_fu_3010_p2.read());
}

void BF_encrypt::thread_tmp_402_fu_2961_p1() {
    tmp_402_fu_2961_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_403_fu_3045_p2() {
    tmp_403_fu_3045_p2 = (l_8_cast_reg_4966.read() ^ tmp_396_fu_3004_p2.read());
}

void BF_encrypt::thread_tmp_404_fu_2971_p1() {
    tmp_404_fu_2971_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_405_fu_2980_p1() {
    tmp_405_fu_2980_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_406_fu_2989_p1() {
    tmp_406_fu_2989_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_407_fu_3032_p1() {
    tmp_407_fu_3032_p1 = reg_649.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_408_fu_3041_p1() {
    tmp_408_fu_3041_p1 = reg_649.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_409_fu_3050_p1() {
    tmp_409_fu_3050_p1 = reg_649.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_40_fu_1089_p2() {
    tmp_40_fu_1089_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_410_fu_3124_p1() {
    tmp_410_fu_3124_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_411_fu_3128_p1() {
    tmp_411_fu_3128_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_412_fu_3160_p2() {
    tmp_412_fu_3160_p2 = (!tmp_419_fu_3144_p1.read().is_01() || !tmp_417_fu_3140_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_419_fu_3144_p1.read()) + sc_biguint<8>(tmp_417_fu_3140_p1.read()));
}

void BF_encrypt::thread_tmp_413_fu_3132_p1() {
    tmp_413_fu_3132_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_414_fu_3166_p2() {
    tmp_414_fu_3166_p2 = (!tmp_415_fu_3136_p1.read().is_01() || !tmp_413_fu_3132_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_415_fu_3136_p1.read()) + sc_biguint<16>(tmp_413_fu_3132_p1.read()));
}

void BF_encrypt::thread_tmp_415_fu_3136_p1() {
    tmp_415_fu_3136_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_416_fu_3172_p2() {
    tmp_416_fu_3172_p2 = (!tmp_411_fu_3128_p1.read().is_01() || !tmp_410_fu_3124_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_411_fu_3128_p1.read()) + sc_biguint<24>(tmp_410_fu_3124_p1.read()));
}

void BF_encrypt::thread_tmp_417_fu_3140_p1() {
    tmp_417_fu_3140_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_418_fu_3212_p2() {
    tmp_418_fu_3212_p2 = (tmp_429_fu_3198_p1.read() ^ tmp_416_reg_5164.read());
}

void BF_encrypt::thread_tmp_419_fu_3144_p1() {
    tmp_419_fu_3144_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_41_fu_800_p2() {
    tmp_41_fu_800_p2 = (!tmp_45_fu_770_p1.read().is_01() || !tmp_38_fu_766_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_45_fu_770_p1.read()) + sc_biguint<16>(tmp_38_fu_766_p1.read()));
}

void BF_encrypt::thread_tmp_420_fu_3221_p2() {
    tmp_420_fu_3221_p2 = (tmp_427_fu_3194_p1.read() ^ tmp_414_reg_5159.read());
}

void BF_encrypt::thread_tmp_421_fu_3190_p1() {
    tmp_421_fu_3190_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_422_fu_3230_p2() {
    tmp_422_fu_3230_p2 = (tmp_421_fu_3190_p1.read() ^ tmp_412_reg_5154.read());
}

void BF_encrypt::thread_tmp_423_fu_3241_p2() {
    tmp_423_fu_3241_p2 = (!tmp_422_fu_3230_p2.read().is_01() || !tmp_433_fu_3226_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_422_fu_3230_p2.read()) + sc_biguint<8>(tmp_433_fu_3226_p1.read()));
}

void BF_encrypt::thread_tmp_424_fu_3247_p2() {
    tmp_424_fu_3247_p2 = (!tmp_420_fu_3221_p2.read().is_01() || !tmp_432_fu_3217_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_420_fu_3221_p2.read()) + sc_biguint<16>(tmp_432_fu_3217_p1.read()));
}

void BF_encrypt::thread_tmp_425_fu_3253_p2() {
    tmp_425_fu_3253_p2 = (!tmp_418_fu_3212_p2.read().is_01() || !tmp_431_fu_3208_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_418_fu_3212_p2.read()) + sc_biguint<24>(tmp_431_fu_3208_p1.read()));
}

void BF_encrypt::thread_tmp_426_fu_3264_p2() {
    tmp_426_fu_3264_p2 = (r_9_cast_cast_reg_5048.read() ^ tmp_425_fu_3253_p2.read());
}

void BF_encrypt::thread_tmp_427_fu_3194_p1() {
    tmp_427_fu_3194_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_428_fu_3272_p2() {
    tmp_428_fu_3272_p2 = (r_9_cast28_cast_reg_5043.read() ^ tmp_424_fu_3247_p2.read());
}

void BF_encrypt::thread_tmp_429_fu_3198_p1() {
    tmp_429_fu_3198_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_42_cast_fu_1072_p1() {
    tmp_42_cast_fu_1072_p1 = esl_zext<32,10>(tmp_42_fu_1065_p3.read());
}

void BF_encrypt::thread_tmp_42_fu_1065_p3() {
    tmp_42_fu_1065_p3 = esl_concat<2,8>(ap_const_lv2_3, r_1_cast_reg_4421.read());
}

void BF_encrypt::thread_tmp_430_fu_3280_p2() {
    tmp_430_fu_3280_p2 = (r_9_cast_reg_5037.read() ^ tmp_423_fu_3241_p2.read());
}

void BF_encrypt::thread_tmp_431_fu_3208_p1() {
    tmp_431_fu_3208_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_432_fu_3217_p1() {
    tmp_432_fu_3217_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_433_fu_3226_p1() {
    tmp_433_fu_3226_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_434_fu_3269_p1() {
    tmp_434_fu_3269_p1 = key_P_load_11_reg_4563.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_435_fu_3277_p1() {
    tmp_435_fu_3277_p1 = key_P_load_11_reg_4563.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_436_fu_3285_p1() {
    tmp_436_fu_3285_p1 = key_P_load_11_reg_4563.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_437_fu_3357_p1() {
    tmp_437_fu_3357_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_438_fu_3361_p1() {
    tmp_438_fu_3361_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_439_fu_3381_p2() {
    tmp_439_fu_3381_p2 = (!tmp_446_fu_3377_p1.read().is_01() || !tmp_444_fu_3373_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_446_fu_3377_p1.read()) + sc_biguint<8>(tmp_444_fu_3373_p1.read()));
}

void BF_encrypt::thread_tmp_43_fu_1122_p2() {
    tmp_43_fu_1122_p2 = (!key_S_q1.read().is_01() || !tmp_40_fu_1089_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_40_fu_1089_p2.read()));
}

void BF_encrypt::thread_tmp_440_fu_3365_p1() {
    tmp_440_fu_3365_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_441_fu_3387_p2() {
    tmp_441_fu_3387_p2 = (!tmp_442_fu_3369_p1.read().is_01() || !tmp_440_fu_3365_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_442_fu_3369_p1.read()) + sc_biguint<16>(tmp_440_fu_3365_p1.read()));
}

void BF_encrypt::thread_tmp_442_fu_3369_p1() {
    tmp_442_fu_3369_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_443_fu_3393_p2() {
    tmp_443_fu_3393_p2 = (!tmp_438_fu_3361_p1.read().is_01() || !tmp_437_fu_3357_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_438_fu_3361_p1.read()) + sc_biguint<24>(tmp_437_fu_3357_p1.read()));
}

void BF_encrypt::thread_tmp_444_fu_3373_p1() {
    tmp_444_fu_3373_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_445_fu_3445_p2() {
    tmp_445_fu_3445_p2 = (tmp_456_fu_3431_p1.read() ^ tmp_443_reg_5230.read());
}

void BF_encrypt::thread_tmp_446_fu_3377_p1() {
    tmp_446_fu_3377_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_447_fu_3454_p2() {
    tmp_447_fu_3454_p2 = (tmp_454_fu_3427_p1.read() ^ tmp_441_reg_5225.read());
}

void BF_encrypt::thread_tmp_448_fu_3423_p1() {
    tmp_448_fu_3423_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_449_fu_3463_p2() {
    tmp_449_fu_3463_p2 = (tmp_448_fu_3423_p1.read() ^ tmp_439_reg_5220.read());
}

void BF_encrypt::thread_tmp_450_fu_3474_p2() {
    tmp_450_fu_3474_p2 = (!tmp_449_fu_3463_p2.read().is_01() || !tmp_460_fu_3459_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_449_fu_3463_p2.read()) + sc_biguint<8>(tmp_460_fu_3459_p1.read()));
}

void BF_encrypt::thread_tmp_451_fu_3480_p2() {
    tmp_451_fu_3480_p2 = (!tmp_447_fu_3454_p2.read().is_01() || !tmp_459_fu_3450_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_447_fu_3454_p2.read()) + sc_biguint<16>(tmp_459_fu_3450_p1.read()));
}

void BF_encrypt::thread_tmp_452_fu_3486_p2() {
    tmp_452_fu_3486_p2 = (!tmp_445_fu_3445_p2.read().is_01() || !tmp_458_fu_3441_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_445_fu_3445_p2.read()) + sc_biguint<24>(tmp_458_fu_3441_p1.read()));
}

void BF_encrypt::thread_tmp_453_fu_3497_p2() {
    tmp_453_fu_3497_p2 = (l_10_cast_cast_reg_5119.read() ^ tmp_452_fu_3486_p2.read());
}

void BF_encrypt::thread_tmp_454_fu_3427_p1() {
    tmp_454_fu_3427_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_455_fu_3506_p2() {
    tmp_455_fu_3506_p2 = (l_10_cast26_cast_reg_5114.read() ^ tmp_451_fu_3480_p2.read());
}

void BF_encrypt::thread_tmp_456_fu_3431_p1() {
    tmp_456_fu_3431_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_457_fu_3515_p2() {
    tmp_457_fu_3515_p2 = (l_10_cast_reg_5108.read() ^ tmp_450_fu_3474_p2.read());
}

void BF_encrypt::thread_tmp_458_fu_3441_p1() {
    tmp_458_fu_3441_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_459_fu_3450_p1() {
    tmp_459_fu_3450_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_45_fu_770_p1() {
    tmp_45_fu_770_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_460_fu_3459_p1() {
    tmp_460_fu_3459_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_461_fu_3502_p1() {
    tmp_461_fu_3502_p1 = key_P_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_462_fu_3511_p1() {
    tmp_462_fu_3511_p1 = key_P_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_463_fu_3520_p1() {
    tmp_463_fu_3520_p1 = key_P_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_464_fu_3594_p1() {
    tmp_464_fu_3594_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_465_fu_3598_p1() {
    tmp_465_fu_3598_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_466_fu_3618_p2() {
    tmp_466_fu_3618_p2 = (!tmp_473_fu_3614_p1.read().is_01() || !tmp_471_fu_3610_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_473_fu_3614_p1.read()) + sc_biguint<8>(tmp_471_fu_3610_p1.read()));
}

void BF_encrypt::thread_tmp_467_fu_3602_p1() {
    tmp_467_fu_3602_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_468_fu_3624_p2() {
    tmp_468_fu_3624_p2 = (!tmp_469_fu_3606_p1.read().is_01() || !tmp_467_fu_3602_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_469_fu_3606_p1.read()) + sc_biguint<16>(tmp_467_fu_3602_p1.read()));
}

void BF_encrypt::thread_tmp_469_fu_3606_p1() {
    tmp_469_fu_3606_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_46_fu_806_p2() {
    tmp_46_fu_806_p2 = (!tmp_34_fu_762_p1.read().is_01() || !tmp_33_fu_758_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_34_fu_762_p1.read()) + sc_biguint<24>(tmp_33_fu_758_p1.read()));
}

void BF_encrypt::thread_tmp_470_fu_3630_p2() {
    tmp_470_fu_3630_p2 = (!tmp_465_fu_3598_p1.read().is_01() || !tmp_464_fu_3594_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_465_fu_3598_p1.read()) + sc_biguint<24>(tmp_464_fu_3594_p1.read()));
}

void BF_encrypt::thread_tmp_471_fu_3610_p1() {
    tmp_471_fu_3610_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_472_fu_3682_p2() {
    tmp_472_fu_3682_p2 = (tmp_483_fu_3668_p1.read() ^ tmp_470_reg_5330.read());
}

void BF_encrypt::thread_tmp_473_fu_3614_p1() {
    tmp_473_fu_3614_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_474_fu_3691_p2() {
    tmp_474_fu_3691_p2 = (tmp_481_fu_3664_p1.read() ^ tmp_468_reg_5325.read());
}

void BF_encrypt::thread_tmp_475_fu_3660_p1() {
    tmp_475_fu_3660_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_476_fu_3700_p2() {
    tmp_476_fu_3700_p2 = (tmp_475_fu_3660_p1.read() ^ tmp_466_reg_5320.read());
}

void BF_encrypt::thread_tmp_477_fu_3711_p2() {
    tmp_477_fu_3711_p2 = (!tmp_476_fu_3700_p2.read().is_01() || !tmp_487_fu_3696_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_476_fu_3700_p2.read()) + sc_biguint<8>(tmp_487_fu_3696_p1.read()));
}

void BF_encrypt::thread_tmp_478_fu_3717_p2() {
    tmp_478_fu_3717_p2 = (!tmp_474_fu_3691_p2.read().is_01() || !tmp_486_fu_3687_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_474_fu_3691_p2.read()) + sc_biguint<16>(tmp_486_fu_3687_p1.read()));
}

void BF_encrypt::thread_tmp_479_fu_3723_p2() {
    tmp_479_fu_3723_p2 = (!tmp_472_fu_3682_p2.read().is_01() || !tmp_485_fu_3678_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_472_fu_3682_p2.read()) + sc_biguint<24>(tmp_485_fu_3678_p1.read()));
}

void BF_encrypt::thread_tmp_47_cast_fu_1243_p1() {
    tmp_47_cast_fu_1243_p1 = esl_zext<32,9>(tmp_47_fu_1236_p3.read());
}

void BF_encrypt::thread_tmp_47_fu_1236_p3() {
    tmp_47_fu_1236_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_45_cast_reg_4553.read());
}

void BF_encrypt::thread_tmp_480_fu_3734_p2() {
    tmp_480_fu_3734_p2 = (r_10_cast_cast_reg_5190.read() ^ tmp_479_fu_3723_p2.read());
}

void BF_encrypt::thread_tmp_481_fu_3664_p1() {
    tmp_481_fu_3664_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_482_fu_3742_p2() {
    tmp_482_fu_3742_p2 = (r_10_cast24_cast_reg_5185.read() ^ tmp_478_fu_3717_p2.read());
}

void BF_encrypt::thread_tmp_483_fu_3668_p1() {
    tmp_483_fu_3668_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_484_fu_3750_p2() {
    tmp_484_fu_3750_p2 = (r_10_cast_reg_5179.read() ^ tmp_477_fu_3711_p2.read());
}

void BF_encrypt::thread_tmp_485_fu_3678_p1() {
    tmp_485_fu_3678_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_486_fu_3687_p1() {
    tmp_486_fu_3687_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_487_fu_3696_p1() {
    tmp_487_fu_3696_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_488_fu_3739_p1() {
    tmp_488_fu_3739_p1 = key_P_load_13_reg_5266.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_489_fu_3747_p1() {
    tmp_489_fu_3747_p1 = key_P_load_13_reg_5266.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_490_fu_3755_p1() {
    tmp_490_fu_3755_p1 = key_P_load_13_reg_5266.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_491_fu_3827_p1() {
    tmp_491_fu_3827_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_492_fu_3831_p1() {
    tmp_492_fu_3831_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_493_fu_3851_p2() {
    tmp_493_fu_3851_p2 = (!tmp_500_fu_3847_p1.read().is_01() || !tmp_498_fu_3843_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_500_fu_3847_p1.read()) + sc_biguint<8>(tmp_498_fu_3843_p1.read()));
}

void BF_encrypt::thread_tmp_494_fu_3835_p1() {
    tmp_494_fu_3835_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_495_fu_3857_p2() {
    tmp_495_fu_3857_p2 = (!tmp_496_fu_3839_p1.read().is_01() || !tmp_494_fu_3835_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_496_fu_3839_p1.read()) + sc_biguint<16>(tmp_494_fu_3835_p1.read()));
}

void BF_encrypt::thread_tmp_496_fu_3839_p1() {
    tmp_496_fu_3839_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_497_fu_3863_p2() {
    tmp_497_fu_3863_p2 = (!tmp_492_fu_3831_p1.read().is_01() || !tmp_491_fu_3827_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_492_fu_3831_p1.read()) + sc_biguint<24>(tmp_491_fu_3827_p1.read()));
}

void BF_encrypt::thread_tmp_498_fu_3843_p1() {
    tmp_498_fu_3843_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_499_fu_3915_p2() {
    tmp_499_fu_3915_p2 = (tmp_510_fu_3901_p1.read() ^ tmp_497_reg_5401.read());
}

void BF_encrypt::thread_tmp_49_fu_774_p1() {
    tmp_49_fu_774_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_4_fu_1469_p1() {
    tmp_4_fu_1469_p1 = esl_zext<32,8>(tmp_56_reg_4627.read());
}

void BF_encrypt::thread_tmp_500_fu_3847_p1() {
    tmp_500_fu_3847_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_501_fu_3924_p2() {
    tmp_501_fu_3924_p2 = (tmp_508_fu_3897_p1.read() ^ tmp_495_reg_5396.read());
}

void BF_encrypt::thread_tmp_502_fu_3893_p1() {
    tmp_502_fu_3893_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_503_fu_3933_p2() {
    tmp_503_fu_3933_p2 = (tmp_502_fu_3893_p1.read() ^ tmp_493_reg_5391.read());
}

void BF_encrypt::thread_tmp_504_fu_3944_p2() {
    tmp_504_fu_3944_p2 = (!tmp_503_fu_3933_p2.read().is_01() || !tmp_515_fu_3929_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_503_fu_3933_p2.read()) + sc_biguint<8>(tmp_515_fu_3929_p1.read()));
}

void BF_encrypt::thread_tmp_505_fu_3950_p2() {
    tmp_505_fu_3950_p2 = (!tmp_501_fu_3924_p2.read().is_01() || !tmp_514_fu_3920_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_501_fu_3924_p2.read()) + sc_biguint<16>(tmp_514_fu_3920_p1.read()));
}

void BF_encrypt::thread_tmp_506_fu_3956_p2() {
    tmp_506_fu_3956_p2 = (!tmp_499_fu_3915_p2.read().is_01() || !tmp_512_fu_3911_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_499_fu_3915_p2.read()) + sc_biguint<24>(tmp_512_fu_3911_p1.read()));
}

void BF_encrypt::thread_tmp_507_fu_3967_p2() {
    tmp_507_fu_3967_p2 = (l_11_cast_cast_reg_5261.read() ^ tmp_506_fu_3956_p2.read());
}

void BF_encrypt::thread_tmp_508_fu_3897_p1() {
    tmp_508_fu_3897_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_509_fu_3975_p2() {
    tmp_509_fu_3975_p2 = (l_11_cast22_cast_reg_5256.read() ^ tmp_505_fu_3950_p2.read());
}

void BF_encrypt::thread_tmp_50_fu_846_p2() {
    tmp_50_fu_846_p2 = (tmp_70_fu_832_p1.read() ^ tmp_46_reg_4406.read());
}

void BF_encrypt::thread_tmp_510_fu_3901_p1() {
    tmp_510_fu_3901_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_511_fu_3983_p2() {
    tmp_511_fu_3983_p2 = (l_11_cast_reg_5250.read() ^ tmp_504_fu_3944_p2.read());
}

void BF_encrypt::thread_tmp_512_fu_3911_p1() {
    tmp_512_fu_3911_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_513_fu_4044_p1() {
    tmp_513_fu_4044_p1 = esl_zext<32,8>(tmp_188_reg_5426.read());
}

void BF_encrypt::thread_tmp_514_fu_3920_p1() {
    tmp_514_fu_3920_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_515_fu_3929_p1() {
    tmp_515_fu_3929_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_516_fu_3972_p1() {
    tmp_516_fu_3972_p1 = key_P_load_14_reg_5289.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_517_fu_3980_p1() {
    tmp_517_fu_3980_p1 = key_P_load_14_reg_5289.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_518_fu_3988_p1() {
    tmp_518_fu_3988_p1 = key_P_load_14_reg_5289.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_519_fu_4060_p1() {
    tmp_519_fu_4060_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_51_cast_fu_1279_p1() {
    tmp_51_cast_fu_1279_p1 = esl_zext<32,10>(tmp_51_fu_1272_p3.read());
}

void BF_encrypt::thread_tmp_51_fu_1272_p3() {
    tmp_51_fu_1272_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_49_cast_reg_4558.read());
}

void BF_encrypt::thread_tmp_520_fu_4064_p1() {
    tmp_520_fu_4064_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_521_fu_4084_p2() {
    tmp_521_fu_4084_p2 = (!tmp_528_fu_4080_p1.read().is_01() || !tmp_526_fu_4076_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_528_fu_4080_p1.read()) + sc_biguint<8>(tmp_526_fu_4076_p1.read()));
}

void BF_encrypt::thread_tmp_522_fu_4068_p1() {
    tmp_522_fu_4068_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_523_fu_4090_p2() {
    tmp_523_fu_4090_p2 = (!tmp_524_fu_4072_p1.read().is_01() || !tmp_522_fu_4068_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_524_fu_4072_p1.read()) + sc_biguint<16>(tmp_522_fu_4068_p1.read()));
}

void BF_encrypt::thread_tmp_524_fu_4072_p1() {
    tmp_524_fu_4072_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_525_fu_4096_p2() {
    tmp_525_fu_4096_p2 = (!tmp_520_fu_4064_p1.read().is_01() || !tmp_519_fu_4060_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_520_fu_4064_p1.read()) + sc_biguint<24>(tmp_519_fu_4060_p1.read()));
}

void BF_encrypt::thread_tmp_526_fu_4076_p1() {
    tmp_526_fu_4076_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_527_fu_4148_p2() {
    tmp_527_fu_4148_p2 = (tmp_538_fu_4134_p1.read() ^ tmp_525_reg_5461.read());
}

void BF_encrypt::thread_tmp_528_fu_4080_p1() {
    tmp_528_fu_4080_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_529_fu_4157_p2() {
    tmp_529_fu_4157_p2 = (tmp_536_fu_4130_p1.read() ^ tmp_523_reg_5456.read());
}

void BF_encrypt::thread_tmp_52_fu_1326_p2() {
    tmp_52_fu_1326_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_530_fu_4126_p1() {
    tmp_530_fu_4126_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_531_fu_4166_p2() {
    tmp_531_fu_4166_p2 = (tmp_530_fu_4126_p1.read() ^ tmp_521_reg_5451.read());
}

void BF_encrypt::thread_tmp_532_fu_4177_p2() {
    tmp_532_fu_4177_p2 = (!tmp_531_fu_4166_p2.read().is_01() || !tmp_543_fu_4162_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_531_fu_4166_p2.read()) + sc_biguint<8>(tmp_543_fu_4162_p1.read()));
}

void BF_encrypt::thread_tmp_533_fu_4183_p2() {
    tmp_533_fu_4183_p2 = (!tmp_529_fu_4157_p2.read().is_01() || !tmp_542_fu_4153_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_529_fu_4157_p2.read()) + sc_biguint<16>(tmp_542_fu_4153_p1.read()));
}

void BF_encrypt::thread_tmp_534_fu_4189_p2() {
    tmp_534_fu_4189_p2 = (!tmp_527_fu_4148_p2.read().is_01() || !tmp_540_fu_4144_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_527_fu_4148_p2.read()) + sc_biguint<24>(tmp_540_fu_4144_p1.read()));
}

void BF_encrypt::thread_tmp_535_fu_4200_p2() {
    tmp_535_fu_4200_p2 = (r_12_cast_cast_reg_5361.read() ^ tmp_534_fu_4189_p2.read());
}

void BF_encrypt::thread_tmp_536_fu_4130_p1() {
    tmp_536_fu_4130_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_537_fu_4208_p2() {
    tmp_537_fu_4208_p2 = (r_12_cast20_cast_reg_5356.read() ^ tmp_533_fu_4183_p2.read());
}

void BF_encrypt::thread_tmp_538_fu_4134_p1() {
    tmp_538_fu_4134_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_539_fu_4216_p2() {
    tmp_539_fu_4216_p2 = (r_12_cast_reg_5350.read() ^ tmp_532_fu_4177_p2.read());
}

void BF_encrypt::thread_tmp_53_fu_778_p1() {
    tmp_53_fu_778_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_540_fu_4144_p1() {
    tmp_540_fu_4144_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_541_fu_4281_p1() {
    tmp_541_fu_4281_p1 = esl_zext<32,8>(tmp_200_reg_5486.read());
}

void BF_encrypt::thread_tmp_542_fu_4153_p1() {
    tmp_542_fu_4153_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_543_fu_4162_p1() {
    tmp_543_fu_4162_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_544_fu_4205_p1() {
    tmp_544_fu_4205_p1 = key_P_load_15_reg_5297.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_545_fu_4213_p1() {
    tmp_545_fu_4213_p1 = key_P_load_15_reg_5297.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_546_fu_4221_p1() {
    tmp_546_fu_4221_p1 = key_P_load_15_reg_5297.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_54_cast_fu_1309_p1() {
    tmp_54_cast_fu_1309_p1 = esl_zext<32,10>(tmp_54_fu_1302_p3.read());
}

void BF_encrypt::thread_tmp_54_fu_1302_p3() {
    tmp_54_fu_1302_p3 = esl_concat<2,8>(ap_const_lv2_3, l_2_cast_reg_4532.read());
}

void BF_encrypt::thread_tmp_55_fu_1359_p2() {
    tmp_55_fu_1359_p2 = (!key_S_q1.read().is_01() || !tmp_52_fu_1326_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_52_fu_1326_p2.read()));
}

void BF_encrypt::thread_tmp_57_fu_855_p2() {
    tmp_57_fu_855_p2 = (tmp_65_fu_828_p1.read() ^ tmp_41_reg_4401.read());
}

void BF_encrypt::thread_tmp_58_fu_824_p1() {
    tmp_58_fu_824_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_59_cast_fu_1480_p1() {
    tmp_59_cast_fu_1480_p1 = esl_zext<32,9>(tmp_59_fu_1473_p3.read());
}

void BF_encrypt::thread_tmp_59_fu_1473_p3() {
    tmp_59_fu_1473_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_57_cast_reg_4632.read());
}

void BF_encrypt::thread_tmp_5_fu_1706_p1() {
    tmp_5_fu_1706_p1 = esl_zext<32,8>(tmp_68_reg_4698.read());
}

void BF_encrypt::thread_tmp_61_fu_864_p2() {
    tmp_61_fu_864_p2 = (tmp_58_fu_824_p1.read() ^ tmp_37_reg_4396.read());
}

void BF_encrypt::thread_tmp_62_fu_875_p2() {
    tmp_62_fu_875_p2 = (!tmp_61_fu_864_p2.read().is_01() || !tmp_85_fu_860_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(tmp_61_fu_864_p2.read()) + sc_biguint<8>(tmp_85_fu_860_p1.read()));
}

void BF_encrypt::thread_tmp_63_cast_fu_1516_p1() {
    tmp_63_cast_fu_1516_p1 = esl_zext<32,10>(tmp_63_fu_1509_p3.read());
}

void BF_encrypt::thread_tmp_63_fu_1509_p3() {
    tmp_63_fu_1509_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_61_cast_reg_4637.read());
}

void BF_encrypt::thread_tmp_64_fu_1563_p2() {
    tmp_64_fu_1563_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_65_fu_828_p1() {
    tmp_65_fu_828_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_66_cast_fu_1546_p1() {
    tmp_66_cast_fu_1546_p1 = esl_zext<32,10>(tmp_66_fu_1539_p3.read());
}

void BF_encrypt::thread_tmp_66_fu_1539_p3() {
    tmp_66_fu_1539_p3 = esl_concat<2,8>(ap_const_lv2_3, r_3_cast_reg_4611.read());
}

void BF_encrypt::thread_tmp_67_fu_1596_p2() {
    tmp_67_fu_1596_p2 = (!key_S_q1.read().is_01() || !tmp_64_fu_1563_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_64_fu_1563_p2.read()));
}

void BF_encrypt::thread_tmp_69_fu_885_p2() {
    tmp_69_fu_885_p2 = (!tmp_57_fu_855_p2.read().is_01() || !tmp_81_fu_851_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(tmp_57_fu_855_p2.read()) + sc_biguint<16>(tmp_81_fu_851_p1.read()));
}

void BF_encrypt::thread_tmp_6_fu_1939_p1() {
    tmp_6_fu_1939_p1 = esl_zext<32,8>(tmp_80_reg_4769.read());
}

void BF_encrypt::thread_tmp_70_fu_832_p1() {
    tmp_70_fu_832_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_71_cast_fu_1717_p1() {
    tmp_71_cast_fu_1717_p1 = esl_zext<32,9>(tmp_71_fu_1710_p3.read());
}

void BF_encrypt::thread_tmp_71_fu_1710_p3() {
    tmp_71_fu_1710_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_69_cast_reg_4703.read());
}

void BF_encrypt::thread_tmp_73_fu_895_p2() {
    tmp_73_fu_895_p2 = (!tmp_50_fu_846_p2.read().is_01() || !tmp_74_fu_842_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(tmp_50_fu_846_p2.read()) + sc_biguint<24>(tmp_74_fu_842_p1.read()));
}

void BF_encrypt::thread_tmp_74_fu_842_p1() {
    tmp_74_fu_842_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_75_cast_fu_1753_p1() {
    tmp_75_cast_fu_1753_p1 = esl_zext<32,10>(tmp_75_fu_1746_p3.read());
}

void BF_encrypt::thread_tmp_75_fu_1746_p3() {
    tmp_75_fu_1746_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_73_cast_reg_4708.read());
}

void BF_encrypt::thread_tmp_76_fu_1800_p2() {
    tmp_76_fu_1800_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_77_fu_911_p2() {
    tmp_77_fu_911_p2 = (tmp_73_fu_895_p2.read() ^ tmp_94_fu_901_p1.read());
}

void BF_encrypt::thread_tmp_78_cast_fu_1783_p1() {
    tmp_78_cast_fu_1783_p1 = esl_zext<32,10>(tmp_78_fu_1776_p3.read());
}

void BF_encrypt::thread_tmp_78_fu_1776_p3() {
    tmp_78_fu_1776_p3 = esl_concat<2,8>(ap_const_lv2_3, l_4_cast_reg_4682.read());
}

void BF_encrypt::thread_tmp_79_fu_1833_p2() {
    tmp_79_fu_1833_p2 = (!key_S_q1.read().is_01() || !tmp_76_fu_1800_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_76_fu_1800_p2.read()));
}

void BF_encrypt::thread_tmp_7_fu_2172_p1() {
    tmp_7_fu_2172_p1 = esl_zext<32,8>(tmp_92_reg_4840.read());
}

void BF_encrypt::thread_tmp_81_fu_851_p1() {
    tmp_81_fu_851_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_82_fu_921_p2() {
    tmp_82_fu_921_p2 = (tmp_69_fu_885_p2.read() ^ tmp_93_fu_891_p1.read());
}

void BF_encrypt::thread_tmp_83_cast_fu_1950_p1() {
    tmp_83_cast_fu_1950_p1 = esl_zext<32,9>(tmp_83_fu_1943_p3.read());
}

void BF_encrypt::thread_tmp_83_fu_1943_p3() {
    tmp_83_fu_1943_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_81_cast_reg_4774.read());
}

void BF_encrypt::thread_tmp_85_fu_860_p1() {
    tmp_85_fu_860_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_86_fu_931_p2() {
    tmp_86_fu_931_p2 = (tmp_62_fu_875_p2.read() ^ tmp_89_fu_881_p1.read());
}

void BF_encrypt::thread_tmp_87_cast_fu_1986_p1() {
    tmp_87_cast_fu_1986_p1 = esl_zext<32,10>(tmp_87_fu_1979_p3.read());
}

void BF_encrypt::thread_tmp_87_fu_1979_p3() {
    tmp_87_fu_1979_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_85_cast_reg_4779.read());
}

void BF_encrypt::thread_tmp_88_fu_2033_p2() {
    tmp_88_fu_2033_p2 = (key_S_q0.read() ^ reg_645.read());
}

void BF_encrypt::thread_tmp_89_fu_881_p1() {
    tmp_89_fu_881_p1 = ap_port_reg_data_1_read.read().range(8-1, 0);
}

void BF_encrypt::thread_tmp_8_fu_2405_p1() {
    tmp_8_fu_2405_p1 = esl_zext<32,8>(tmp_104_reg_4911.read());
}

void BF_encrypt::thread_tmp_90_cast_fu_2016_p1() {
    tmp_90_cast_fu_2016_p1 = esl_zext<32,10>(tmp_90_fu_2009_p3.read());
}

void BF_encrypt::thread_tmp_90_fu_2009_p3() {
    tmp_90_fu_2009_p3 = esl_concat<2,8>(ap_const_lv2_3, r_5_cast_reg_4753.read());
}

void BF_encrypt::thread_tmp_91_fu_2066_p2() {
    tmp_91_fu_2066_p2 = (!key_S_q1.read().is_01() || !tmp_88_fu_2033_p2.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q1.read()) + sc_biguint<32>(tmp_88_fu_2033_p2.read()));
}

void BF_encrypt::thread_tmp_93_fu_891_p1() {
    tmp_93_fu_891_p1 = ap_port_reg_data_1_read.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_94_fu_901_p1() {
    tmp_94_fu_901_p1 = ap_port_reg_data_1_read.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_95_cast_fu_2183_p1() {
    tmp_95_cast_fu_2183_p1 = esl_zext<32,9>(tmp_95_fu_2176_p3.read());
}

void BF_encrypt::thread_tmp_95_fu_2176_p3() {
    tmp_95_fu_2176_p3 = esl_concat<1,8>(ap_const_lv1_1, tmp_93_cast_reg_4845.read());
}

void BF_encrypt::thread_tmp_97_fu_917_p1() {
    tmp_97_fu_917_p1 = reg_640.read().range(24-1, 0);
}

void BF_encrypt::thread_tmp_98_fu_927_p1() {
    tmp_98_fu_927_p1 = reg_640.read().range(16-1, 0);
}

void BF_encrypt::thread_tmp_99_cast_fu_2219_p1() {
    tmp_99_cast_fu_2219_p1 = esl_zext<32,10>(tmp_99_fu_2212_p3.read());
}

void BF_encrypt::thread_tmp_99_fu_2212_p3() {
    tmp_99_fu_2212_p3 = esl_concat<2,8>(ap_const_lv2_2, tmp_97_cast_reg_4850.read());
}

void BF_encrypt::thread_tmp_9_fu_2638_p1() {
    tmp_9_fu_2638_p1 = esl_zext<32,8>(tmp_116_reg_4982.read());
}

void BF_encrypt::thread_tmp_fu_905_p2() {
    tmp_fu_905_p2 = (tmp_31_fu_869_p2.read() ^ ap_port_reg_data_1_read.read());
}

void BF_encrypt::thread_tmp_s_fu_710_p4() {
    tmp_s_fu_710_p4 = l_fu_686_p2.read().range(31, 24);
}

}

