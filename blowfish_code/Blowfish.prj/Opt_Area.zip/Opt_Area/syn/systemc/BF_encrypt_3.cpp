#include "BF_encrypt.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void BF_encrypt::thread_add_ln100_1_fu_1837_p2() {
    add_ln100_1_fu_1837_p2 = (!xor_ln100_fu_1804_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln100_fu_1804_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln100_2_fu_1762_p2() {
    add_ln100_2_fu_1762_p2 = (!trunc_ln100_5_fu_1746_p1.read().is_01() || !trunc_ln100_4_fu_1742_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln100_5_fu_1746_p1.read()) + sc_biguint<16>(trunc_ln100_4_fu_1742_p1.read()));
}

void BF_encrypt::thread_add_ln100_3_fu_1768_p2() {
    add_ln100_3_fu_1768_p2 = (!trunc_ln100_3_fu_1738_p1.read().is_01() || !trunc_ln100_2_fu_1734_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln100_3_fu_1738_p1.read()) + sc_biguint<24>(trunc_ln100_2_fu_1734_p1.read()));
}

void BF_encrypt::thread_add_ln100_4_fu_1774_p2() {
    add_ln100_4_fu_1774_p2 = (!trunc_ln100_1_fu_1730_p1.read().is_01() || !trunc_ln100_fu_1726_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln100_1_fu_1730_p1.read()) + sc_biguint<8>(trunc_ln100_fu_1726_p1.read()));
}

void BF_encrypt::thread_add_ln100_5_fu_1843_p2() {
    add_ln100_5_fu_1843_p2 = (!trunc_ln100_12_fu_1833_p1.read().is_01() || !xor_ln100_3_fu_1828_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln100_12_fu_1833_p1.read()) + sc_biguint<16>(xor_ln100_3_fu_1828_p2.read()));
}

void BF_encrypt::thread_add_ln100_6_fu_1849_p2() {
    add_ln100_6_fu_1849_p2 = (!trunc_ln100_11_fu_1824_p1.read().is_01() || !xor_ln100_2_fu_1819_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln100_11_fu_1824_p1.read()) + sc_biguint<24>(xor_ln100_2_fu_1819_p2.read()));
}

void BF_encrypt::thread_add_ln100_7_fu_1855_p2() {
    add_ln100_7_fu_1855_p2 = (!trunc_ln100_10_fu_1815_p1.read().is_01() || !xor_ln100_1_fu_1810_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln100_10_fu_1815_p1.read()) + sc_biguint<8>(xor_ln100_1_fu_1810_p2.read()));
}

void BF_encrypt::thread_add_ln101_1_fu_2070_p2() {
    add_ln101_1_fu_2070_p2 = (!xor_ln101_fu_2037_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln101_fu_2037_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln101_2_fu_1995_p2() {
    add_ln101_2_fu_1995_p2 = (!trunc_ln101_5_fu_1979_p1.read().is_01() || !trunc_ln101_4_fu_1975_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln101_5_fu_1979_p1.read()) + sc_biguint<16>(trunc_ln101_4_fu_1975_p1.read()));
}

void BF_encrypt::thread_add_ln101_3_fu_2001_p2() {
    add_ln101_3_fu_2001_p2 = (!trunc_ln101_3_fu_1971_p1.read().is_01() || !trunc_ln101_2_fu_1967_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln101_3_fu_1971_p1.read()) + sc_biguint<24>(trunc_ln101_2_fu_1967_p1.read()));
}

void BF_encrypt::thread_add_ln101_4_fu_2007_p2() {
    add_ln101_4_fu_2007_p2 = (!trunc_ln101_1_fu_1963_p1.read().is_01() || !trunc_ln101_fu_1959_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln101_1_fu_1963_p1.read()) + sc_biguint<8>(trunc_ln101_fu_1959_p1.read()));
}

void BF_encrypt::thread_add_ln101_5_fu_2076_p2() {
    add_ln101_5_fu_2076_p2 = (!trunc_ln101_12_fu_2066_p1.read().is_01() || !xor_ln101_3_fu_2061_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln101_12_fu_2066_p1.read()) + sc_biguint<16>(xor_ln101_3_fu_2061_p2.read()));
}

void BF_encrypt::thread_add_ln101_6_fu_2082_p2() {
    add_ln101_6_fu_2082_p2 = (!trunc_ln101_11_fu_2057_p1.read().is_01() || !xor_ln101_2_fu_2052_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln101_11_fu_2057_p1.read()) + sc_biguint<24>(xor_ln101_2_fu_2052_p2.read()));
}

void BF_encrypt::thread_add_ln101_7_fu_2088_p2() {
    add_ln101_7_fu_2088_p2 = (!trunc_ln101_10_fu_2048_p1.read().is_01() || !xor_ln101_1_fu_2043_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln101_10_fu_2048_p1.read()) + sc_biguint<8>(xor_ln101_1_fu_2043_p2.read()));
}

void BF_encrypt::thread_add_ln102_1_fu_2303_p2() {
    add_ln102_1_fu_2303_p2 = (!xor_ln102_fu_2270_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln102_fu_2270_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln102_2_fu_2228_p2() {
    add_ln102_2_fu_2228_p2 = (!trunc_ln102_5_fu_2212_p1.read().is_01() || !trunc_ln102_4_fu_2208_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln102_5_fu_2212_p1.read()) + sc_biguint<16>(trunc_ln102_4_fu_2208_p1.read()));
}

void BF_encrypt::thread_add_ln102_3_fu_2234_p2() {
    add_ln102_3_fu_2234_p2 = (!trunc_ln102_3_fu_2204_p1.read().is_01() || !trunc_ln102_2_fu_2200_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln102_3_fu_2204_p1.read()) + sc_biguint<24>(trunc_ln102_2_fu_2200_p1.read()));
}

void BF_encrypt::thread_add_ln102_4_fu_2240_p2() {
    add_ln102_4_fu_2240_p2 = (!trunc_ln102_1_fu_2196_p1.read().is_01() || !trunc_ln102_fu_2192_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln102_1_fu_2196_p1.read()) + sc_biguint<8>(trunc_ln102_fu_2192_p1.read()));
}

void BF_encrypt::thread_add_ln102_5_fu_2309_p2() {
    add_ln102_5_fu_2309_p2 = (!trunc_ln102_12_fu_2299_p1.read().is_01() || !xor_ln102_3_fu_2294_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln102_12_fu_2299_p1.read()) + sc_biguint<16>(xor_ln102_3_fu_2294_p2.read()));
}

void BF_encrypt::thread_add_ln102_6_fu_2315_p2() {
    add_ln102_6_fu_2315_p2 = (!trunc_ln102_11_fu_2290_p1.read().is_01() || !xor_ln102_2_fu_2285_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln102_11_fu_2290_p1.read()) + sc_biguint<24>(xor_ln102_2_fu_2285_p2.read()));
}

void BF_encrypt::thread_add_ln102_7_fu_2321_p2() {
    add_ln102_7_fu_2321_p2 = (!trunc_ln102_10_fu_2281_p1.read().is_01() || !xor_ln102_1_fu_2276_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln102_10_fu_2281_p1.read()) + sc_biguint<8>(xor_ln102_1_fu_2276_p2.read()));
}

void BF_encrypt::thread_add_ln103_1_fu_2536_p2() {
    add_ln103_1_fu_2536_p2 = (!xor_ln103_fu_2503_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln103_fu_2503_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln103_2_fu_2461_p2() {
    add_ln103_2_fu_2461_p2 = (!trunc_ln103_5_fu_2445_p1.read().is_01() || !trunc_ln103_4_fu_2441_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln103_5_fu_2445_p1.read()) + sc_biguint<16>(trunc_ln103_4_fu_2441_p1.read()));
}

void BF_encrypt::thread_add_ln103_3_fu_2467_p2() {
    add_ln103_3_fu_2467_p2 = (!trunc_ln103_3_fu_2437_p1.read().is_01() || !trunc_ln103_2_fu_2433_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln103_3_fu_2437_p1.read()) + sc_biguint<24>(trunc_ln103_2_fu_2433_p1.read()));
}

void BF_encrypt::thread_add_ln103_4_fu_2473_p2() {
    add_ln103_4_fu_2473_p2 = (!trunc_ln103_1_fu_2429_p1.read().is_01() || !trunc_ln103_fu_2425_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln103_1_fu_2429_p1.read()) + sc_biguint<8>(trunc_ln103_fu_2425_p1.read()));
}

void BF_encrypt::thread_add_ln103_5_fu_2542_p2() {
    add_ln103_5_fu_2542_p2 = (!trunc_ln103_12_fu_2532_p1.read().is_01() || !xor_ln103_3_fu_2527_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln103_12_fu_2532_p1.read()) + sc_biguint<16>(xor_ln103_3_fu_2527_p2.read()));
}

void BF_encrypt::thread_add_ln103_6_fu_2548_p2() {
    add_ln103_6_fu_2548_p2 = (!trunc_ln103_11_fu_2523_p1.read().is_01() || !xor_ln103_2_fu_2518_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln103_11_fu_2523_p1.read()) + sc_biguint<24>(xor_ln103_2_fu_2518_p2.read()));
}

void BF_encrypt::thread_add_ln103_7_fu_2554_p2() {
    add_ln103_7_fu_2554_p2 = (!trunc_ln103_10_fu_2514_p1.read().is_01() || !xor_ln103_1_fu_2509_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln103_10_fu_2514_p1.read()) + sc_biguint<8>(xor_ln103_1_fu_2509_p2.read()));
}

void BF_encrypt::thread_add_ln104_1_fu_2769_p2() {
    add_ln104_1_fu_2769_p2 = (!xor_ln104_fu_2736_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln104_fu_2736_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln104_2_fu_2694_p2() {
    add_ln104_2_fu_2694_p2 = (!trunc_ln104_5_fu_2678_p1.read().is_01() || !trunc_ln104_4_fu_2674_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln104_5_fu_2678_p1.read()) + sc_biguint<16>(trunc_ln104_4_fu_2674_p1.read()));
}

void BF_encrypt::thread_add_ln104_3_fu_2700_p2() {
    add_ln104_3_fu_2700_p2 = (!trunc_ln104_3_fu_2670_p1.read().is_01() || !trunc_ln104_2_fu_2666_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln104_3_fu_2670_p1.read()) + sc_biguint<24>(trunc_ln104_2_fu_2666_p1.read()));
}

void BF_encrypt::thread_add_ln104_4_fu_2706_p2() {
    add_ln104_4_fu_2706_p2 = (!trunc_ln104_1_fu_2662_p1.read().is_01() || !trunc_ln104_fu_2658_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln104_1_fu_2662_p1.read()) + sc_biguint<8>(trunc_ln104_fu_2658_p1.read()));
}

void BF_encrypt::thread_add_ln104_5_fu_2775_p2() {
    add_ln104_5_fu_2775_p2 = (!trunc_ln104_12_fu_2765_p1.read().is_01() || !xor_ln104_3_fu_2760_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln104_12_fu_2765_p1.read()) + sc_biguint<16>(xor_ln104_3_fu_2760_p2.read()));
}

void BF_encrypt::thread_add_ln104_6_fu_2781_p2() {
    add_ln104_6_fu_2781_p2 = (!trunc_ln104_11_fu_2756_p1.read().is_01() || !xor_ln104_2_fu_2751_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln104_11_fu_2756_p1.read()) + sc_biguint<24>(xor_ln104_2_fu_2751_p2.read()));
}

void BF_encrypt::thread_add_ln104_7_fu_2787_p2() {
    add_ln104_7_fu_2787_p2 = (!trunc_ln104_10_fu_2747_p1.read().is_01() || !xor_ln104_1_fu_2742_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln104_10_fu_2747_p1.read()) + sc_biguint<8>(xor_ln104_1_fu_2742_p2.read()));
}

void BF_encrypt::thread_add_ln105_1_fu_3002_p2() {
    add_ln105_1_fu_3002_p2 = (!xor_ln105_fu_2969_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln105_fu_2969_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln105_2_fu_2927_p2() {
    add_ln105_2_fu_2927_p2 = (!trunc_ln105_5_fu_2911_p1.read().is_01() || !trunc_ln105_4_fu_2907_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln105_5_fu_2911_p1.read()) + sc_biguint<16>(trunc_ln105_4_fu_2907_p1.read()));
}

void BF_encrypt::thread_add_ln105_3_fu_2933_p2() {
    add_ln105_3_fu_2933_p2 = (!trunc_ln105_3_fu_2903_p1.read().is_01() || !trunc_ln105_2_fu_2899_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln105_3_fu_2903_p1.read()) + sc_biguint<24>(trunc_ln105_2_fu_2899_p1.read()));
}

void BF_encrypt::thread_add_ln105_4_fu_2939_p2() {
    add_ln105_4_fu_2939_p2 = (!trunc_ln105_1_fu_2895_p1.read().is_01() || !trunc_ln105_fu_2891_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln105_1_fu_2895_p1.read()) + sc_biguint<8>(trunc_ln105_fu_2891_p1.read()));
}

void BF_encrypt::thread_add_ln105_5_fu_3008_p2() {
    add_ln105_5_fu_3008_p2 = (!trunc_ln105_12_fu_2998_p1.read().is_01() || !xor_ln105_3_fu_2993_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln105_12_fu_2998_p1.read()) + sc_biguint<16>(xor_ln105_3_fu_2993_p2.read()));
}

void BF_encrypt::thread_add_ln105_6_fu_3014_p2() {
    add_ln105_6_fu_3014_p2 = (!trunc_ln105_11_fu_2989_p1.read().is_01() || !xor_ln105_2_fu_2984_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln105_11_fu_2989_p1.read()) + sc_biguint<24>(xor_ln105_2_fu_2984_p2.read()));
}

void BF_encrypt::thread_add_ln105_7_fu_3020_p2() {
    add_ln105_7_fu_3020_p2 = (!trunc_ln105_10_fu_2980_p1.read().is_01() || !xor_ln105_1_fu_2975_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln105_10_fu_2980_p1.read()) + sc_biguint<8>(xor_ln105_1_fu_2975_p2.read()));
}

void BF_encrypt::thread_add_ln106_1_fu_3239_p2() {
    add_ln106_1_fu_3239_p2 = (!xor_ln106_fu_3206_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln106_fu_3206_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln106_2_fu_3164_p2() {
    add_ln106_2_fu_3164_p2 = (!trunc_ln106_5_fu_3148_p1.read().is_01() || !trunc_ln106_4_fu_3144_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln106_5_fu_3148_p1.read()) + sc_biguint<16>(trunc_ln106_4_fu_3144_p1.read()));
}

void BF_encrypt::thread_add_ln106_3_fu_3170_p2() {
    add_ln106_3_fu_3170_p2 = (!trunc_ln106_3_fu_3140_p1.read().is_01() || !trunc_ln106_2_fu_3136_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln106_3_fu_3140_p1.read()) + sc_biguint<24>(trunc_ln106_2_fu_3136_p1.read()));
}

void BF_encrypt::thread_add_ln106_4_fu_3176_p2() {
    add_ln106_4_fu_3176_p2 = (!trunc_ln106_1_fu_3132_p1.read().is_01() || !trunc_ln106_fu_3128_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln106_1_fu_3132_p1.read()) + sc_biguint<8>(trunc_ln106_fu_3128_p1.read()));
}

void BF_encrypt::thread_add_ln106_5_fu_3245_p2() {
    add_ln106_5_fu_3245_p2 = (!trunc_ln106_12_fu_3235_p1.read().is_01() || !xor_ln106_3_fu_3230_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln106_12_fu_3235_p1.read()) + sc_biguint<16>(xor_ln106_3_fu_3230_p2.read()));
}

void BF_encrypt::thread_add_ln106_6_fu_3251_p2() {
    add_ln106_6_fu_3251_p2 = (!trunc_ln106_11_fu_3226_p1.read().is_01() || !xor_ln106_2_fu_3221_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln106_11_fu_3226_p1.read()) + sc_biguint<24>(xor_ln106_2_fu_3221_p2.read()));
}

void BF_encrypt::thread_add_ln106_7_fu_3257_p2() {
    add_ln106_7_fu_3257_p2 = (!trunc_ln106_10_fu_3217_p1.read().is_01() || !xor_ln106_1_fu_3212_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln106_10_fu_3217_p1.read()) + sc_biguint<8>(xor_ln106_1_fu_3212_p2.read()));
}

void BF_encrypt::thread_add_ln107_1_fu_3472_p2() {
    add_ln107_1_fu_3472_p2 = (!xor_ln107_fu_3439_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln107_fu_3439_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln107_2_fu_3385_p2() {
    add_ln107_2_fu_3385_p2 = (!trunc_ln107_5_fu_3381_p1.read().is_01() || !trunc_ln107_4_fu_3377_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln107_5_fu_3381_p1.read()) + sc_biguint<16>(trunc_ln107_4_fu_3377_p1.read()));
}

void BF_encrypt::thread_add_ln107_3_fu_3391_p2() {
    add_ln107_3_fu_3391_p2 = (!trunc_ln107_3_fu_3373_p1.read().is_01() || !trunc_ln107_2_fu_3369_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln107_3_fu_3373_p1.read()) + sc_biguint<24>(trunc_ln107_2_fu_3369_p1.read()));
}

void BF_encrypt::thread_add_ln107_4_fu_3397_p2() {
    add_ln107_4_fu_3397_p2 = (!trunc_ln107_1_fu_3365_p1.read().is_01() || !trunc_ln107_fu_3361_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln107_1_fu_3365_p1.read()) + sc_biguint<8>(trunc_ln107_fu_3361_p1.read()));
}

void BF_encrypt::thread_add_ln107_5_fu_3478_p2() {
    add_ln107_5_fu_3478_p2 = (!trunc_ln107_12_fu_3468_p1.read().is_01() || !xor_ln107_3_fu_3463_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln107_12_fu_3468_p1.read()) + sc_biguint<16>(xor_ln107_3_fu_3463_p2.read()));
}

void BF_encrypt::thread_add_ln107_6_fu_3484_p2() {
    add_ln107_6_fu_3484_p2 = (!trunc_ln107_11_fu_3459_p1.read().is_01() || !xor_ln107_2_fu_3454_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln107_11_fu_3459_p1.read()) + sc_biguint<24>(xor_ln107_2_fu_3454_p2.read()));
}

void BF_encrypt::thread_add_ln107_7_fu_3490_p2() {
    add_ln107_7_fu_3490_p2 = (!trunc_ln107_10_fu_3450_p1.read().is_01() || !xor_ln107_1_fu_3445_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln107_10_fu_3450_p1.read()) + sc_biguint<8>(xor_ln107_1_fu_3445_p2.read()));
}

void BF_encrypt::thread_add_ln108_1_fu_3709_p2() {
    add_ln108_1_fu_3709_p2 = (!xor_ln108_fu_3676_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln108_fu_3676_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln108_2_fu_3622_p2() {
    add_ln108_2_fu_3622_p2 = (!trunc_ln108_5_fu_3618_p1.read().is_01() || !trunc_ln108_4_fu_3614_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln108_5_fu_3618_p1.read()) + sc_biguint<16>(trunc_ln108_4_fu_3614_p1.read()));
}

void BF_encrypt::thread_add_ln108_3_fu_3628_p2() {
    add_ln108_3_fu_3628_p2 = (!trunc_ln108_3_fu_3610_p1.read().is_01() || !trunc_ln108_2_fu_3606_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln108_3_fu_3610_p1.read()) + sc_biguint<24>(trunc_ln108_2_fu_3606_p1.read()));
}

void BF_encrypt::thread_add_ln108_4_fu_3634_p2() {
    add_ln108_4_fu_3634_p2 = (!trunc_ln108_1_fu_3602_p1.read().is_01() || !trunc_ln108_fu_3598_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln108_1_fu_3602_p1.read()) + sc_biguint<8>(trunc_ln108_fu_3598_p1.read()));
}

void BF_encrypt::thread_add_ln108_5_fu_3715_p2() {
    add_ln108_5_fu_3715_p2 = (!trunc_ln108_12_fu_3705_p1.read().is_01() || !xor_ln108_3_fu_3700_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln108_12_fu_3705_p1.read()) + sc_biguint<16>(xor_ln108_3_fu_3700_p2.read()));
}

void BF_encrypt::thread_add_ln108_6_fu_3721_p2() {
    add_ln108_6_fu_3721_p2 = (!trunc_ln108_11_fu_3696_p1.read().is_01() || !xor_ln108_2_fu_3691_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln108_11_fu_3696_p1.read()) + sc_biguint<24>(xor_ln108_2_fu_3691_p2.read()));
}

void BF_encrypt::thread_add_ln108_7_fu_3727_p2() {
    add_ln108_7_fu_3727_p2 = (!trunc_ln108_10_fu_3687_p1.read().is_01() || !xor_ln108_1_fu_3682_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln108_10_fu_3687_p1.read()) + sc_biguint<8>(xor_ln108_1_fu_3682_p2.read()));
}

void BF_encrypt::thread_add_ln109_1_fu_3942_p2() {
    add_ln109_1_fu_3942_p2 = (!xor_ln109_fu_3909_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln109_fu_3909_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln109_2_fu_3855_p2() {
    add_ln109_2_fu_3855_p2 = (!trunc_ln109_5_fu_3851_p1.read().is_01() || !trunc_ln109_4_fu_3847_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln109_5_fu_3851_p1.read()) + sc_biguint<16>(trunc_ln109_4_fu_3847_p1.read()));
}

void BF_encrypt::thread_add_ln109_3_fu_3861_p2() {
    add_ln109_3_fu_3861_p2 = (!trunc_ln109_3_fu_3843_p1.read().is_01() || !trunc_ln109_2_fu_3839_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln109_3_fu_3843_p1.read()) + sc_biguint<24>(trunc_ln109_2_fu_3839_p1.read()));
}

void BF_encrypt::thread_add_ln109_4_fu_3867_p2() {
    add_ln109_4_fu_3867_p2 = (!trunc_ln109_1_fu_3835_p1.read().is_01() || !trunc_ln109_fu_3831_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln109_1_fu_3835_p1.read()) + sc_biguint<8>(trunc_ln109_fu_3831_p1.read()));
}

void BF_encrypt::thread_add_ln109_5_fu_3948_p2() {
    add_ln109_5_fu_3948_p2 = (!trunc_ln109_12_fu_3938_p1.read().is_01() || !xor_ln109_3_fu_3933_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln109_12_fu_3938_p1.read()) + sc_biguint<16>(xor_ln109_3_fu_3933_p2.read()));
}

void BF_encrypt::thread_add_ln109_6_fu_3954_p2() {
    add_ln109_6_fu_3954_p2 = (!trunc_ln109_11_fu_3929_p1.read().is_01() || !xor_ln109_2_fu_3924_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln109_11_fu_3929_p1.read()) + sc_biguint<24>(xor_ln109_2_fu_3924_p2.read()));
}

void BF_encrypt::thread_add_ln109_7_fu_3960_p2() {
    add_ln109_7_fu_3960_p2 = (!trunc_ln109_10_fu_3920_p1.read().is_01() || !xor_ln109_1_fu_3915_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln109_10_fu_3920_p1.read()) + sc_biguint<8>(xor_ln109_1_fu_3915_p2.read()));
}

void BF_encrypt::thread_add_ln110_1_fu_4175_p2() {
    add_ln110_1_fu_4175_p2 = (!xor_ln110_fu_4142_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln110_fu_4142_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln110_2_fu_4088_p2() {
    add_ln110_2_fu_4088_p2 = (!trunc_ln110_5_fu_4084_p1.read().is_01() || !trunc_ln110_4_fu_4080_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln110_5_fu_4084_p1.read()) + sc_biguint<16>(trunc_ln110_4_fu_4080_p1.read()));
}

void BF_encrypt::thread_add_ln110_3_fu_4094_p2() {
    add_ln110_3_fu_4094_p2 = (!trunc_ln110_3_fu_4076_p1.read().is_01() || !trunc_ln110_2_fu_4072_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln110_3_fu_4076_p1.read()) + sc_biguint<24>(trunc_ln110_2_fu_4072_p1.read()));
}

void BF_encrypt::thread_add_ln110_4_fu_4100_p2() {
    add_ln110_4_fu_4100_p2 = (!trunc_ln110_1_fu_4068_p1.read().is_01() || !trunc_ln110_fu_4064_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln110_1_fu_4068_p1.read()) + sc_biguint<8>(trunc_ln110_fu_4064_p1.read()));
}

void BF_encrypt::thread_add_ln110_5_fu_4181_p2() {
    add_ln110_5_fu_4181_p2 = (!trunc_ln110_12_fu_4171_p1.read().is_01() || !xor_ln110_3_fu_4166_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln110_12_fu_4171_p1.read()) + sc_biguint<16>(xor_ln110_3_fu_4166_p2.read()));
}

void BF_encrypt::thread_add_ln110_6_fu_4187_p2() {
    add_ln110_6_fu_4187_p2 = (!trunc_ln110_11_fu_4162_p1.read().is_01() || !xor_ln110_2_fu_4157_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln110_11_fu_4162_p1.read()) + sc_biguint<24>(xor_ln110_2_fu_4157_p2.read()));
}

void BF_encrypt::thread_add_ln110_7_fu_4193_p2() {
    add_ln110_7_fu_4193_p2 = (!trunc_ln110_10_fu_4153_p1.read().is_01() || !xor_ln110_1_fu_4148_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln110_10_fu_4153_p1.read()) + sc_biguint<8>(xor_ln110_1_fu_4148_p2.read()));
}

void BF_encrypt::thread_add_ln111_1_fu_4332_p2() {
    add_ln111_1_fu_4332_p2 = (!xor_ln111_fu_4326_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln111_fu_4326_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln96_1_fu_873_p2() {
    add_ln96_1_fu_873_p2 = (!xor_ln96_fu_840_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln96_fu_840_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln96_2_fu_798_p2() {
    add_ln96_2_fu_798_p2 = (!trunc_ln96_5_fu_782_p1.read().is_01() || !trunc_ln96_4_fu_778_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln96_5_fu_782_p1.read()) + sc_biguint<16>(trunc_ln96_4_fu_778_p1.read()));
}

void BF_encrypt::thread_add_ln96_3_fu_804_p2() {
    add_ln96_3_fu_804_p2 = (!trunc_ln96_3_fu_774_p1.read().is_01() || !trunc_ln96_2_fu_770_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln96_3_fu_774_p1.read()) + sc_biguint<24>(trunc_ln96_2_fu_770_p1.read()));
}

void BF_encrypt::thread_add_ln96_4_fu_810_p2() {
    add_ln96_4_fu_810_p2 = (!trunc_ln96_1_fu_766_p1.read().is_01() || !trunc_ln96_fu_762_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln96_1_fu_766_p1.read()) + sc_biguint<8>(trunc_ln96_fu_762_p1.read()));
}

void BF_encrypt::thread_add_ln96_5_fu_883_p2() {
    add_ln96_5_fu_883_p2 = (!trunc_ln96_12_fu_869_p1.read().is_01() || !xor_ln96_3_fu_864_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln96_12_fu_869_p1.read()) + sc_biguint<16>(xor_ln96_3_fu_864_p2.read()));
}

void BF_encrypt::thread_add_ln96_6_fu_893_p2() {
    add_ln96_6_fu_893_p2 = (!trunc_ln96_11_fu_860_p1.read().is_01() || !xor_ln96_2_fu_855_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln96_11_fu_860_p1.read()) + sc_biguint<24>(xor_ln96_2_fu_855_p2.read()));
}

void BF_encrypt::thread_add_ln96_7_fu_903_p2() {
    add_ln96_7_fu_903_p2 = (!trunc_ln96_10_fu_851_p1.read().is_01() || !xor_ln96_1_fu_846_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln96_10_fu_851_p1.read()) + sc_biguint<8>(xor_ln96_1_fu_846_p2.read()));
}

void BF_encrypt::thread_add_ln97_1_fu_1126_p2() {
    add_ln97_1_fu_1126_p2 = (!xor_ln97_fu_1093_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln97_fu_1093_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln97_2_fu_1051_p2() {
    add_ln97_2_fu_1051_p2 = (!trunc_ln97_5_fu_1035_p1.read().is_01() || !trunc_ln97_4_fu_1031_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln97_5_fu_1035_p1.read()) + sc_biguint<16>(trunc_ln97_4_fu_1031_p1.read()));
}

void BF_encrypt::thread_add_ln97_3_fu_1057_p2() {
    add_ln97_3_fu_1057_p2 = (!trunc_ln97_3_fu_1027_p1.read().is_01() || !trunc_ln97_2_fu_1023_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln97_3_fu_1027_p1.read()) + sc_biguint<24>(trunc_ln97_2_fu_1023_p1.read()));
}

void BF_encrypt::thread_add_ln97_4_fu_1063_p2() {
    add_ln97_4_fu_1063_p2 = (!trunc_ln97_1_fu_1019_p1.read().is_01() || !trunc_ln97_fu_1015_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln97_1_fu_1019_p1.read()) + sc_biguint<8>(trunc_ln97_fu_1015_p1.read()));
}

void BF_encrypt::thread_add_ln97_5_fu_1132_p2() {
    add_ln97_5_fu_1132_p2 = (!trunc_ln97_12_fu_1122_p1.read().is_01() || !xor_ln97_3_fu_1117_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln97_12_fu_1122_p1.read()) + sc_biguint<16>(xor_ln97_3_fu_1117_p2.read()));
}

void BF_encrypt::thread_add_ln97_6_fu_1138_p2() {
    add_ln97_6_fu_1138_p2 = (!trunc_ln97_11_fu_1113_p1.read().is_01() || !xor_ln97_2_fu_1108_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln97_11_fu_1113_p1.read()) + sc_biguint<24>(xor_ln97_2_fu_1108_p2.read()));
}

void BF_encrypt::thread_add_ln97_7_fu_1144_p2() {
    add_ln97_7_fu_1144_p2 = (!trunc_ln97_10_fu_1104_p1.read().is_01() || !xor_ln97_1_fu_1099_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln97_10_fu_1104_p1.read()) + sc_biguint<8>(xor_ln97_1_fu_1099_p2.read()));
}

void BF_encrypt::thread_add_ln98_1_fu_1363_p2() {
    add_ln98_1_fu_1363_p2 = (!xor_ln98_fu_1330_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln98_fu_1330_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln98_2_fu_1288_p2() {
    add_ln98_2_fu_1288_p2 = (!trunc_ln98_5_fu_1272_p1.read().is_01() || !trunc_ln98_4_fu_1268_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln98_5_fu_1272_p1.read()) + sc_biguint<16>(trunc_ln98_4_fu_1268_p1.read()));
}

void BF_encrypt::thread_add_ln98_3_fu_1294_p2() {
    add_ln98_3_fu_1294_p2 = (!trunc_ln98_3_fu_1264_p1.read().is_01() || !trunc_ln98_2_fu_1260_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln98_3_fu_1264_p1.read()) + sc_biguint<24>(trunc_ln98_2_fu_1260_p1.read()));
}

void BF_encrypt::thread_add_ln98_4_fu_1300_p2() {
    add_ln98_4_fu_1300_p2 = (!trunc_ln98_1_fu_1256_p1.read().is_01() || !trunc_ln98_fu_1252_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln98_1_fu_1256_p1.read()) + sc_biguint<8>(trunc_ln98_fu_1252_p1.read()));
}

void BF_encrypt::thread_add_ln98_5_fu_1369_p2() {
    add_ln98_5_fu_1369_p2 = (!trunc_ln98_12_fu_1359_p1.read().is_01() || !xor_ln98_3_fu_1354_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln98_12_fu_1359_p1.read()) + sc_biguint<16>(xor_ln98_3_fu_1354_p2.read()));
}

void BF_encrypt::thread_add_ln98_6_fu_1375_p2() {
    add_ln98_6_fu_1375_p2 = (!trunc_ln98_11_fu_1350_p1.read().is_01() || !xor_ln98_2_fu_1345_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln98_11_fu_1350_p1.read()) + sc_biguint<24>(xor_ln98_2_fu_1345_p2.read()));
}

void BF_encrypt::thread_add_ln98_7_fu_1381_p2() {
    add_ln98_7_fu_1381_p2 = (!trunc_ln98_10_fu_1341_p1.read().is_01() || !xor_ln98_1_fu_1336_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln98_10_fu_1341_p1.read()) + sc_biguint<8>(xor_ln98_1_fu_1336_p2.read()));
}

void BF_encrypt::thread_add_ln99_1_fu_1600_p2() {
    add_ln99_1_fu_1600_p2 = (!xor_ln99_fu_1567_p2.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(xor_ln99_fu_1567_p2.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_add_ln99_2_fu_1525_p2() {
    add_ln99_2_fu_1525_p2 = (!trunc_ln99_5_fu_1509_p1.read().is_01() || !trunc_ln99_4_fu_1505_p1.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln99_5_fu_1509_p1.read()) + sc_biguint<16>(trunc_ln99_4_fu_1505_p1.read()));
}

void BF_encrypt::thread_add_ln99_3_fu_1531_p2() {
    add_ln99_3_fu_1531_p2 = (!trunc_ln99_3_fu_1501_p1.read().is_01() || !trunc_ln99_2_fu_1497_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln99_3_fu_1501_p1.read()) + sc_biguint<24>(trunc_ln99_2_fu_1497_p1.read()));
}

void BF_encrypt::thread_add_ln99_4_fu_1537_p2() {
    add_ln99_4_fu_1537_p2 = (!trunc_ln99_1_fu_1493_p1.read().is_01() || !trunc_ln99_fu_1489_p1.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln99_1_fu_1493_p1.read()) + sc_biguint<8>(trunc_ln99_fu_1489_p1.read()));
}

void BF_encrypt::thread_add_ln99_5_fu_1606_p2() {
    add_ln99_5_fu_1606_p2 = (!trunc_ln99_12_fu_1596_p1.read().is_01() || !xor_ln99_3_fu_1591_p2.read().is_01())? sc_lv<16>(): (sc_biguint<16>(trunc_ln99_12_fu_1596_p1.read()) + sc_biguint<16>(xor_ln99_3_fu_1591_p2.read()));
}

void BF_encrypt::thread_add_ln99_6_fu_1612_p2() {
    add_ln99_6_fu_1612_p2 = (!trunc_ln99_11_fu_1587_p1.read().is_01() || !xor_ln99_2_fu_1582_p2.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln99_11_fu_1587_p1.read()) + sc_biguint<24>(xor_ln99_2_fu_1582_p2.read()));
}

void BF_encrypt::thread_add_ln99_7_fu_1618_p2() {
    add_ln99_7_fu_1618_p2 = (!trunc_ln99_10_fu_1578_p1.read().is_01() || !xor_ln99_1_fu_1573_p2.read().is_01())? sc_lv<8>(): (sc_biguint<8>(trunc_ln99_10_fu_1578_p1.read()) + sc_biguint<8>(xor_ln99_1_fu_1573_p2.read()));
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage0() {
    ap_CS_fsm_pp0_stage0 = ap_CS_fsm.read()[0];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage1() {
    ap_CS_fsm_pp0_stage1 = ap_CS_fsm.read()[1];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage10() {
    ap_CS_fsm_pp0_stage10 = ap_CS_fsm.read()[10];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage11() {
    ap_CS_fsm_pp0_stage11 = ap_CS_fsm.read()[11];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage12() {
    ap_CS_fsm_pp0_stage12 = ap_CS_fsm.read()[12];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage13() {
    ap_CS_fsm_pp0_stage13 = ap_CS_fsm.read()[13];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage14() {
    ap_CS_fsm_pp0_stage14 = ap_CS_fsm.read()[14];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage15() {
    ap_CS_fsm_pp0_stage15 = ap_CS_fsm.read()[15];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage16() {
    ap_CS_fsm_pp0_stage16 = ap_CS_fsm.read()[16];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage17() {
    ap_CS_fsm_pp0_stage17 = ap_CS_fsm.read()[17];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage18() {
    ap_CS_fsm_pp0_stage18 = ap_CS_fsm.read()[18];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage19() {
    ap_CS_fsm_pp0_stage19 = ap_CS_fsm.read()[19];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage2() {
    ap_CS_fsm_pp0_stage2 = ap_CS_fsm.read()[2];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage20() {
    ap_CS_fsm_pp0_stage20 = ap_CS_fsm.read()[20];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage21() {
    ap_CS_fsm_pp0_stage21 = ap_CS_fsm.read()[21];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage22() {
    ap_CS_fsm_pp0_stage22 = ap_CS_fsm.read()[22];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage23() {
    ap_CS_fsm_pp0_stage23 = ap_CS_fsm.read()[23];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage24() {
    ap_CS_fsm_pp0_stage24 = ap_CS_fsm.read()[24];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage25() {
    ap_CS_fsm_pp0_stage25 = ap_CS_fsm.read()[25];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage26() {
    ap_CS_fsm_pp0_stage26 = ap_CS_fsm.read()[26];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage27() {
    ap_CS_fsm_pp0_stage27 = ap_CS_fsm.read()[27];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage28() {
    ap_CS_fsm_pp0_stage28 = ap_CS_fsm.read()[28];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage29() {
    ap_CS_fsm_pp0_stage29 = ap_CS_fsm.read()[29];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage3() {
    ap_CS_fsm_pp0_stage3 = ap_CS_fsm.read()[3];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage30() {
    ap_CS_fsm_pp0_stage30 = ap_CS_fsm.read()[30];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage31() {
    ap_CS_fsm_pp0_stage31 = ap_CS_fsm.read()[31];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage4() {
    ap_CS_fsm_pp0_stage4 = ap_CS_fsm.read()[4];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage5() {
    ap_CS_fsm_pp0_stage5 = ap_CS_fsm.read()[5];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage6() {
    ap_CS_fsm_pp0_stage6 = ap_CS_fsm.read()[6];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage7() {
    ap_CS_fsm_pp0_stage7 = ap_CS_fsm.read()[7];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage8() {
    ap_CS_fsm_pp0_stage8 = ap_CS_fsm.read()[8];
}

void BF_encrypt::thread_ap_CS_fsm_pp0_stage9() {
    ap_CS_fsm_pp0_stage9 = ap_CS_fsm.read()[9];
}

void BF_encrypt::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()));
}

void BF_encrypt::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0) || (esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read())));
}

void BF_encrypt::thread_ap_block_pp0_stage1() {
    ap_block_pp0_stage1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage10() {
    ap_block_pp0_stage10 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage10_11001() {
    ap_block_pp0_stage10_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage10_subdone() {
    ap_block_pp0_stage10_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage11() {
    ap_block_pp0_stage11 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage11_11001() {
    ap_block_pp0_stage11_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage11_subdone() {
    ap_block_pp0_stage11_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage12() {
    ap_block_pp0_stage12 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage12_11001() {
    ap_block_pp0_stage12_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage12_subdone() {
    ap_block_pp0_stage12_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage13() {
    ap_block_pp0_stage13 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage13_11001() {
    ap_block_pp0_stage13_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage13_subdone() {
    ap_block_pp0_stage13_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage14() {
    ap_block_pp0_stage14 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage14_11001() {
    ap_block_pp0_stage14_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage14_subdone() {
    ap_block_pp0_stage14_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage15() {
    ap_block_pp0_stage15 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage15_11001() {
    ap_block_pp0_stage15_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage15_subdone() {
    ap_block_pp0_stage15_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage16() {
    ap_block_pp0_stage16 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage16_11001() {
    ap_block_pp0_stage16_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage16_subdone() {
    ap_block_pp0_stage16_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage17() {
    ap_block_pp0_stage17 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage17_11001() {
    ap_block_pp0_stage17_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage17_subdone() {
    ap_block_pp0_stage17_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage18() {
    ap_block_pp0_stage18 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage18_11001() {
    ap_block_pp0_stage18_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage18_subdone() {
    ap_block_pp0_stage18_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage19() {
    ap_block_pp0_stage19 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage19_11001() {
    ap_block_pp0_stage19_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage19_subdone() {
    ap_block_pp0_stage19_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage1_11001() {
    ap_block_pp0_stage1_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage1_subdone() {
    ap_block_pp0_stage1_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage2() {
    ap_block_pp0_stage2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage20() {
    ap_block_pp0_stage20 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage20_11001() {
    ap_block_pp0_stage20_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage20_subdone() {
    ap_block_pp0_stage20_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage21() {
    ap_block_pp0_stage21 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage21_11001() {
    ap_block_pp0_stage21_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage21_subdone() {
    ap_block_pp0_stage21_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage22() {
    ap_block_pp0_stage22 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage22_11001() {
    ap_block_pp0_stage22_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage22_subdone() {
    ap_block_pp0_stage22_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage23() {
    ap_block_pp0_stage23 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage23_11001() {
    ap_block_pp0_stage23_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage23_subdone() {
    ap_block_pp0_stage23_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage24() {
    ap_block_pp0_stage24 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage24_11001() {
    ap_block_pp0_stage24_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage24_subdone() {
    ap_block_pp0_stage24_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage25() {
    ap_block_pp0_stage25 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage25_11001() {
    ap_block_pp0_stage25_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage25_subdone() {
    ap_block_pp0_stage25_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage26() {
    ap_block_pp0_stage26 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage26_11001() {
    ap_block_pp0_stage26_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage26_subdone() {
    ap_block_pp0_stage26_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage27() {
    ap_block_pp0_stage27 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage27_11001() {
    ap_block_pp0_stage27_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage27_subdone() {
    ap_block_pp0_stage27_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage28() {
    ap_block_pp0_stage28 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage28_11001() {
    ap_block_pp0_stage28_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage28_subdone() {
    ap_block_pp0_stage28_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage29() {
    ap_block_pp0_stage29 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage29_11001() {
    ap_block_pp0_stage29_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage29_subdone() {
    ap_block_pp0_stage29_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage2_11001() {
    ap_block_pp0_stage2_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage2_subdone() {
    ap_block_pp0_stage2_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage3() {
    ap_block_pp0_stage3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage30() {
    ap_block_pp0_stage30 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage30_11001() {
    ap_block_pp0_stage30_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage30_subdone() {
    ap_block_pp0_stage30_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage31() {
    ap_block_pp0_stage31 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage31_11001() {
    ap_block_pp0_stage31_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage31_subdone() {
    ap_block_pp0_stage31_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage3_11001() {
    ap_block_pp0_stage3_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage3_subdone() {
    ap_block_pp0_stage3_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage4() {
    ap_block_pp0_stage4 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage4_11001() {
    ap_block_pp0_stage4_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage4_subdone() {
    ap_block_pp0_stage4_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage5() {
    ap_block_pp0_stage5 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage5_11001() {
    ap_block_pp0_stage5_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage5_subdone() {
    ap_block_pp0_stage5_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage6() {
    ap_block_pp0_stage6 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage6_11001() {
    ap_block_pp0_stage6_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage6_subdone() {
    ap_block_pp0_stage6_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage7() {
    ap_block_pp0_stage7 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage7_11001() {
    ap_block_pp0_stage7_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage7_subdone() {
    ap_block_pp0_stage7_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage8() {
    ap_block_pp0_stage8 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage8_11001() {
    ap_block_pp0_stage8_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage8_subdone() {
    ap_block_pp0_stage8_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_pp0_stage9() {
    ap_block_pp0_stage9 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage9_11001() {
    ap_block_pp0_stage9_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_pp0_stage9_subdone() {
    ap_block_pp0_stage9_subdone = esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_0);
}

void BF_encrypt::thread_ap_block_state10_pp0_stage9_iter0() {
    ap_block_state10_pp0_stage9_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state11_pp0_stage10_iter0() {
    ap_block_state11_pp0_stage10_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state12_pp0_stage11_iter0() {
    ap_block_state12_pp0_stage11_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state13_pp0_stage12_iter0() {
    ap_block_state13_pp0_stage12_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state14_pp0_stage13_iter0() {
    ap_block_state14_pp0_stage13_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state15_pp0_stage14_iter0() {
    ap_block_state15_pp0_stage14_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state16_pp0_stage15_iter0() {
    ap_block_state16_pp0_stage15_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state17_pp0_stage16_iter0() {
    ap_block_state17_pp0_stage16_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state18_pp0_stage17_iter0() {
    ap_block_state18_pp0_stage17_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state19_pp0_stage18_iter0() {
    ap_block_state19_pp0_stage18_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state1_pp0_stage0_iter0() {
    ap_block_state1_pp0_stage0_iter0 = esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read());
}

void BF_encrypt::thread_ap_block_state20_pp0_stage19_iter0() {
    ap_block_state20_pp0_stage19_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state21_pp0_stage20_iter0() {
    ap_block_state21_pp0_stage20_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state22_pp0_stage21_iter0() {
    ap_block_state22_pp0_stage21_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state23_pp0_stage22_iter0() {
    ap_block_state23_pp0_stage22_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state24_pp0_stage23_iter0() {
    ap_block_state24_pp0_stage23_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state25_pp0_stage24_iter0() {
    ap_block_state25_pp0_stage24_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state26_pp0_stage25_iter0() {
    ap_block_state26_pp0_stage25_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state27_pp0_stage26_iter0() {
    ap_block_state27_pp0_stage26_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state28_pp0_stage27_iter0() {
    ap_block_state28_pp0_stage27_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state29_pp0_stage28_iter0() {
    ap_block_state29_pp0_stage28_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state2_pp0_stage1_iter0() {
    ap_block_state2_pp0_stage1_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state30_pp0_stage29_iter0() {
    ap_block_state30_pp0_stage29_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state31_pp0_stage30_iter0() {
    ap_block_state31_pp0_stage30_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state32_pp0_stage31_iter0() {
    ap_block_state32_pp0_stage31_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state33_pp0_stage0_iter1() {
    ap_block_state33_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state34_pp0_stage1_iter1() {
    ap_block_state34_pp0_stage1_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state35_pp0_stage2_iter1() {
    ap_block_state35_pp0_stage2_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state36_pp0_stage3_iter1() {
    ap_block_state36_pp0_stage3_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state37_pp0_stage4_iter1() {
    ap_block_state37_pp0_stage4_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state38_pp0_stage5_iter1() {
    ap_block_state38_pp0_stage5_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state39_pp0_stage6_iter1() {
    ap_block_state39_pp0_stage6_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state3_pp0_stage2_iter0() {
    ap_block_state3_pp0_stage2_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state40_pp0_stage7_iter1() {
    ap_block_state40_pp0_stage7_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state41_pp0_stage8_iter1() {
    ap_block_state41_pp0_stage8_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state42_pp0_stage9_iter1() {
    ap_block_state42_pp0_stage9_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state43_pp0_stage10_iter1() {
    ap_block_state43_pp0_stage10_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state44_pp0_stage11_iter1() {
    ap_block_state44_pp0_stage11_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state45_pp0_stage12_iter1() {
    ap_block_state45_pp0_stage12_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state46_pp0_stage13_iter1() {
    ap_block_state46_pp0_stage13_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state47_pp0_stage14_iter1() {
    ap_block_state47_pp0_stage14_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state48_pp0_stage15_iter1() {
    ap_block_state48_pp0_stage15_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state49_pp0_stage16_iter1() {
    ap_block_state49_pp0_stage16_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state4_pp0_stage3_iter0() {
    ap_block_state4_pp0_stage3_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state50_pp0_stage17_iter1() {
    ap_block_state50_pp0_stage17_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state51_pp0_stage18_iter1() {
    ap_block_state51_pp0_stage18_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state52_pp0_stage19_iter1() {
    ap_block_state52_pp0_stage19_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state53_pp0_stage20_iter1() {
    ap_block_state53_pp0_stage20_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state54_pp0_stage21_iter1() {
    ap_block_state54_pp0_stage21_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state55_pp0_stage22_iter1() {
    ap_block_state55_pp0_stage22_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state56_pp0_stage23_iter1() {
    ap_block_state56_pp0_stage23_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state57_pp0_stage24_iter1() {
    ap_block_state57_pp0_stage24_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state58_pp0_stage25_iter1() {
    ap_block_state58_pp0_stage25_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state59_pp0_stage26_iter1() {
    ap_block_state59_pp0_stage26_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state5_pp0_stage4_iter0() {
    ap_block_state5_pp0_stage4_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state60_pp0_stage27_iter1() {
    ap_block_state60_pp0_stage27_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state61_pp0_stage28_iter1() {
    ap_block_state61_pp0_stage28_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state62_pp0_stage29_iter1() {
    ap_block_state62_pp0_stage29_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state63_pp0_stage30_iter1() {
    ap_block_state63_pp0_stage30_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state64_pp0_stage31_iter1() {
    ap_block_state64_pp0_stage31_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state6_pp0_stage5_iter0() {
    ap_block_state6_pp0_stage5_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state7_pp0_stage6_iter0() {
    ap_block_state7_pp0_stage6_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state8_pp0_stage7_iter0() {
    ap_block_state8_pp0_stage7_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_block_state9_pp0_stage8_iter0() {
    ap_block_state9_pp0_stage8_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void BF_encrypt::thread_ap_condition_148() {
    ap_condition_148 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0));
}

void BF_encrypt::thread_ap_condition_314() {
    ap_condition_314 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0));
}

void BF_encrypt::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void BF_encrypt::thread_ap_enable_reg_pp0_iter0() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read())) {
        ap_enable_reg_pp0_iter0 = ap_start.read();
    } else {
        ap_enable_reg_pp0_iter0 = ap_enable_reg_pp0_iter0_reg.read();
    }
}

void BF_encrypt::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0_0to0() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read())) {
        ap_idle_pp0_0to0 = ap_const_logic_1;
    } else {
        ap_idle_pp0_0to0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_idle_pp0_1to1() {
    if (esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read())) {
        ap_idle_pp0_1to1 = ap_const_logic_1;
    } else {
        ap_idle_pp0_1to1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage31_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to0.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_ap_return_0() {
    ap_return_0 = r_8_reg_5501.read();
}

void BF_encrypt::thread_ap_return_1() {
    ap_return_1 = l_11_fu_4343_p2.read();
}

void BF_encrypt::thread_grp_fu_638_p2() {
    grp_fu_638_p2 = (!key_S_q0.read().is_01() || !key_S_q1.read().is_01())? sc_lv<32>(): (sc_biguint<32>(key_S_q0.read()) + sc_biguint<32>(key_S_q1.read()));
}

void BF_encrypt::thread_key_P_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_10;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_E;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_C;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_A;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_8;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_6;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_4;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_2;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        key_P_address0 = ap_const_lv5_0;
    } else {
        key_P_address0 = "XXXXX";
    }
}

void BF_encrypt::thread_key_P_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_11;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_F;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_D;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_B;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_9;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_7;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_5;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_3;
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0))) {
        key_P_address1 = ap_const_lv5_1;
    } else {
        key_P_address1 = "XXXXX";
    }
}

void BF_encrypt::thread_key_P_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        key_P_ce0 = ap_const_logic_1;
    } else {
        key_P_ce0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_P_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        key_P_ce1 = ap_const_logic_1;
    } else {
        key_P_ce1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_S_address0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage30.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln111_2_fu_4309_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage27.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln111_fu_4286_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage24.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln110_2_fu_4113_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage21.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln110_fu_4048_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln109_2_fu_3880_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln109_fu_3815_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln108_2_fu_3647_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln108_fu_3582_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln107_2_fu_3410_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln107_fu_3345_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln106_2_fu_3159_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage31.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln106_fu_3112_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage29.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln105_2_fu_2922_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage28.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln105_fu_2875_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage26.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln104_2_fu_2689_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage25.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln104_fu_2642_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage23.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln103_2_fu_2456_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage22.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln103_fu_2409_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln102_2_fu_2223_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln102_fu_2176_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln101_2_fu_1990_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln101_fu_1943_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln100_2_fu_1757_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln100_fu_1710_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln99_2_fu_1520_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln99_fu_1473_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln98_2_fu_1283_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln98_fu_1236_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln97_2_fu_1046_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln97_fu_999_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln96_2_fu_793_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        key_S_address0 =  (sc_lv<10>) (zext_ln96_fu_724_p1.read());
    } else {
        key_S_address0 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void BF_encrypt::thread_key_S_address1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage30.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln111_3_fu_4321_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage27.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln111_1_fu_4297_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage24.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln110_3_fu_4125_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage21.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln110_1_fu_4059_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage18.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln109_3_fu_3892_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage15.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln109_1_fu_3826_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage12.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln108_3_fu_3659_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage9.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln108_1_fu_3593_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage6.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln107_3_fu_3422_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage3.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln107_1_fu_3356_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage0.read(), ap_const_boolean_0) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln106_3_fu_3189_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage31.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln106_1_fu_3123_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage29.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln105_3_fu_2952_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage28.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln105_1_fu_2886_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage26.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln104_3_fu_2719_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage25.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln104_1_fu_2653_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage23.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln103_3_fu_2486_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage22.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln103_1_fu_2420_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage20.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln102_3_fu_2253_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage19.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln102_1_fu_2187_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage17.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln101_3_fu_2020_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage16.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln101_1_fu_1954_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage14.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln100_3_fu_1787_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage13.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln100_1_fu_1721_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage11.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln99_3_fu_1550_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage10.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln99_1_fu_1484_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage8.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln98_3_fu_1313_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage7.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln98_1_fu_1247_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage5.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln97_3_fu_1076_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage4.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln97_1_fu_1010_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage2.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln96_3_fu_823_p1.read());
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                esl_seteq<1,1,1>(ap_block_pp0_stage1.read(), ap_const_boolean_0))) {
        key_S_address1 =  (sc_lv<10>) (zext_ln96_1_fu_747_p1.read());
    } else {
        key_S_address1 =  (sc_lv<10>) ("XXXXXXXXXX");
    }
}

void BF_encrypt::thread_key_S_ce0() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage26_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage25_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage27_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage30_11001.read(), ap_const_boolean_0)))) {
        key_S_ce0 = ap_const_logic_1;
    } else {
        key_S_ce0 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_key_S_ce1() {
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage31_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage20_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage23_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage26_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage29_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage19_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage22_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage25_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
          esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage28_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read())) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage21_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage24_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage27_11001.read(), ap_const_boolean_0)) || 
         (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && 
          esl_seteq<1,1,1>(ap_block_pp0_stage30_11001.read(), ap_const_boolean_0)))) {
        key_S_ce1 = ap_const_logic_1;
    } else {
        key_S_ce1 = ap_const_logic_0;
    }
}

void BF_encrypt::thread_l_10_fu_3995_p2() {
    l_10_fu_3995_p2 = (xor_ln109_4_fu_3966_p2.read() ^ key_P_load_14_reg_5294.read());
}

void BF_encrypt::thread_l_11_fu_4343_p2() {
    l_11_fu_4343_p2 = (xor_ln111_1_fu_4338_p2.read() ^ reg_657.read());
}

void BF_encrypt::thread_l_4_fu_1182_p2() {
    l_4_fu_1182_p2 = (xor_ln97_4_fu_1150_p2.read() ^ reg_653.read());
}

void BF_encrypt::thread_l_5_fu_1656_p2() {
    l_5_fu_1656_p2 = (xor_ln99_4_fu_1624_p2.read() ^ reg_644.read());
}

void BF_encrypt::thread_l_6_fu_2123_p2() {
    l_6_fu_2123_p2 = (xor_ln101_4_fu_2094_p2.read() ^ key_P_load_6_reg_4475.read());
}

void BF_encrypt::thread_l_7_fu_2589_p2() {
    l_7_fu_2589_p2 = (xor_ln103_4_fu_2560_p2.read() ^ key_P_load_8_reg_4516.read());
}

void BF_encrypt::thread_l_8_fu_3058_p2() {
    l_8_fu_3058_p2 = (xor_ln105_4_fu_3026_p2.read() ^ reg_653.read());
}

void BF_encrypt::thread_l_9_fu_3528_p2() {
    l_9_fu_3528_p2 = (xor_ln107_4_fu_3496_p2.read() ^ key_P_q0.read());
}

void BF_encrypt::thread_l_fu_690_p2() {
    l_fu_690_p2 = (key_P_q0.read() ^ ap_port_reg_data_0_read.read());
}

void BF_encrypt::thread_lshr_ln_fu_714_p4() {
    lshr_ln_fu_714_p4 = l_fu_690_p2.read().range(31, 24);
}

void BF_encrypt::thread_or_ln100_1_fu_1750_p3() {
    or_ln100_1_fu_1750_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln100_7_reg_4713.read());
}

void BF_encrypt::thread_or_ln100_2_fu_1780_p3() {
    or_ln100_2_fu_1780_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln99_11_reg_4697.read());
}

void BF_encrypt::thread_or_ln101_1_fu_1983_p3() {
    or_ln101_1_fu_1983_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln101_7_reg_4784.read());
}

void BF_encrypt::thread_or_ln101_2_fu_2013_p3() {
    or_ln101_2_fu_2013_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln100_11_reg_4768.read());
}

void BF_encrypt::thread_or_ln102_1_fu_2216_p3() {
    or_ln102_1_fu_2216_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln102_7_reg_4855.read());
}

void BF_encrypt::thread_or_ln102_2_fu_2246_p3() {
    or_ln102_2_fu_2246_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln101_11_reg_4839.read());
}

void BF_encrypt::thread_or_ln103_1_fu_2449_p3() {
    or_ln103_1_fu_2449_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln103_7_reg_4926.read());
}

void BF_encrypt::thread_or_ln103_2_fu_2479_p3() {
    or_ln103_2_fu_2479_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln102_11_reg_4910.read());
}

void BF_encrypt::thread_or_ln104_1_fu_2682_p3() {
    or_ln104_1_fu_2682_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln104_7_reg_4997.read());
}

void BF_encrypt::thread_or_ln104_2_fu_2712_p3() {
    or_ln104_2_fu_2712_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln103_11_reg_4981.read());
}

void BF_encrypt::thread_or_ln105_1_fu_2915_p3() {
    or_ln105_1_fu_2915_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln105_7_reg_5068.read());
}

void BF_encrypt::thread_or_ln105_2_fu_2945_p3() {
    or_ln105_2_fu_2945_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln104_11_reg_5052.read());
}

void BF_encrypt::thread_or_ln106_1_fu_3152_p3() {
    or_ln106_1_fu_3152_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln106_7_reg_5139.read());
}

void BF_encrypt::thread_or_ln106_2_fu_3182_p3() {
    or_ln106_2_fu_3182_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln105_11_reg_5123.read());
}

void BF_encrypt::thread_or_ln107_1_fu_3403_p3() {
    or_ln107_1_fu_3403_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln107_7_reg_5210.read());
}

void BF_encrypt::thread_or_ln107_2_fu_3415_p3() {
    or_ln107_2_fu_3415_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln106_11_reg_5194.read());
}

void BF_encrypt::thread_or_ln108_1_fu_3640_p3() {
    or_ln108_1_fu_3640_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln108_7_reg_5289.read());
}

void BF_encrypt::thread_or_ln108_2_fu_3652_p3() {
    or_ln108_2_fu_3652_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln107_11_reg_5265.read());
}

void BF_encrypt::thread_or_ln109_1_fu_3873_p3() {
    or_ln109_1_fu_3873_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln109_7_reg_5381.read());
}

void BF_encrypt::thread_or_ln109_2_fu_3885_p3() {
    or_ln109_2_fu_3885_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln108_11_reg_5365.read());
}

void BF_encrypt::thread_or_ln10_fu_3116_p3() {
    or_ln10_fu_3116_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln10_reg_5134.read());
}

void BF_encrypt::thread_or_ln110_1_fu_4106_p3() {
    or_ln110_1_fu_4106_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln110_7_reg_5441.read());
}

void BF_encrypt::thread_or_ln110_2_fu_4118_p3() {
    or_ln110_2_fu_4118_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln109_11_reg_5426.read());
}

void BF_encrypt::thread_or_ln111_1_fu_4302_p3() {
    or_ln111_1_fu_4302_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln111_4_reg_5496.read());
}

void BF_encrypt::thread_or_ln111_2_fu_4314_p3() {
    or_ln111_2_fu_4314_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln110_11_reg_5481.read());
}

void BF_encrypt::thread_or_ln11_fu_3349_p3() {
    or_ln11_fu_3349_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln11_reg_5205.read());
}

void BF_encrypt::thread_or_ln12_fu_3586_p3() {
    or_ln12_fu_3586_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln12_reg_5284.read());
}

void BF_encrypt::thread_or_ln13_fu_3819_p3() {
    or_ln13_fu_3819_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln13_reg_5376.read());
}

void BF_encrypt::thread_or_ln14_fu_4052_p3() {
    or_ln14_fu_4052_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln14_reg_5436.read());
}

void BF_encrypt::thread_or_ln15_fu_4290_p3() {
    or_ln15_fu_4290_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln15_reg_5491.read());
}

void BF_encrypt::thread_or_ln1_fu_1003_p3() {
    or_ln1_fu_1003_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln6_reg_4447.read());
}

void BF_encrypt::thread_or_ln2_fu_1240_p3() {
    or_ln2_fu_1240_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln7_reg_4558.read());
}

void BF_encrypt::thread_or_ln3_fu_1477_p3() {
    or_ln3_fu_1477_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln8_reg_4637.read());
}

void BF_encrypt::thread_or_ln4_fu_1714_p3() {
    or_ln4_fu_1714_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln9_reg_4708.read());
}

void BF_encrypt::thread_or_ln5_fu_1947_p3() {
    or_ln5_fu_1947_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln_reg_4779.read());
}

void BF_encrypt::thread_or_ln6_fu_2180_p3() {
    or_ln6_fu_2180_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln1_reg_4850.read());
}

void BF_encrypt::thread_or_ln7_fu_2413_p3() {
    or_ln7_fu_2413_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln2_reg_4921.read());
}

void BF_encrypt::thread_or_ln8_fu_2646_p3() {
    or_ln8_fu_2646_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln3_reg_4992.read());
}

void BF_encrypt::thread_or_ln96_1_fu_786_p3() {
    or_ln96_1_fu_786_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln96_7_reg_4391.read());
}

void BF_encrypt::thread_or_ln96_2_fu_816_p3() {
    or_ln96_2_fu_816_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln94_3_reg_4375.read());
}

void BF_encrypt::thread_or_ln97_1_fu_1039_p3() {
    or_ln97_1_fu_1039_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln97_7_reg_4452.read());
}

void BF_encrypt::thread_or_ln97_2_fu_1069_p3() {
    or_ln97_2_fu_1069_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln96_11_reg_4436.read());
}

void BF_encrypt::thread_or_ln98_1_fu_1276_p3() {
    or_ln98_1_fu_1276_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln98_7_reg_4563.read());
}

void BF_encrypt::thread_or_ln98_2_fu_1306_p3() {
    or_ln98_2_fu_1306_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln97_11_reg_4547.read());
}

void BF_encrypt::thread_or_ln99_1_fu_1513_p3() {
    or_ln99_1_fu_1513_p3 = esl_concat<2,8>(ap_const_lv2_2, trunc_ln99_7_reg_4642.read());
}

void BF_encrypt::thread_or_ln99_2_fu_1543_p3() {
    or_ln99_2_fu_1543_p3 = esl_concat<2,8>(ap_const_lv2_3, xor_ln98_11_reg_4626.read());
}

void BF_encrypt::thread_or_ln9_fu_2879_p3() {
    or_ln9_fu_2879_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln4_reg_5063.read());
}

void BF_encrypt::thread_or_ln_fu_739_p3() {
    or_ln_fu_739_p3 = esl_concat<1,8>(ap_const_lv1_1, trunc_ln5_fu_729_p4.read());
}

void BF_encrypt::thread_r_1_fu_1419_p2() {
    r_1_fu_1419_p2 = (xor_ln98_4_fu_1387_p2.read() ^ reg_657.read());
}

void BF_encrypt::thread_r_2_fu_1890_p2() {
    r_2_fu_1890_p2 = (xor_ln100_4_fu_1861_p2.read() ^ key_P_load_5_reg_4457.read());
}

void BF_encrypt::thread_r_3_fu_2356_p2() {
    r_3_fu_2356_p2 = (xor_ln102_4_fu_2327_p2.read() ^ key_P_load_7_reg_4483.read());
}

void BF_encrypt::thread_r_4_fu_2822_p2() {
    r_4_fu_2822_p2 = (xor_ln104_4_fu_2793_p2.read() ^ key_P_load_9_reg_4524.read());
}

void BF_encrypt::thread_r_5_fu_3292_p2() {
    r_5_fu_3292_p2 = (xor_ln106_4_fu_3263_p2.read() ^ key_P_load_11_reg_4568.read());
}

void BF_encrypt::thread_r_6_fu_3762_p2() {
    r_6_fu_3762_p2 = (xor_ln108_4_fu_3733_p2.read() ^ key_P_load_13_reg_5271.read());
}

void BF_encrypt::thread_r_7_fu_4228_p2() {
    r_7_fu_4228_p2 = (xor_ln110_4_fu_4199_p2.read() ^ key_P_load_15_reg_5302.read());
}

void BF_encrypt::thread_r_8_fu_4281_p2() {
    r_8_fu_4281_p2 = (key_P_load_17_reg_5320.read() ^ r_7_fu_4228_p2.read());
}

void BF_encrypt::thread_r_fu_945_p2() {
    r_fu_945_p2 = (xor_ln96_4_fu_909_p2.read() ^ reg_644.read());
}

void BF_encrypt::thread_trunc_ln100_10_fu_1815_p1() {
    trunc_ln100_10_fu_1815_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln100_11_fu_1824_p1() {
    trunc_ln100_11_fu_1824_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln100_12_fu_1833_p1() {
    trunc_ln100_12_fu_1833_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln100_13_fu_1866_p1() {
    trunc_ln100_13_fu_1866_p1 = key_P_load_5_reg_4457.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln100_14_fu_1874_p1() {
    trunc_ln100_14_fu_1874_p1 = key_P_load_5_reg_4457.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln100_15_fu_1882_p1() {
    trunc_ln100_15_fu_1882_p1 = key_P_load_5_reg_4457.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln100_1_fu_1730_p1() {
    trunc_ln100_1_fu_1730_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln100_2_fu_1734_p1() {
    trunc_ln100_2_fu_1734_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln100_3_fu_1738_p1() {
    trunc_ln100_3_fu_1738_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln100_4_fu_1742_p1() {
    trunc_ln100_4_fu_1742_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln100_5_fu_1746_p1() {
    trunc_ln100_5_fu_1746_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln100_6_fu_1792_p1() {
    trunc_ln100_6_fu_1792_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln100_8_fu_1796_p1() {
    trunc_ln100_8_fu_1796_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln100_9_fu_1800_p1() {
    trunc_ln100_9_fu_1800_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln100_fu_1726_p1() {
    trunc_ln100_fu_1726_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln101_10_fu_2048_p1() {
    trunc_ln101_10_fu_2048_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln101_11_fu_2057_p1() {
    trunc_ln101_11_fu_2057_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln101_12_fu_2066_p1() {
    trunc_ln101_12_fu_2066_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln101_13_fu_2099_p1() {
    trunc_ln101_13_fu_2099_p1 = key_P_load_6_reg_4475.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln101_14_fu_2107_p1() {
    trunc_ln101_14_fu_2107_p1 = key_P_load_6_reg_4475.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln101_15_fu_2115_p1() {
    trunc_ln101_15_fu_2115_p1 = key_P_load_6_reg_4475.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln101_1_fu_1963_p1() {
    trunc_ln101_1_fu_1963_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln101_2_fu_1967_p1() {
    trunc_ln101_2_fu_1967_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln101_3_fu_1971_p1() {
    trunc_ln101_3_fu_1971_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln101_4_fu_1975_p1() {
    trunc_ln101_4_fu_1975_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln101_5_fu_1979_p1() {
    trunc_ln101_5_fu_1979_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln101_6_fu_2025_p1() {
    trunc_ln101_6_fu_2025_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln101_8_fu_2029_p1() {
    trunc_ln101_8_fu_2029_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln101_9_fu_2033_p1() {
    trunc_ln101_9_fu_2033_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln101_fu_1959_p1() {
    trunc_ln101_fu_1959_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln102_10_fu_2281_p1() {
    trunc_ln102_10_fu_2281_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln102_11_fu_2290_p1() {
    trunc_ln102_11_fu_2290_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln102_12_fu_2299_p1() {
    trunc_ln102_12_fu_2299_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln102_13_fu_2332_p1() {
    trunc_ln102_13_fu_2332_p1 = key_P_load_7_reg_4483.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln102_14_fu_2340_p1() {
    trunc_ln102_14_fu_2340_p1 = key_P_load_7_reg_4483.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln102_15_fu_2348_p1() {
    trunc_ln102_15_fu_2348_p1 = key_P_load_7_reg_4483.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln102_1_fu_2196_p1() {
    trunc_ln102_1_fu_2196_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln102_2_fu_2200_p1() {
    trunc_ln102_2_fu_2200_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln102_3_fu_2204_p1() {
    trunc_ln102_3_fu_2204_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln102_4_fu_2208_p1() {
    trunc_ln102_4_fu_2208_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln102_5_fu_2212_p1() {
    trunc_ln102_5_fu_2212_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln102_6_fu_2258_p1() {
    trunc_ln102_6_fu_2258_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln102_8_fu_2262_p1() {
    trunc_ln102_8_fu_2262_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln102_9_fu_2266_p1() {
    trunc_ln102_9_fu_2266_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln102_fu_2192_p1() {
    trunc_ln102_fu_2192_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln103_10_fu_2514_p1() {
    trunc_ln103_10_fu_2514_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln103_11_fu_2523_p1() {
    trunc_ln103_11_fu_2523_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln103_12_fu_2532_p1() {
    trunc_ln103_12_fu_2532_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln103_13_fu_2565_p1() {
    trunc_ln103_13_fu_2565_p1 = key_P_load_8_reg_4516.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln103_14_fu_2573_p1() {
    trunc_ln103_14_fu_2573_p1 = key_P_load_8_reg_4516.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln103_15_fu_2581_p1() {
    trunc_ln103_15_fu_2581_p1 = key_P_load_8_reg_4516.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln103_1_fu_2429_p1() {
    trunc_ln103_1_fu_2429_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln103_2_fu_2433_p1() {
    trunc_ln103_2_fu_2433_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln103_3_fu_2437_p1() {
    trunc_ln103_3_fu_2437_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln103_4_fu_2441_p1() {
    trunc_ln103_4_fu_2441_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln103_5_fu_2445_p1() {
    trunc_ln103_5_fu_2445_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln103_6_fu_2491_p1() {
    trunc_ln103_6_fu_2491_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln103_8_fu_2495_p1() {
    trunc_ln103_8_fu_2495_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln103_9_fu_2499_p1() {
    trunc_ln103_9_fu_2499_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln103_fu_2425_p1() {
    trunc_ln103_fu_2425_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln104_10_fu_2747_p1() {
    trunc_ln104_10_fu_2747_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln104_11_fu_2756_p1() {
    trunc_ln104_11_fu_2756_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln104_12_fu_2765_p1() {
    trunc_ln104_12_fu_2765_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln104_13_fu_2798_p1() {
    trunc_ln104_13_fu_2798_p1 = key_P_load_9_reg_4524.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln104_14_fu_2806_p1() {
    trunc_ln104_14_fu_2806_p1 = key_P_load_9_reg_4524.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln104_15_fu_2814_p1() {
    trunc_ln104_15_fu_2814_p1 = key_P_load_9_reg_4524.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln104_1_fu_2662_p1() {
    trunc_ln104_1_fu_2662_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln104_2_fu_2666_p1() {
    trunc_ln104_2_fu_2666_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln104_3_fu_2670_p1() {
    trunc_ln104_3_fu_2670_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln104_4_fu_2674_p1() {
    trunc_ln104_4_fu_2674_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln104_5_fu_2678_p1() {
    trunc_ln104_5_fu_2678_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln104_6_fu_2724_p1() {
    trunc_ln104_6_fu_2724_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln104_8_fu_2728_p1() {
    trunc_ln104_8_fu_2728_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln104_9_fu_2732_p1() {
    trunc_ln104_9_fu_2732_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln104_fu_2658_p1() {
    trunc_ln104_fu_2658_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln105_10_fu_2980_p1() {
    trunc_ln105_10_fu_2980_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln105_11_fu_2989_p1() {
    trunc_ln105_11_fu_2989_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln105_12_fu_2998_p1() {
    trunc_ln105_12_fu_2998_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln105_13_fu_3031_p1() {
    trunc_ln105_13_fu_3031_p1 = reg_653.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln105_14_fu_3040_p1() {
    trunc_ln105_14_fu_3040_p1 = reg_653.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln105_15_fu_3049_p1() {
    trunc_ln105_15_fu_3049_p1 = reg_653.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln105_1_fu_2895_p1() {
    trunc_ln105_1_fu_2895_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln105_2_fu_2899_p1() {
    trunc_ln105_2_fu_2899_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln105_3_fu_2903_p1() {
    trunc_ln105_3_fu_2903_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln105_4_fu_2907_p1() {
    trunc_ln105_4_fu_2907_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln105_5_fu_2911_p1() {
    trunc_ln105_5_fu_2911_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln105_6_fu_2957_p1() {
    trunc_ln105_6_fu_2957_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln105_8_fu_2961_p1() {
    trunc_ln105_8_fu_2961_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln105_9_fu_2965_p1() {
    trunc_ln105_9_fu_2965_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln105_fu_2891_p1() {
    trunc_ln105_fu_2891_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln106_10_fu_3217_p1() {
    trunc_ln106_10_fu_3217_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln106_11_fu_3226_p1() {
    trunc_ln106_11_fu_3226_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln106_12_fu_3235_p1() {
    trunc_ln106_12_fu_3235_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln106_13_fu_3268_p1() {
    trunc_ln106_13_fu_3268_p1 = key_P_load_11_reg_4568.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln106_14_fu_3276_p1() {
    trunc_ln106_14_fu_3276_p1 = key_P_load_11_reg_4568.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln106_15_fu_3284_p1() {
    trunc_ln106_15_fu_3284_p1 = key_P_load_11_reg_4568.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln106_1_fu_3132_p1() {
    trunc_ln106_1_fu_3132_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln106_2_fu_3136_p1() {
    trunc_ln106_2_fu_3136_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln106_3_fu_3140_p1() {
    trunc_ln106_3_fu_3140_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln106_4_fu_3144_p1() {
    trunc_ln106_4_fu_3144_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln106_5_fu_3148_p1() {
    trunc_ln106_5_fu_3148_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln106_6_fu_3194_p1() {
    trunc_ln106_6_fu_3194_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln106_8_fu_3198_p1() {
    trunc_ln106_8_fu_3198_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln106_9_fu_3202_p1() {
    trunc_ln106_9_fu_3202_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln106_fu_3128_p1() {
    trunc_ln106_fu_3128_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln107_10_fu_3450_p1() {
    trunc_ln107_10_fu_3450_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln107_11_fu_3459_p1() {
    trunc_ln107_11_fu_3459_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln107_12_fu_3468_p1() {
    trunc_ln107_12_fu_3468_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln107_13_fu_3501_p1() {
    trunc_ln107_13_fu_3501_p1 = key_P_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln107_14_fu_3510_p1() {
    trunc_ln107_14_fu_3510_p1 = key_P_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln107_15_fu_3519_p1() {
    trunc_ln107_15_fu_3519_p1 = key_P_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln107_1_fu_3365_p1() {
    trunc_ln107_1_fu_3365_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln107_2_fu_3369_p1() {
    trunc_ln107_2_fu_3369_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln107_3_fu_3373_p1() {
    trunc_ln107_3_fu_3373_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln107_4_fu_3377_p1() {
    trunc_ln107_4_fu_3377_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln107_5_fu_3381_p1() {
    trunc_ln107_5_fu_3381_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln107_6_fu_3427_p1() {
    trunc_ln107_6_fu_3427_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln107_8_fu_3431_p1() {
    trunc_ln107_8_fu_3431_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln107_9_fu_3435_p1() {
    trunc_ln107_9_fu_3435_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln107_fu_3361_p1() {
    trunc_ln107_fu_3361_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln108_10_fu_3687_p1() {
    trunc_ln108_10_fu_3687_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln108_11_fu_3696_p1() {
    trunc_ln108_11_fu_3696_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln108_12_fu_3705_p1() {
    trunc_ln108_12_fu_3705_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln108_13_fu_3738_p1() {
    trunc_ln108_13_fu_3738_p1 = key_P_load_13_reg_5271.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln108_14_fu_3746_p1() {
    trunc_ln108_14_fu_3746_p1 = key_P_load_13_reg_5271.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln108_15_fu_3754_p1() {
    trunc_ln108_15_fu_3754_p1 = key_P_load_13_reg_5271.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln108_1_fu_3602_p1() {
    trunc_ln108_1_fu_3602_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln108_2_fu_3606_p1() {
    trunc_ln108_2_fu_3606_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln108_3_fu_3610_p1() {
    trunc_ln108_3_fu_3610_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln108_4_fu_3614_p1() {
    trunc_ln108_4_fu_3614_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln108_5_fu_3618_p1() {
    trunc_ln108_5_fu_3618_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln108_6_fu_3664_p1() {
    trunc_ln108_6_fu_3664_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln108_8_fu_3668_p1() {
    trunc_ln108_8_fu_3668_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln108_9_fu_3672_p1() {
    trunc_ln108_9_fu_3672_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln108_fu_3598_p1() {
    trunc_ln108_fu_3598_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln109_10_fu_3920_p1() {
    trunc_ln109_10_fu_3920_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln109_11_fu_3929_p1() {
    trunc_ln109_11_fu_3929_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln109_12_fu_3938_p1() {
    trunc_ln109_12_fu_3938_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln109_13_fu_3971_p1() {
    trunc_ln109_13_fu_3971_p1 = key_P_load_14_reg_5294.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln109_14_fu_3979_p1() {
    trunc_ln109_14_fu_3979_p1 = key_P_load_14_reg_5294.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln109_15_fu_3987_p1() {
    trunc_ln109_15_fu_3987_p1 = key_P_load_14_reg_5294.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln109_1_fu_3835_p1() {
    trunc_ln109_1_fu_3835_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln109_2_fu_3839_p1() {
    trunc_ln109_2_fu_3839_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln109_3_fu_3843_p1() {
    trunc_ln109_3_fu_3843_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln109_4_fu_3847_p1() {
    trunc_ln109_4_fu_3847_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln109_5_fu_3851_p1() {
    trunc_ln109_5_fu_3851_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln109_6_fu_3897_p1() {
    trunc_ln109_6_fu_3897_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln109_8_fu_3901_p1() {
    trunc_ln109_8_fu_3901_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln109_9_fu_3905_p1() {
    trunc_ln109_9_fu_3905_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln109_fu_3831_p1() {
    trunc_ln109_fu_3831_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln110_10_fu_4153_p1() {
    trunc_ln110_10_fu_4153_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln110_11_fu_4162_p1() {
    trunc_ln110_11_fu_4162_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln110_12_fu_4171_p1() {
    trunc_ln110_12_fu_4171_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln110_13_fu_4204_p1() {
    trunc_ln110_13_fu_4204_p1 = key_P_load_15_reg_5302.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln110_14_fu_4212_p1() {
    trunc_ln110_14_fu_4212_p1 = key_P_load_15_reg_5302.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln110_15_fu_4220_p1() {
    trunc_ln110_15_fu_4220_p1 = key_P_load_15_reg_5302.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln110_1_fu_4068_p1() {
    trunc_ln110_1_fu_4068_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln110_2_fu_4072_p1() {
    trunc_ln110_2_fu_4072_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln110_3_fu_4076_p1() {
    trunc_ln110_3_fu_4076_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln110_4_fu_4080_p1() {
    trunc_ln110_4_fu_4080_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln110_5_fu_4084_p1() {
    trunc_ln110_5_fu_4084_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln110_6_fu_4130_p1() {
    trunc_ln110_6_fu_4130_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln110_8_fu_4134_p1() {
    trunc_ln110_8_fu_4134_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln110_9_fu_4138_p1() {
    trunc_ln110_9_fu_4138_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln110_fu_4064_p1() {
    trunc_ln110_fu_4064_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln5_fu_729_p4() {
    trunc_ln5_fu_729_p4 = xor_ln94_2_fu_702_p2.read().range(23, 16);
}

void BF_encrypt::thread_trunc_ln94_1_fu_670_p1() {
    trunc_ln94_1_fu_670_p1 = key_P_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln94_2_fu_674_p1() {
    trunc_ln94_2_fu_674_p1 = ap_port_reg_data_0_read.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln94_3_fu_678_p1() {
    trunc_ln94_3_fu_678_p1 = key_P_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln94_4_fu_682_p1() {
    trunc_ln94_4_fu_682_p1 = ap_port_reg_data_0_read.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln94_5_fu_686_p1() {
    trunc_ln94_5_fu_686_p1 = key_P_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln94_fu_666_p1() {
    trunc_ln94_fu_666_p1 = ap_port_reg_data_0_read.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_10_fu_851_p1() {
    trunc_ln96_10_fu_851_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_11_fu_860_p1() {
    trunc_ln96_11_fu_860_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_12_fu_869_p1() {
    trunc_ln96_12_fu_869_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_13_fu_879_p1() {
    trunc_ln96_13_fu_879_p1 = ap_port_reg_data_1_read.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_14_fu_889_p1() {
    trunc_ln96_14_fu_889_p1 = ap_port_reg_data_1_read.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_15_fu_899_p1() {
    trunc_ln96_15_fu_899_p1 = ap_port_reg_data_1_read.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_16_fu_915_p1() {
    trunc_ln96_16_fu_915_p1 = reg_644.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_17_fu_925_p1() {
    trunc_ln96_17_fu_925_p1 = reg_644.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_18_fu_935_p1() {
    trunc_ln96_18_fu_935_p1 = reg_644.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_1_fu_766_p1() {
    trunc_ln96_1_fu_766_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_2_fu_770_p1() {
    trunc_ln96_2_fu_770_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_3_fu_774_p1() {
    trunc_ln96_3_fu_774_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_4_fu_778_p1() {
    trunc_ln96_4_fu_778_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_5_fu_782_p1() {
    trunc_ln96_5_fu_782_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_6_fu_828_p1() {
    trunc_ln96_6_fu_828_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln96_8_fu_832_p1() {
    trunc_ln96_8_fu_832_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln96_9_fu_836_p1() {
    trunc_ln96_9_fu_836_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln96_fu_762_p1() {
    trunc_ln96_fu_762_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln97_10_fu_1104_p1() {
    trunc_ln97_10_fu_1104_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln97_11_fu_1113_p1() {
    trunc_ln97_11_fu_1113_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln97_12_fu_1122_p1() {
    trunc_ln97_12_fu_1122_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln97_13_fu_1155_p1() {
    trunc_ln97_13_fu_1155_p1 = reg_653.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln97_14_fu_1164_p1() {
    trunc_ln97_14_fu_1164_p1 = reg_653.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln97_15_fu_1173_p1() {
    trunc_ln97_15_fu_1173_p1 = reg_653.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln97_1_fu_1019_p1() {
    trunc_ln97_1_fu_1019_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln97_2_fu_1023_p1() {
    trunc_ln97_2_fu_1023_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln97_3_fu_1027_p1() {
    trunc_ln97_3_fu_1027_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln97_4_fu_1031_p1() {
    trunc_ln97_4_fu_1031_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln97_5_fu_1035_p1() {
    trunc_ln97_5_fu_1035_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln97_6_fu_1081_p1() {
    trunc_ln97_6_fu_1081_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln97_8_fu_1085_p1() {
    trunc_ln97_8_fu_1085_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln97_9_fu_1089_p1() {
    trunc_ln97_9_fu_1089_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln97_fu_1015_p1() {
    trunc_ln97_fu_1015_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln98_10_fu_1341_p1() {
    trunc_ln98_10_fu_1341_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln98_11_fu_1350_p1() {
    trunc_ln98_11_fu_1350_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln98_12_fu_1359_p1() {
    trunc_ln98_12_fu_1359_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln98_13_fu_1392_p1() {
    trunc_ln98_13_fu_1392_p1 = reg_657.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln98_14_fu_1401_p1() {
    trunc_ln98_14_fu_1401_p1 = reg_657.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln98_15_fu_1410_p1() {
    trunc_ln98_15_fu_1410_p1 = reg_657.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln98_1_fu_1256_p1() {
    trunc_ln98_1_fu_1256_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln98_2_fu_1260_p1() {
    trunc_ln98_2_fu_1260_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln98_3_fu_1264_p1() {
    trunc_ln98_3_fu_1264_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln98_4_fu_1268_p1() {
    trunc_ln98_4_fu_1268_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln98_5_fu_1272_p1() {
    trunc_ln98_5_fu_1272_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln98_6_fu_1318_p1() {
    trunc_ln98_6_fu_1318_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln98_8_fu_1322_p1() {
    trunc_ln98_8_fu_1322_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln98_9_fu_1326_p1() {
    trunc_ln98_9_fu_1326_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln98_fu_1252_p1() {
    trunc_ln98_fu_1252_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln99_10_fu_1578_p1() {
    trunc_ln99_10_fu_1578_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln99_11_fu_1587_p1() {
    trunc_ln99_11_fu_1587_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln99_12_fu_1596_p1() {
    trunc_ln99_12_fu_1596_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln99_13_fu_1629_p1() {
    trunc_ln99_13_fu_1629_p1 = reg_644.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln99_14_fu_1638_p1() {
    trunc_ln99_14_fu_1638_p1 = reg_644.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln99_15_fu_1647_p1() {
    trunc_ln99_15_fu_1647_p1 = reg_644.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln99_1_fu_1493_p1() {
    trunc_ln99_1_fu_1493_p1 = key_S_q1.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln99_2_fu_1497_p1() {
    trunc_ln99_2_fu_1497_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln99_3_fu_1501_p1() {
    trunc_ln99_3_fu_1501_p1 = key_S_q1.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln99_4_fu_1505_p1() {
    trunc_ln99_4_fu_1505_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln99_5_fu_1509_p1() {
    trunc_ln99_5_fu_1509_p1 = key_S_q1.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln99_6_fu_1555_p1() {
    trunc_ln99_6_fu_1555_p1 = key_S_q0.read().range(16-1, 0);
}

void BF_encrypt::thread_trunc_ln99_8_fu_1559_p1() {
    trunc_ln99_8_fu_1559_p1 = key_S_q0.read().range(24-1, 0);
}

void BF_encrypt::thread_trunc_ln99_9_fu_1563_p1() {
    trunc_ln99_9_fu_1563_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_trunc_ln99_fu_1489_p1() {
    trunc_ln99_fu_1489_p1 = key_S_q0.read().range(8-1, 0);
}

void BF_encrypt::thread_xor_ln100_10_fu_1901_p2() {
    xor_ln100_10_fu_1901_p2 = (xor_ln100_6_fu_1877_p2.read() ^ trunc_ln100_14_fu_1874_p1.read());
}

void BF_encrypt::thread_xor_ln100_11_fu_1907_p2() {
    xor_ln100_11_fu_1907_p2 = (xor_ln100_5_fu_1869_p2.read() ^ trunc_ln100_13_fu_1866_p1.read());
}

void BF_encrypt::thread_xor_ln100_1_fu_1810_p2() {
    xor_ln100_1_fu_1810_p2 = (trunc_ln100_9_fu_1800_p1.read() ^ add_ln100_4_reg_4743.read());
}

void BF_encrypt::thread_xor_ln100_2_fu_1819_p2() {
    xor_ln100_2_fu_1819_p2 = (trunc_ln100_8_fu_1796_p1.read() ^ add_ln100_3_reg_4738.read());
}

void BF_encrypt::thread_xor_ln100_3_fu_1828_p2() {
    xor_ln100_3_fu_1828_p2 = (trunc_ln100_6_fu_1792_p1.read() ^ add_ln100_2_reg_4733.read());
}

void BF_encrypt::thread_xor_ln100_4_fu_1861_p2() {
    xor_ln100_4_fu_1861_p2 = (r_1_reg_4611.read() ^ add_ln100_1_fu_1837_p2.read());
}

void BF_encrypt::thread_xor_ln100_5_fu_1869_p2() {
    xor_ln100_5_fu_1869_p2 = (xor_ln98_11_reg_4626.read() ^ add_ln100_7_fu_1855_p2.read());
}

void BF_encrypt::thread_xor_ln100_6_fu_1877_p2() {
    xor_ln100_6_fu_1877_p2 = (xor_ln98_10_reg_4621.read() ^ add_ln100_6_fu_1849_p2.read());
}

void BF_encrypt::thread_xor_ln100_7_fu_1885_p2() {
    xor_ln100_7_fu_1885_p2 = (xor_ln98_9_reg_4616.read() ^ add_ln100_5_fu_1843_p2.read());
}

void BF_encrypt::thread_xor_ln100_9_fu_1895_p2() {
    xor_ln100_9_fu_1895_p2 = (xor_ln100_7_fu_1885_p2.read() ^ trunc_ln100_15_fu_1882_p1.read());
}

void BF_encrypt::thread_xor_ln100_fu_1804_p2() {
    xor_ln100_fu_1804_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln101_10_fu_2134_p2() {
    xor_ln101_10_fu_2134_p2 = (xor_ln101_6_fu_2110_p2.read() ^ trunc_ln101_14_fu_2107_p1.read());
}

void BF_encrypt::thread_xor_ln101_11_fu_2140_p2() {
    xor_ln101_11_fu_2140_p2 = (xor_ln101_5_fu_2102_p2.read() ^ trunc_ln101_13_fu_2099_p1.read());
}

void BF_encrypt::thread_xor_ln101_1_fu_2043_p2() {
    xor_ln101_1_fu_2043_p2 = (trunc_ln101_9_fu_2033_p1.read() ^ add_ln101_4_reg_4814.read());
}

void BF_encrypt::thread_xor_ln101_2_fu_2052_p2() {
    xor_ln101_2_fu_2052_p2 = (trunc_ln101_8_fu_2029_p1.read() ^ add_ln101_3_reg_4809.read());
}

void BF_encrypt::thread_xor_ln101_3_fu_2061_p2() {
    xor_ln101_3_fu_2061_p2 = (trunc_ln101_6_fu_2025_p1.read() ^ add_ln101_2_reg_4804.read());
}

void BF_encrypt::thread_xor_ln101_4_fu_2094_p2() {
    xor_ln101_4_fu_2094_p2 = (l_5_reg_4682.read() ^ add_ln101_1_fu_2070_p2.read());
}

void BF_encrypt::thread_xor_ln101_5_fu_2102_p2() {
    xor_ln101_5_fu_2102_p2 = (xor_ln99_11_reg_4697.read() ^ add_ln101_7_fu_2088_p2.read());
}

void BF_encrypt::thread_xor_ln101_6_fu_2110_p2() {
    xor_ln101_6_fu_2110_p2 = (xor_ln99_10_reg_4692.read() ^ add_ln101_6_fu_2082_p2.read());
}

void BF_encrypt::thread_xor_ln101_7_fu_2118_p2() {
    xor_ln101_7_fu_2118_p2 = (xor_ln99_9_reg_4687.read() ^ add_ln101_5_fu_2076_p2.read());
}

void BF_encrypt::thread_xor_ln101_9_fu_2128_p2() {
    xor_ln101_9_fu_2128_p2 = (xor_ln101_7_fu_2118_p2.read() ^ trunc_ln101_15_fu_2115_p1.read());
}

void BF_encrypt::thread_xor_ln101_fu_2037_p2() {
    xor_ln101_fu_2037_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln102_10_fu_2367_p2() {
    xor_ln102_10_fu_2367_p2 = (xor_ln102_6_fu_2343_p2.read() ^ trunc_ln102_14_fu_2340_p1.read());
}

void BF_encrypt::thread_xor_ln102_11_fu_2373_p2() {
    xor_ln102_11_fu_2373_p2 = (xor_ln102_5_fu_2335_p2.read() ^ trunc_ln102_13_fu_2332_p1.read());
}

void BF_encrypt::thread_xor_ln102_1_fu_2276_p2() {
    xor_ln102_1_fu_2276_p2 = (trunc_ln102_9_fu_2266_p1.read() ^ add_ln102_4_reg_4885.read());
}

void BF_encrypt::thread_xor_ln102_2_fu_2285_p2() {
    xor_ln102_2_fu_2285_p2 = (trunc_ln102_8_fu_2262_p1.read() ^ add_ln102_3_reg_4880.read());
}

void BF_encrypt::thread_xor_ln102_3_fu_2294_p2() {
    xor_ln102_3_fu_2294_p2 = (trunc_ln102_6_fu_2258_p1.read() ^ add_ln102_2_reg_4875.read());
}

void BF_encrypt::thread_xor_ln102_4_fu_2327_p2() {
    xor_ln102_4_fu_2327_p2 = (r_2_reg_4753.read() ^ add_ln102_1_fu_2303_p2.read());
}

void BF_encrypt::thread_xor_ln102_5_fu_2335_p2() {
    xor_ln102_5_fu_2335_p2 = (xor_ln100_11_reg_4768.read() ^ add_ln102_7_fu_2321_p2.read());
}

void BF_encrypt::thread_xor_ln102_6_fu_2343_p2() {
    xor_ln102_6_fu_2343_p2 = (xor_ln100_10_reg_4763.read() ^ add_ln102_6_fu_2315_p2.read());
}

void BF_encrypt::thread_xor_ln102_7_fu_2351_p2() {
    xor_ln102_7_fu_2351_p2 = (xor_ln100_9_reg_4758.read() ^ add_ln102_5_fu_2309_p2.read());
}

void BF_encrypt::thread_xor_ln102_9_fu_2361_p2() {
    xor_ln102_9_fu_2361_p2 = (xor_ln102_7_fu_2351_p2.read() ^ trunc_ln102_15_fu_2348_p1.read());
}

void BF_encrypt::thread_xor_ln102_fu_2270_p2() {
    xor_ln102_fu_2270_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln103_10_fu_2600_p2() {
    xor_ln103_10_fu_2600_p2 = (xor_ln103_6_fu_2576_p2.read() ^ trunc_ln103_14_fu_2573_p1.read());
}

void BF_encrypt::thread_xor_ln103_11_fu_2606_p2() {
    xor_ln103_11_fu_2606_p2 = (xor_ln103_5_fu_2568_p2.read() ^ trunc_ln103_13_fu_2565_p1.read());
}

void BF_encrypt::thread_xor_ln103_1_fu_2509_p2() {
    xor_ln103_1_fu_2509_p2 = (trunc_ln103_9_fu_2499_p1.read() ^ add_ln103_4_reg_4956.read());
}

void BF_encrypt::thread_xor_ln103_2_fu_2518_p2() {
    xor_ln103_2_fu_2518_p2 = (trunc_ln103_8_fu_2495_p1.read() ^ add_ln103_3_reg_4951.read());
}

void BF_encrypt::thread_xor_ln103_3_fu_2527_p2() {
    xor_ln103_3_fu_2527_p2 = (trunc_ln103_6_fu_2491_p1.read() ^ add_ln103_2_reg_4946.read());
}

void BF_encrypt::thread_xor_ln103_4_fu_2560_p2() {
    xor_ln103_4_fu_2560_p2 = (l_6_reg_4824.read() ^ add_ln103_1_fu_2536_p2.read());
}

void BF_encrypt::thread_xor_ln103_5_fu_2568_p2() {
    xor_ln103_5_fu_2568_p2 = (xor_ln101_11_reg_4839.read() ^ add_ln103_7_fu_2554_p2.read());
}

void BF_encrypt::thread_xor_ln103_6_fu_2576_p2() {
    xor_ln103_6_fu_2576_p2 = (xor_ln101_10_reg_4834.read() ^ add_ln103_6_fu_2548_p2.read());
}

void BF_encrypt::thread_xor_ln103_7_fu_2584_p2() {
    xor_ln103_7_fu_2584_p2 = (xor_ln101_9_reg_4829.read() ^ add_ln103_5_fu_2542_p2.read());
}

void BF_encrypt::thread_xor_ln103_9_fu_2594_p2() {
    xor_ln103_9_fu_2594_p2 = (xor_ln103_7_fu_2584_p2.read() ^ trunc_ln103_15_fu_2581_p1.read());
}

void BF_encrypt::thread_xor_ln103_fu_2503_p2() {
    xor_ln103_fu_2503_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln104_10_fu_2833_p2() {
    xor_ln104_10_fu_2833_p2 = (xor_ln104_6_fu_2809_p2.read() ^ trunc_ln104_14_fu_2806_p1.read());
}

void BF_encrypt::thread_xor_ln104_11_fu_2839_p2() {
    xor_ln104_11_fu_2839_p2 = (xor_ln104_5_fu_2801_p2.read() ^ trunc_ln104_13_fu_2798_p1.read());
}

void BF_encrypt::thread_xor_ln104_1_fu_2742_p2() {
    xor_ln104_1_fu_2742_p2 = (trunc_ln104_9_fu_2732_p1.read() ^ add_ln104_4_reg_5027.read());
}

void BF_encrypt::thread_xor_ln104_2_fu_2751_p2() {
    xor_ln104_2_fu_2751_p2 = (trunc_ln104_8_fu_2728_p1.read() ^ add_ln104_3_reg_5022.read());
}

void BF_encrypt::thread_xor_ln104_3_fu_2760_p2() {
    xor_ln104_3_fu_2760_p2 = (trunc_ln104_6_fu_2724_p1.read() ^ add_ln104_2_reg_5017.read());
}

void BF_encrypt::thread_xor_ln104_4_fu_2793_p2() {
    xor_ln104_4_fu_2793_p2 = (r_3_reg_4895.read() ^ add_ln104_1_fu_2769_p2.read());
}

void BF_encrypt::thread_xor_ln104_5_fu_2801_p2() {
    xor_ln104_5_fu_2801_p2 = (xor_ln102_11_reg_4910.read() ^ add_ln104_7_fu_2787_p2.read());
}

void BF_encrypt::thread_xor_ln104_6_fu_2809_p2() {
    xor_ln104_6_fu_2809_p2 = (xor_ln102_10_reg_4905.read() ^ add_ln104_6_fu_2781_p2.read());
}

void BF_encrypt::thread_xor_ln104_7_fu_2817_p2() {
    xor_ln104_7_fu_2817_p2 = (xor_ln102_9_reg_4900.read() ^ add_ln104_5_fu_2775_p2.read());
}

void BF_encrypt::thread_xor_ln104_9_fu_2827_p2() {
    xor_ln104_9_fu_2827_p2 = (xor_ln104_7_fu_2817_p2.read() ^ trunc_ln104_15_fu_2814_p1.read());
}

void BF_encrypt::thread_xor_ln104_fu_2736_p2() {
    xor_ln104_fu_2736_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln105_10_fu_3070_p2() {
    xor_ln105_10_fu_3070_p2 = (xor_ln105_6_fu_3044_p2.read() ^ trunc_ln105_14_fu_3040_p1.read());
}

void BF_encrypt::thread_xor_ln105_11_fu_3076_p2() {
    xor_ln105_11_fu_3076_p2 = (xor_ln105_5_fu_3035_p2.read() ^ trunc_ln105_13_fu_3031_p1.read());
}

void BF_encrypt::thread_xor_ln105_1_fu_2975_p2() {
    xor_ln105_1_fu_2975_p2 = (trunc_ln105_9_fu_2965_p1.read() ^ add_ln105_4_reg_5098.read());
}

void BF_encrypt::thread_xor_ln105_2_fu_2984_p2() {
    xor_ln105_2_fu_2984_p2 = (trunc_ln105_8_fu_2961_p1.read() ^ add_ln105_3_reg_5093.read());
}

void BF_encrypt::thread_xor_ln105_3_fu_2993_p2() {
    xor_ln105_3_fu_2993_p2 = (trunc_ln105_6_fu_2957_p1.read() ^ add_ln105_2_reg_5088.read());
}

void BF_encrypt::thread_xor_ln105_4_fu_3026_p2() {
    xor_ln105_4_fu_3026_p2 = (l_7_reg_4966.read() ^ add_ln105_1_fu_3002_p2.read());
}

void BF_encrypt::thread_xor_ln105_5_fu_3035_p2() {
    xor_ln105_5_fu_3035_p2 = (xor_ln103_11_reg_4981.read() ^ add_ln105_7_fu_3020_p2.read());
}

void BF_encrypt::thread_xor_ln105_6_fu_3044_p2() {
    xor_ln105_6_fu_3044_p2 = (xor_ln103_10_reg_4976.read() ^ add_ln105_6_fu_3014_p2.read());
}

void BF_encrypt::thread_xor_ln105_7_fu_3053_p2() {
    xor_ln105_7_fu_3053_p2 = (xor_ln103_9_reg_4971.read() ^ add_ln105_5_fu_3008_p2.read());
}

void BF_encrypt::thread_xor_ln105_9_fu_3064_p2() {
    xor_ln105_9_fu_3064_p2 = (xor_ln105_7_fu_3053_p2.read() ^ trunc_ln105_15_fu_3049_p1.read());
}

void BF_encrypt::thread_xor_ln105_fu_2969_p2() {
    xor_ln105_fu_2969_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln106_10_fu_3303_p2() {
    xor_ln106_10_fu_3303_p2 = (xor_ln106_6_fu_3279_p2.read() ^ trunc_ln106_14_fu_3276_p1.read());
}

void BF_encrypt::thread_xor_ln106_11_fu_3309_p2() {
    xor_ln106_11_fu_3309_p2 = (xor_ln106_5_fu_3271_p2.read() ^ trunc_ln106_13_fu_3268_p1.read());
}

void BF_encrypt::thread_xor_ln106_1_fu_3212_p2() {
    xor_ln106_1_fu_3212_p2 = (trunc_ln106_9_fu_3202_p1.read() ^ add_ln106_4_reg_5169.read());
}

void BF_encrypt::thread_xor_ln106_2_fu_3221_p2() {
    xor_ln106_2_fu_3221_p2 = (trunc_ln106_8_fu_3198_p1.read() ^ add_ln106_3_reg_5164.read());
}

void BF_encrypt::thread_xor_ln106_3_fu_3230_p2() {
    xor_ln106_3_fu_3230_p2 = (trunc_ln106_6_fu_3194_p1.read() ^ add_ln106_2_reg_5159.read());
}

void BF_encrypt::thread_xor_ln106_4_fu_3263_p2() {
    xor_ln106_4_fu_3263_p2 = (r_4_reg_5037.read() ^ add_ln106_1_fu_3239_p2.read());
}

void BF_encrypt::thread_xor_ln106_5_fu_3271_p2() {
    xor_ln106_5_fu_3271_p2 = (xor_ln104_11_reg_5052.read() ^ add_ln106_7_fu_3257_p2.read());
}

void BF_encrypt::thread_xor_ln106_6_fu_3279_p2() {
    xor_ln106_6_fu_3279_p2 = (xor_ln104_10_reg_5047.read() ^ add_ln106_6_fu_3251_p2.read());
}

void BF_encrypt::thread_xor_ln106_7_fu_3287_p2() {
    xor_ln106_7_fu_3287_p2 = (xor_ln104_9_reg_5042.read() ^ add_ln106_5_fu_3245_p2.read());
}

void BF_encrypt::thread_xor_ln106_9_fu_3297_p2() {
    xor_ln106_9_fu_3297_p2 = (xor_ln106_7_fu_3287_p2.read() ^ trunc_ln106_15_fu_3284_p1.read());
}

void BF_encrypt::thread_xor_ln106_fu_3206_p2() {
    xor_ln106_fu_3206_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln107_10_fu_3540_p2() {
    xor_ln107_10_fu_3540_p2 = (xor_ln107_6_fu_3514_p2.read() ^ trunc_ln107_14_fu_3510_p1.read());
}

void BF_encrypt::thread_xor_ln107_11_fu_3546_p2() {
    xor_ln107_11_fu_3546_p2 = (xor_ln107_5_fu_3505_p2.read() ^ trunc_ln107_13_fu_3501_p1.read());
}

void BF_encrypt::thread_xor_ln107_1_fu_3445_p2() {
    xor_ln107_1_fu_3445_p2 = (trunc_ln107_9_fu_3435_p1.read() ^ add_ln107_4_reg_5235.read());
}

void BF_encrypt::thread_xor_ln107_2_fu_3454_p2() {
    xor_ln107_2_fu_3454_p2 = (trunc_ln107_8_fu_3431_p1.read() ^ add_ln107_3_reg_5230.read());
}

void BF_encrypt::thread_xor_ln107_3_fu_3463_p2() {
    xor_ln107_3_fu_3463_p2 = (trunc_ln107_6_fu_3427_p1.read() ^ add_ln107_2_reg_5225.read());
}

void BF_encrypt::thread_xor_ln107_4_fu_3496_p2() {
    xor_ln107_4_fu_3496_p2 = (l_8_reg_5108.read() ^ add_ln107_1_fu_3472_p2.read());
}

void BF_encrypt::thread_xor_ln107_5_fu_3505_p2() {
    xor_ln107_5_fu_3505_p2 = (xor_ln105_11_reg_5123.read() ^ add_ln107_7_fu_3490_p2.read());
}

void BF_encrypt::thread_xor_ln107_6_fu_3514_p2() {
    xor_ln107_6_fu_3514_p2 = (xor_ln105_10_reg_5118.read() ^ add_ln107_6_fu_3484_p2.read());
}

void BF_encrypt::thread_xor_ln107_7_fu_3523_p2() {
    xor_ln107_7_fu_3523_p2 = (xor_ln105_9_reg_5113.read() ^ add_ln107_5_fu_3478_p2.read());
}

void BF_encrypt::thread_xor_ln107_9_fu_3534_p2() {
    xor_ln107_9_fu_3534_p2 = (xor_ln107_7_fu_3523_p2.read() ^ trunc_ln107_15_fu_3519_p1.read());
}

void BF_encrypt::thread_xor_ln107_fu_3439_p2() {
    xor_ln107_fu_3439_p2 = (key_S_q0.read() ^ reg_662.read());
}

void BF_encrypt::thread_xor_ln108_10_fu_3773_p2() {
    xor_ln108_10_fu_3773_p2 = (xor_ln108_6_fu_3749_p2.read() ^ trunc_ln108_14_fu_3746_p1.read());
}

void BF_encrypt::thread_xor_ln108_11_fu_3779_p2() {
    xor_ln108_11_fu_3779_p2 = (xor_ln108_5_fu_3741_p2.read() ^ trunc_ln108_13_fu_3738_p1.read());
}

void BF_encrypt::thread_xor_ln108_1_fu_3682_p2() {
    xor_ln108_1_fu_3682_p2 = (trunc_ln108_9_fu_3672_p1.read() ^ add_ln108_4_reg_5335.read());
}

void BF_encrypt::thread_xor_ln108_2_fu_3691_p2() {
    xor_ln108_2_fu_3691_p2 = (trunc_ln108_8_fu_3668_p1.read() ^ add_ln108_3_reg_5330.read());
}

void BF_encrypt::thread_xor_ln108_3_fu_3700_p2() {
    xor_ln108_3_fu_3700_p2 = (trunc_ln108_6_fu_3664_p1.read() ^ add_ln108_2_reg_5325.read());
}

void BF_encrypt::thread_xor_ln108_4_fu_3733_p2() {
    xor_ln108_4_fu_3733_p2 = (r_5_reg_5179.read() ^ add_ln108_1_fu_3709_p2.read());
}

void BF_encrypt::thread_xor_ln108_5_fu_3741_p2() {
    xor_ln108_5_fu_3741_p2 = (xor_ln106_11_reg_5194.read() ^ add_ln108_7_fu_3727_p2.read());
}

void BF_encrypt::thread_xor_ln108_6_fu_3749_p2() {
    xor_ln108_6_fu_3749_p2 = (xor_ln106_10_reg_5189.read() ^ add_ln108_6_fu_3721_p2.read());
}

void BF_encrypt::thread_xor_ln108_7_fu_3757_p2() {
    xor_ln108_7_fu_3757_p2 = (xor_ln106_9_reg_5184.read() ^ add_ln108_5_fu_3715_p2.read());
}

void BF_encrypt::thread_xor_ln108_9_fu_3767_p2() {
    xor_ln108_9_fu_3767_p2 = (xor_ln108_7_fu_3757_p2.read() ^ trunc_ln108_15_fu_3754_p1.read());
}

void BF_encrypt::thread_xor_ln108_fu_3676_p2() {
    xor_ln108_fu_3676_p2 = (key_S_q0.read() ^ reg_662.read());
}

void BF_encrypt::thread_xor_ln109_10_fu_4006_p2() {
    xor_ln109_10_fu_4006_p2 = (xor_ln109_6_fu_3982_p2.read() ^ trunc_ln109_14_fu_3979_p1.read());
}

void BF_encrypt::thread_xor_ln109_11_fu_4012_p2() {
    xor_ln109_11_fu_4012_p2 = (xor_ln109_5_fu_3974_p2.read() ^ trunc_ln109_13_fu_3971_p1.read());
}

void BF_encrypt::thread_xor_ln109_1_fu_3915_p2() {
    xor_ln109_1_fu_3915_p2 = (trunc_ln109_9_fu_3905_p1.read() ^ add_ln109_4_reg_5406.read());
}

void BF_encrypt::thread_xor_ln109_2_fu_3924_p2() {
    xor_ln109_2_fu_3924_p2 = (trunc_ln109_8_fu_3901_p1.read() ^ add_ln109_3_reg_5401.read());
}

void BF_encrypt::thread_xor_ln109_3_fu_3933_p2() {
    xor_ln109_3_fu_3933_p2 = (trunc_ln109_6_fu_3897_p1.read() ^ add_ln109_2_reg_5396.read());
}

void BF_encrypt::thread_xor_ln109_4_fu_3966_p2() {
    xor_ln109_4_fu_3966_p2 = (l_9_reg_5250.read() ^ add_ln109_1_fu_3942_p2.read());
}

void BF_encrypt::thread_xor_ln109_5_fu_3974_p2() {
    xor_ln109_5_fu_3974_p2 = (xor_ln107_11_reg_5265.read() ^ add_ln109_7_fu_3960_p2.read());
}

void BF_encrypt::thread_xor_ln109_6_fu_3982_p2() {
    xor_ln109_6_fu_3982_p2 = (xor_ln107_10_reg_5260.read() ^ add_ln109_6_fu_3954_p2.read());
}

void BF_encrypt::thread_xor_ln109_7_fu_3990_p2() {
    xor_ln109_7_fu_3990_p2 = (xor_ln107_9_reg_5255.read() ^ add_ln109_5_fu_3948_p2.read());
}

void BF_encrypt::thread_xor_ln109_9_fu_4000_p2() {
    xor_ln109_9_fu_4000_p2 = (xor_ln109_7_fu_3990_p2.read() ^ trunc_ln109_15_fu_3987_p1.read());
}

void BF_encrypt::thread_xor_ln109_fu_3909_p2() {
    xor_ln109_fu_3909_p2 = (key_S_q0.read() ^ reg_662.read());
}

void BF_encrypt::thread_xor_ln110_10_fu_4239_p2() {
    xor_ln110_10_fu_4239_p2 = (xor_ln110_6_fu_4215_p2.read() ^ trunc_ln110_14_fu_4212_p1.read());
}

void BF_encrypt::thread_xor_ln110_11_fu_4245_p2() {
    xor_ln110_11_fu_4245_p2 = (xor_ln110_5_fu_4207_p2.read() ^ trunc_ln110_13_fu_4204_p1.read());
}

void BF_encrypt::thread_xor_ln110_1_fu_4148_p2() {
    xor_ln110_1_fu_4148_p2 = (trunc_ln110_9_fu_4138_p1.read() ^ add_ln110_4_reg_5466.read());
}

void BF_encrypt::thread_xor_ln110_2_fu_4157_p2() {
    xor_ln110_2_fu_4157_p2 = (trunc_ln110_8_fu_4134_p1.read() ^ add_ln110_3_reg_5461.read());
}

void BF_encrypt::thread_xor_ln110_3_fu_4166_p2() {
    xor_ln110_3_fu_4166_p2 = (trunc_ln110_6_fu_4130_p1.read() ^ add_ln110_2_reg_5456.read());
}

void BF_encrypt::thread_xor_ln110_4_fu_4199_p2() {
    xor_ln110_4_fu_4199_p2 = (r_6_reg_5350.read() ^ add_ln110_1_fu_4175_p2.read());
}

void BF_encrypt::thread_xor_ln110_5_fu_4207_p2() {
    xor_ln110_5_fu_4207_p2 = (xor_ln108_11_reg_5365.read() ^ add_ln110_7_fu_4193_p2.read());
}

void BF_encrypt::thread_xor_ln110_6_fu_4215_p2() {
    xor_ln110_6_fu_4215_p2 = (xor_ln108_10_reg_5360.read() ^ add_ln110_6_fu_4187_p2.read());
}

void BF_encrypt::thread_xor_ln110_7_fu_4223_p2() {
    xor_ln110_7_fu_4223_p2 = (xor_ln108_9_reg_5355.read() ^ add_ln110_5_fu_4181_p2.read());
}

void BF_encrypt::thread_xor_ln110_9_fu_4233_p2() {
    xor_ln110_9_fu_4233_p2 = (xor_ln110_7_fu_4223_p2.read() ^ trunc_ln110_15_fu_4220_p1.read());
}

void BF_encrypt::thread_xor_ln110_fu_4142_p2() {
    xor_ln110_fu_4142_p2 = (key_S_q0.read() ^ reg_662.read());
}

void BF_encrypt::thread_xor_ln111_1_fu_4338_p2() {
    xor_ln111_1_fu_4338_p2 = (l_10_reg_5421.read() ^ add_ln111_1_fu_4332_p2.read());
}

void BF_encrypt::thread_xor_ln111_fu_4326_p2() {
    xor_ln111_fu_4326_p2 = (key_S_q0.read() ^ reg_662.read());
}

void BF_encrypt::thread_xor_ln94_1_fu_696_p2() {
    xor_ln94_1_fu_696_p2 = (trunc_ln94_5_fu_686_p1.read() ^ trunc_ln94_4_fu_682_p1.read());
}

void BF_encrypt::thread_xor_ln94_2_fu_702_p2() {
    xor_ln94_2_fu_702_p2 = (trunc_ln94_3_fu_678_p1.read() ^ trunc_ln94_2_fu_674_p1.read());
}

void BF_encrypt::thread_xor_ln94_3_fu_708_p2() {
    xor_ln94_3_fu_708_p2 = (trunc_ln94_1_fu_670_p1.read() ^ trunc_ln94_fu_666_p1.read());
}

void BF_encrypt::thread_xor_ln96_10_fu_957_p2() {
    xor_ln96_10_fu_957_p2 = (xor_ln96_6_fu_929_p2.read() ^ trunc_ln96_17_fu_925_p1.read());
}

void BF_encrypt::thread_xor_ln96_11_fu_963_p2() {
    xor_ln96_11_fu_963_p2 = (xor_ln96_5_fu_919_p2.read() ^ trunc_ln96_16_fu_915_p1.read());
}

void BF_encrypt::thread_xor_ln96_1_fu_846_p2() {
    xor_ln96_1_fu_846_p2 = (trunc_ln96_9_fu_836_p1.read() ^ add_ln96_4_reg_4411.read());
}

void BF_encrypt::thread_xor_ln96_2_fu_855_p2() {
    xor_ln96_2_fu_855_p2 = (trunc_ln96_8_fu_832_p1.read() ^ add_ln96_3_reg_4406.read());
}

void BF_encrypt::thread_xor_ln96_3_fu_864_p2() {
    xor_ln96_3_fu_864_p2 = (trunc_ln96_6_fu_828_p1.read() ^ add_ln96_2_reg_4401.read());
}

void BF_encrypt::thread_xor_ln96_4_fu_909_p2() {
    xor_ln96_4_fu_909_p2 = (add_ln96_1_fu_873_p2.read() ^ ap_port_reg_data_1_read.read());
}

void BF_encrypt::thread_xor_ln96_5_fu_919_p2() {
    xor_ln96_5_fu_919_p2 = (add_ln96_7_fu_903_p2.read() ^ trunc_ln96_15_fu_899_p1.read());
}

void BF_encrypt::thread_xor_ln96_6_fu_929_p2() {
    xor_ln96_6_fu_929_p2 = (add_ln96_6_fu_893_p2.read() ^ trunc_ln96_14_fu_889_p1.read());
}

void BF_encrypt::thread_xor_ln96_7_fu_939_p2() {
    xor_ln96_7_fu_939_p2 = (add_ln96_5_fu_883_p2.read() ^ trunc_ln96_13_fu_879_p1.read());
}

void BF_encrypt::thread_xor_ln96_9_fu_951_p2() {
    xor_ln96_9_fu_951_p2 = (xor_ln96_7_fu_939_p2.read() ^ trunc_ln96_18_fu_935_p1.read());
}

void BF_encrypt::thread_xor_ln96_fu_840_p2() {
    xor_ln96_fu_840_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln97_10_fu_1194_p2() {
    xor_ln97_10_fu_1194_p2 = (xor_ln97_6_fu_1168_p2.read() ^ trunc_ln97_14_fu_1164_p1.read());
}

void BF_encrypt::thread_xor_ln97_11_fu_1200_p2() {
    xor_ln97_11_fu_1200_p2 = (xor_ln97_5_fu_1159_p2.read() ^ trunc_ln97_13_fu_1155_p1.read());
}

void BF_encrypt::thread_xor_ln97_1_fu_1099_p2() {
    xor_ln97_1_fu_1099_p2 = (trunc_ln97_9_fu_1089_p1.read() ^ add_ln97_4_reg_4506.read());
}

void BF_encrypt::thread_xor_ln97_2_fu_1108_p2() {
    xor_ln97_2_fu_1108_p2 = (trunc_ln97_8_fu_1085_p1.read() ^ add_ln97_3_reg_4501.read());
}

void BF_encrypt::thread_xor_ln97_3_fu_1117_p2() {
    xor_ln97_3_fu_1117_p2 = (trunc_ln97_6_fu_1081_p1.read() ^ add_ln97_2_reg_4496.read());
}

void BF_encrypt::thread_xor_ln97_4_fu_1150_p2() {
    xor_ln97_4_fu_1150_p2 = (l_reg_4360.read() ^ add_ln97_1_fu_1126_p2.read());
}

void BF_encrypt::thread_xor_ln97_5_fu_1159_p2() {
    xor_ln97_5_fu_1159_p2 = (xor_ln94_3_reg_4375.read() ^ add_ln97_7_fu_1144_p2.read());
}

void BF_encrypt::thread_xor_ln97_6_fu_1168_p2() {
    xor_ln97_6_fu_1168_p2 = (xor_ln94_2_reg_4370.read() ^ add_ln97_6_fu_1138_p2.read());
}

void BF_encrypt::thread_xor_ln97_7_fu_1177_p2() {
    xor_ln97_7_fu_1177_p2 = (xor_ln94_1_reg_4365.read() ^ add_ln97_5_fu_1132_p2.read());
}

void BF_encrypt::thread_xor_ln97_9_fu_1188_p2() {
    xor_ln97_9_fu_1188_p2 = (xor_ln97_7_fu_1177_p2.read() ^ trunc_ln97_15_fu_1173_p1.read());
}

void BF_encrypt::thread_xor_ln97_fu_1093_p2() {
    xor_ln97_fu_1093_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln98_10_fu_1431_p2() {
    xor_ln98_10_fu_1431_p2 = (xor_ln98_6_fu_1405_p2.read() ^ trunc_ln98_14_fu_1401_p1.read());
}

void BF_encrypt::thread_xor_ln98_11_fu_1437_p2() {
    xor_ln98_11_fu_1437_p2 = (xor_ln98_5_fu_1396_p2.read() ^ trunc_ln98_13_fu_1392_p1.read());
}

void BF_encrypt::thread_xor_ln98_1_fu_1336_p2() {
    xor_ln98_1_fu_1336_p2 = (trunc_ln98_9_fu_1326_p1.read() ^ add_ln98_4_reg_4601.read());
}

void BF_encrypt::thread_xor_ln98_2_fu_1345_p2() {
    xor_ln98_2_fu_1345_p2 = (trunc_ln98_8_fu_1322_p1.read() ^ add_ln98_3_reg_4596.read());
}

void BF_encrypt::thread_xor_ln98_3_fu_1354_p2() {
    xor_ln98_3_fu_1354_p2 = (trunc_ln98_6_fu_1318_p1.read() ^ add_ln98_2_reg_4591.read());
}

void BF_encrypt::thread_xor_ln98_4_fu_1387_p2() {
    xor_ln98_4_fu_1387_p2 = (r_reg_4421.read() ^ add_ln98_1_fu_1363_p2.read());
}

void BF_encrypt::thread_xor_ln98_5_fu_1396_p2() {
    xor_ln98_5_fu_1396_p2 = (xor_ln96_11_reg_4436.read() ^ add_ln98_7_fu_1381_p2.read());
}

void BF_encrypt::thread_xor_ln98_6_fu_1405_p2() {
    xor_ln98_6_fu_1405_p2 = (xor_ln96_10_reg_4431.read() ^ add_ln98_6_fu_1375_p2.read());
}

void BF_encrypt::thread_xor_ln98_7_fu_1414_p2() {
    xor_ln98_7_fu_1414_p2 = (xor_ln96_9_reg_4426.read() ^ add_ln98_5_fu_1369_p2.read());
}

void BF_encrypt::thread_xor_ln98_9_fu_1425_p2() {
    xor_ln98_9_fu_1425_p2 = (xor_ln98_7_fu_1414_p2.read() ^ trunc_ln98_15_fu_1410_p1.read());
}

void BF_encrypt::thread_xor_ln98_fu_1330_p2() {
    xor_ln98_fu_1330_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_xor_ln99_10_fu_1668_p2() {
    xor_ln99_10_fu_1668_p2 = (xor_ln99_6_fu_1642_p2.read() ^ trunc_ln99_14_fu_1638_p1.read());
}

void BF_encrypt::thread_xor_ln99_11_fu_1674_p2() {
    xor_ln99_11_fu_1674_p2 = (xor_ln99_5_fu_1633_p2.read() ^ trunc_ln99_13_fu_1629_p1.read());
}

void BF_encrypt::thread_xor_ln99_1_fu_1573_p2() {
    xor_ln99_1_fu_1573_p2 = (trunc_ln99_9_fu_1563_p1.read() ^ add_ln99_4_reg_4672.read());
}

void BF_encrypt::thread_xor_ln99_2_fu_1582_p2() {
    xor_ln99_2_fu_1582_p2 = (trunc_ln99_8_fu_1559_p1.read() ^ add_ln99_3_reg_4667.read());
}

void BF_encrypt::thread_xor_ln99_3_fu_1591_p2() {
    xor_ln99_3_fu_1591_p2 = (trunc_ln99_6_fu_1555_p1.read() ^ add_ln99_2_reg_4662.read());
}

void BF_encrypt::thread_xor_ln99_4_fu_1624_p2() {
    xor_ln99_4_fu_1624_p2 = (l_4_reg_4532.read() ^ add_ln99_1_fu_1600_p2.read());
}

void BF_encrypt::thread_xor_ln99_5_fu_1633_p2() {
    xor_ln99_5_fu_1633_p2 = (xor_ln97_11_reg_4547.read() ^ add_ln99_7_fu_1618_p2.read());
}

void BF_encrypt::thread_xor_ln99_6_fu_1642_p2() {
    xor_ln99_6_fu_1642_p2 = (xor_ln97_10_reg_4542.read() ^ add_ln99_6_fu_1612_p2.read());
}

void BF_encrypt::thread_xor_ln99_7_fu_1651_p2() {
    xor_ln99_7_fu_1651_p2 = (xor_ln97_9_reg_4537.read() ^ add_ln99_5_fu_1606_p2.read());
}

void BF_encrypt::thread_xor_ln99_9_fu_1662_p2() {
    xor_ln99_9_fu_1662_p2 = (xor_ln99_7_fu_1651_p2.read() ^ trunc_ln99_15_fu_1647_p1.read());
}

void BF_encrypt::thread_xor_ln99_fu_1567_p2() {
    xor_ln99_fu_1567_p2 = (key_S_q0.read() ^ reg_649.read());
}

void BF_encrypt::thread_zext_ln100_1_fu_1721_p1() {
    zext_ln100_1_fu_1721_p1 = esl_zext<64,9>(or_ln4_fu_1714_p3.read());
}

void BF_encrypt::thread_zext_ln100_2_fu_1757_p1() {
    zext_ln100_2_fu_1757_p1 = esl_zext<64,10>(or_ln100_1_fu_1750_p3.read());
}

void BF_encrypt::thread_zext_ln100_3_fu_1787_p1() {
    zext_ln100_3_fu_1787_p1 = esl_zext<64,10>(or_ln100_2_fu_1780_p3.read());
}

void BF_encrypt::thread_zext_ln100_fu_1710_p1() {
    zext_ln100_fu_1710_p1 = esl_zext<64,8>(lshr_ln4_reg_4703.read());
}

void BF_encrypt::thread_zext_ln101_1_fu_1954_p1() {
    zext_ln101_1_fu_1954_p1 = esl_zext<64,9>(or_ln5_fu_1947_p3.read());
}

void BF_encrypt::thread_zext_ln101_2_fu_1990_p1() {
    zext_ln101_2_fu_1990_p1 = esl_zext<64,10>(or_ln101_1_fu_1983_p3.read());
}

void BF_encrypt::thread_zext_ln101_3_fu_2020_p1() {
    zext_ln101_3_fu_2020_p1 = esl_zext<64,10>(or_ln101_2_fu_2013_p3.read());
}

void BF_encrypt::thread_zext_ln101_fu_1943_p1() {
    zext_ln101_fu_1943_p1 = esl_zext<64,8>(lshr_ln5_reg_4774.read());
}

void BF_encrypt::thread_zext_ln102_1_fu_2187_p1() {
    zext_ln102_1_fu_2187_p1 = esl_zext<64,9>(or_ln6_fu_2180_p3.read());
}

void BF_encrypt::thread_zext_ln102_2_fu_2223_p1() {
    zext_ln102_2_fu_2223_p1 = esl_zext<64,10>(or_ln102_1_fu_2216_p3.read());
}

void BF_encrypt::thread_zext_ln102_3_fu_2253_p1() {
    zext_ln102_3_fu_2253_p1 = esl_zext<64,10>(or_ln102_2_fu_2246_p3.read());
}

void BF_encrypt::thread_zext_ln102_fu_2176_p1() {
    zext_ln102_fu_2176_p1 = esl_zext<64,8>(lshr_ln6_reg_4845.read());
}

void BF_encrypt::thread_zext_ln103_1_fu_2420_p1() {
    zext_ln103_1_fu_2420_p1 = esl_zext<64,9>(or_ln7_fu_2413_p3.read());
}

void BF_encrypt::thread_zext_ln103_2_fu_2456_p1() {
    zext_ln103_2_fu_2456_p1 = esl_zext<64,10>(or_ln103_1_fu_2449_p3.read());
}

void BF_encrypt::thread_zext_ln103_3_fu_2486_p1() {
    zext_ln103_3_fu_2486_p1 = esl_zext<64,10>(or_ln103_2_fu_2479_p3.read());
}

void BF_encrypt::thread_zext_ln103_fu_2409_p1() {
    zext_ln103_fu_2409_p1 = esl_zext<64,8>(lshr_ln7_reg_4916.read());
}

void BF_encrypt::thread_zext_ln104_1_fu_2653_p1() {
    zext_ln104_1_fu_2653_p1 = esl_zext<64,9>(or_ln8_fu_2646_p3.read());
}

void BF_encrypt::thread_zext_ln104_2_fu_2689_p1() {
    zext_ln104_2_fu_2689_p1 = esl_zext<64,10>(or_ln104_1_fu_2682_p3.read());
}

void BF_encrypt::thread_zext_ln104_3_fu_2719_p1() {
    zext_ln104_3_fu_2719_p1 = esl_zext<64,10>(or_ln104_2_fu_2712_p3.read());
}

void BF_encrypt::thread_zext_ln104_fu_2642_p1() {
    zext_ln104_fu_2642_p1 = esl_zext<64,8>(lshr_ln8_reg_4987.read());
}

void BF_encrypt::thread_zext_ln105_1_fu_2886_p1() {
    zext_ln105_1_fu_2886_p1 = esl_zext<64,9>(or_ln9_fu_2879_p3.read());
}

void BF_encrypt::thread_zext_ln105_2_fu_2922_p1() {
    zext_ln105_2_fu_2922_p1 = esl_zext<64,10>(or_ln105_1_fu_2915_p3.read());
}

void BF_encrypt::thread_zext_ln105_3_fu_2952_p1() {
    zext_ln105_3_fu_2952_p1 = esl_zext<64,10>(or_ln105_2_fu_2945_p3.read());
}

void BF_encrypt::thread_zext_ln105_fu_2875_p1() {
    zext_ln105_fu_2875_p1 = esl_zext<64,8>(lshr_ln9_reg_5058.read());
}

void BF_encrypt::thread_zext_ln106_1_fu_3123_p1() {
    zext_ln106_1_fu_3123_p1 = esl_zext<64,9>(or_ln10_fu_3116_p3.read());
}

void BF_encrypt::thread_zext_ln106_2_fu_3159_p1() {
    zext_ln106_2_fu_3159_p1 = esl_zext<64,10>(or_ln106_1_fu_3152_p3.read());
}

void BF_encrypt::thread_zext_ln106_3_fu_3189_p1() {
    zext_ln106_3_fu_3189_p1 = esl_zext<64,10>(or_ln106_2_fu_3182_p3.read());
}

void BF_encrypt::thread_zext_ln106_fu_3112_p1() {
    zext_ln106_fu_3112_p1 = esl_zext<64,8>(lshr_ln10_reg_5129.read());
}

void BF_encrypt::thread_zext_ln107_1_fu_3356_p1() {
    zext_ln107_1_fu_3356_p1 = esl_zext<64,9>(or_ln11_fu_3349_p3.read());
}

void BF_encrypt::thread_zext_ln107_2_fu_3410_p1() {
    zext_ln107_2_fu_3410_p1 = esl_zext<64,10>(or_ln107_1_fu_3403_p3.read());
}

void BF_encrypt::thread_zext_ln107_3_fu_3422_p1() {
    zext_ln107_3_fu_3422_p1 = esl_zext<64,10>(or_ln107_2_fu_3415_p3.read());
}

void BF_encrypt::thread_zext_ln107_fu_3345_p1() {
    zext_ln107_fu_3345_p1 = esl_zext<64,8>(lshr_ln11_reg_5200.read());
}

void BF_encrypt::thread_zext_ln108_1_fu_3593_p1() {
    zext_ln108_1_fu_3593_p1 = esl_zext<64,9>(or_ln12_fu_3586_p3.read());
}

void BF_encrypt::thread_zext_ln108_2_fu_3647_p1() {
    zext_ln108_2_fu_3647_p1 = esl_zext<64,10>(or_ln108_1_fu_3640_p3.read());
}

void BF_encrypt::thread_zext_ln108_3_fu_3659_p1() {
    zext_ln108_3_fu_3659_p1 = esl_zext<64,10>(or_ln108_2_fu_3652_p3.read());
}

void BF_encrypt::thread_zext_ln108_fu_3582_p1() {
    zext_ln108_fu_3582_p1 = esl_zext<64,8>(lshr_ln12_reg_5279.read());
}

void BF_encrypt::thread_zext_ln109_1_fu_3826_p1() {
    zext_ln109_1_fu_3826_p1 = esl_zext<64,9>(or_ln13_fu_3819_p3.read());
}

void BF_encrypt::thread_zext_ln109_2_fu_3880_p1() {
    zext_ln109_2_fu_3880_p1 = esl_zext<64,10>(or_ln109_1_fu_3873_p3.read());
}

void BF_encrypt::thread_zext_ln109_3_fu_3892_p1() {
    zext_ln109_3_fu_3892_p1 = esl_zext<64,10>(or_ln109_2_fu_3885_p3.read());
}

void BF_encrypt::thread_zext_ln109_fu_3815_p1() {
    zext_ln109_fu_3815_p1 = esl_zext<64,8>(lshr_ln13_reg_5371.read());
}

void BF_encrypt::thread_zext_ln110_1_fu_4059_p1() {
    zext_ln110_1_fu_4059_p1 = esl_zext<64,9>(or_ln14_fu_4052_p3.read());
}

void BF_encrypt::thread_zext_ln110_2_fu_4113_p1() {
    zext_ln110_2_fu_4113_p1 = esl_zext<64,10>(or_ln110_1_fu_4106_p3.read());
}

void BF_encrypt::thread_zext_ln110_3_fu_4125_p1() {
    zext_ln110_3_fu_4125_p1 = esl_zext<64,10>(or_ln110_2_fu_4118_p3.read());
}

void BF_encrypt::thread_zext_ln110_fu_4048_p1() {
    zext_ln110_fu_4048_p1 = esl_zext<64,8>(lshr_ln14_reg_5431.read());
}

void BF_encrypt::thread_zext_ln111_1_fu_4297_p1() {
    zext_ln111_1_fu_4297_p1 = esl_zext<64,9>(or_ln15_fu_4290_p3.read());
}

void BF_encrypt::thread_zext_ln111_2_fu_4309_p1() {
    zext_ln111_2_fu_4309_p1 = esl_zext<64,10>(or_ln111_1_fu_4302_p3.read());
}

void BF_encrypt::thread_zext_ln111_3_fu_4321_p1() {
    zext_ln111_3_fu_4321_p1 = esl_zext<64,10>(or_ln111_2_fu_4314_p3.read());
}

void BF_encrypt::thread_zext_ln111_fu_4286_p1() {
    zext_ln111_fu_4286_p1 = esl_zext<64,8>(lshr_ln15_reg_5486.read());
}

void BF_encrypt::thread_zext_ln96_1_fu_747_p1() {
    zext_ln96_1_fu_747_p1 = esl_zext<64,9>(or_ln_fu_739_p3.read());
}

void BF_encrypt::thread_zext_ln96_2_fu_793_p1() {
    zext_ln96_2_fu_793_p1 = esl_zext<64,10>(or_ln96_1_fu_786_p3.read());
}

void BF_encrypt::thread_zext_ln96_3_fu_823_p1() {
    zext_ln96_3_fu_823_p1 = esl_zext<64,10>(or_ln96_2_fu_816_p3.read());
}

void BF_encrypt::thread_zext_ln96_fu_724_p1() {
    zext_ln96_fu_724_p1 = esl_zext<64,8>(lshr_ln_fu_714_p4.read());
}

void BF_encrypt::thread_zext_ln97_1_fu_1010_p1() {
    zext_ln97_1_fu_1010_p1 = esl_zext<64,9>(or_ln1_fu_1003_p3.read());
}

void BF_encrypt::thread_zext_ln97_2_fu_1046_p1() {
    zext_ln97_2_fu_1046_p1 = esl_zext<64,10>(or_ln97_1_fu_1039_p3.read());
}

void BF_encrypt::thread_zext_ln97_3_fu_1076_p1() {
    zext_ln97_3_fu_1076_p1 = esl_zext<64,10>(or_ln97_2_fu_1069_p3.read());
}

void BF_encrypt::thread_zext_ln97_fu_999_p1() {
    zext_ln97_fu_999_p1 = esl_zext<64,8>(lshr_ln1_reg_4442.read());
}

void BF_encrypt::thread_zext_ln98_1_fu_1247_p1() {
    zext_ln98_1_fu_1247_p1 = esl_zext<64,9>(or_ln2_fu_1240_p3.read());
}

void BF_encrypt::thread_zext_ln98_2_fu_1283_p1() {
    zext_ln98_2_fu_1283_p1 = esl_zext<64,10>(or_ln98_1_fu_1276_p3.read());
}

void BF_encrypt::thread_zext_ln98_3_fu_1313_p1() {
    zext_ln98_3_fu_1313_p1 = esl_zext<64,10>(or_ln98_2_fu_1306_p3.read());
}

void BF_encrypt::thread_zext_ln98_fu_1236_p1() {
    zext_ln98_fu_1236_p1 = esl_zext<64,8>(lshr_ln2_reg_4553.read());
}

void BF_encrypt::thread_zext_ln99_1_fu_1484_p1() {
    zext_ln99_1_fu_1484_p1 = esl_zext<64,9>(or_ln3_fu_1477_p3.read());
}

void BF_encrypt::thread_zext_ln99_2_fu_1520_p1() {
    zext_ln99_2_fu_1520_p1 = esl_zext<64,10>(or_ln99_1_fu_1513_p3.read());
}

void BF_encrypt::thread_zext_ln99_3_fu_1550_p1() {
    zext_ln99_3_fu_1550_p1 = esl_zext<64,10>(or_ln99_2_fu_1543_p3.read());
}

void BF_encrypt::thread_zext_ln99_fu_1473_p1() {
    zext_ln99_fu_1473_p1 = esl_zext<64,8>(lshr_ln3_reg_4632.read());
}

}

