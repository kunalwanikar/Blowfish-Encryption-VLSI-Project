#include "BF_encrypt.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void BF_encrypt::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_pp0_stage0;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter0_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read())) {
            ap_enable_reg_pp0_iter0_reg = ap_start.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp0_iter1 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage31.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage31_subdone.read(), ap_const_boolean_0))) {
            ap_enable_reg_pp0_iter1 = ap_enable_reg_pp0_iter0.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1))) {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && 
             esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
            reg_644 = key_P_q0.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && 
                    esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0))) {
            reg_644 = key_P_q1.read();
        }
    }
    if (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1)) {
        if (esl_seteq<1,1,1>(ap_condition_314.read(), ap_const_boolean_1)) {
            reg_657 = key_P_q0.read();
        } else if (esl_seteq<1,1,1>(ap_condition_148.read(), ap_const_boolean_1)) {
            reg_657 = key_P_q1.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0))) {
        add_ln100_2_reg_4733 = add_ln100_2_fu_1762_p2.read();
        add_ln100_3_reg_4738 = add_ln100_3_fu_1768_p2.read();
        add_ln100_4_reg_4743 = add_ln100_4_fu_1774_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0))) {
        add_ln101_2_reg_4804 = add_ln101_2_fu_1995_p2.read();
        add_ln101_3_reg_4809 = add_ln101_3_fu_2001_p2.read();
        add_ln101_4_reg_4814 = add_ln101_4_fu_2007_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage20_11001.read(), ap_const_boolean_0))) {
        add_ln102_2_reg_4875 = add_ln102_2_fu_2228_p2.read();
        add_ln102_3_reg_4880 = add_ln102_3_fu_2234_p2.read();
        add_ln102_4_reg_4885 = add_ln102_4_fu_2240_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage23_11001.read(), ap_const_boolean_0))) {
        add_ln103_2_reg_4946 = add_ln103_2_fu_2461_p2.read();
        add_ln103_3_reg_4951 = add_ln103_3_fu_2467_p2.read();
        add_ln103_4_reg_4956 = add_ln103_4_fu_2473_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage26_11001.read(), ap_const_boolean_0))) {
        add_ln104_2_reg_5017 = add_ln104_2_fu_2694_p2.read();
        add_ln104_3_reg_5022 = add_ln104_3_fu_2700_p2.read();
        add_ln104_4_reg_5027 = add_ln104_4_fu_2706_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage29_11001.read(), ap_const_boolean_0))) {
        add_ln105_2_reg_5088 = add_ln105_2_fu_2927_p2.read();
        add_ln105_3_reg_5093 = add_ln105_3_fu_2933_p2.read();
        add_ln105_4_reg_5098 = add_ln105_4_fu_2939_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        add_ln106_2_reg_5159 = add_ln106_2_fu_3164_p2.read();
        add_ln106_3_reg_5164 = add_ln106_3_fu_3170_p2.read();
        add_ln106_4_reg_5169 = add_ln106_4_fu_3176_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0))) {
        add_ln107_2_reg_5225 = add_ln107_2_fu_3385_p2.read();
        add_ln107_3_reg_5230 = add_ln107_3_fu_3391_p2.read();
        add_ln107_4_reg_5235 = add_ln107_4_fu_3397_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0))) {
        add_ln108_2_reg_5325 = add_ln108_2_fu_3622_p2.read();
        add_ln108_3_reg_5330 = add_ln108_3_fu_3628_p2.read();
        add_ln108_4_reg_5335 = add_ln108_4_fu_3634_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0))) {
        add_ln109_2_reg_5396 = add_ln109_2_fu_3855_p2.read();
        add_ln109_3_reg_5401 = add_ln109_3_fu_3861_p2.read();
        add_ln109_4_reg_5406 = add_ln109_4_fu_3867_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage22_11001.read(), ap_const_boolean_0))) {
        add_ln110_2_reg_5456 = add_ln110_2_fu_4088_p2.read();
        add_ln110_3_reg_5461 = add_ln110_3_fu_4094_p2.read();
        add_ln110_4_reg_5466 = add_ln110_4_fu_4100_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0))) {
        add_ln96_2_reg_4401 = add_ln96_2_fu_798_p2.read();
        add_ln96_3_reg_4406 = add_ln96_3_fu_804_p2.read();
        add_ln96_4_reg_4411 = add_ln96_4_fu_810_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0))) {
        add_ln97_2_reg_4496 = add_ln97_2_fu_1051_p2.read();
        add_ln97_3_reg_4501 = add_ln97_3_fu_1057_p2.read();
        add_ln97_4_reg_4506 = add_ln97_4_fu_1063_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0))) {
        add_ln98_2_reg_4591 = add_ln98_2_fu_1288_p2.read();
        add_ln98_3_reg_4596 = add_ln98_3_fu_1294_p2.read();
        add_ln98_4_reg_4601 = add_ln98_4_fu_1300_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0))) {
        add_ln99_2_reg_4662 = add_ln99_2_fu_1525_p2.read();
        add_ln99_3_reg_4667 = add_ln99_3_fu_1531_p2.read();
        add_ln99_4_reg_4672 = add_ln99_4_fu_1537_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        ap_port_reg_data_0_read = data_0_read.read();
        ap_port_reg_data_1_read = data_1_read.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0))) {
        key_P_load_11_reg_4568 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0))) {
        key_P_load_13_reg_5271 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()))) {
        key_P_load_14_reg_5294 = key_P_q0.read();
        key_P_load_15_reg_5302 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0))) {
        key_P_load_17_reg_5320 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
        key_P_load_5_reg_4457 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0))) {
        key_P_load_6_reg_4475 = key_P_q0.read();
        key_P_load_7_reg_4483 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0))) {
        key_P_load_8_reg_4516 = key_P_q0.read();
        key_P_load_9_reg_4524 = key_P_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage19.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage19_11001.read(), ap_const_boolean_0))) {
        l_10_reg_5421 = l_10_fu_3995_p2.read();
        lshr_ln14_reg_5431 = l_10_fu_3995_p2.read().range(31, 24);
        trunc_ln110_7_reg_5441 = xor_ln109_9_fu_4000_p2.read().range(15, 8);
        trunc_ln14_reg_5436 = xor_ln109_10_fu_4006_p2.read().range(23, 16);
        xor_ln109_11_reg_5426 = xor_ln109_11_fu_4012_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0))) {
        l_4_reg_4532 = l_4_fu_1182_p2.read();
        lshr_ln2_reg_4553 = l_4_fu_1182_p2.read().range(31, 24);
        trunc_ln7_reg_4558 = xor_ln97_10_fu_1194_p2.read().range(23, 16);
        trunc_ln98_7_reg_4563 = xor_ln97_9_fu_1188_p2.read().range(15, 8);
        xor_ln97_10_reg_4542 = xor_ln97_10_fu_1194_p2.read();
        xor_ln97_11_reg_4547 = xor_ln97_11_fu_1200_p2.read();
        xor_ln97_9_reg_4537 = xor_ln97_9_fu_1188_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage12.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage12_11001.read(), ap_const_boolean_0))) {
        l_5_reg_4682 = l_5_fu_1656_p2.read();
        lshr_ln4_reg_4703 = l_5_fu_1656_p2.read().range(31, 24);
        trunc_ln100_7_reg_4713 = xor_ln99_9_fu_1662_p2.read().range(15, 8);
        trunc_ln9_reg_4708 = xor_ln99_10_fu_1668_p2.read().range(23, 16);
        xor_ln99_10_reg_4692 = xor_ln99_10_fu_1668_p2.read();
        xor_ln99_11_reg_4697 = xor_ln99_11_fu_1674_p2.read();
        xor_ln99_9_reg_4687 = xor_ln99_9_fu_1662_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage18.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage18_11001.read(), ap_const_boolean_0))) {
        l_6_reg_4824 = l_6_fu_2123_p2.read();
        lshr_ln6_reg_4845 = l_6_fu_2123_p2.read().range(31, 24);
        trunc_ln102_7_reg_4855 = xor_ln101_9_fu_2128_p2.read().range(15, 8);
        trunc_ln1_reg_4850 = xor_ln101_10_fu_2134_p2.read().range(23, 16);
        xor_ln101_10_reg_4834 = xor_ln101_10_fu_2134_p2.read();
        xor_ln101_11_reg_4839 = xor_ln101_11_fu_2140_p2.read();
        xor_ln101_9_reg_4829 = xor_ln101_9_fu_2128_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage24.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage24_11001.read(), ap_const_boolean_0))) {
        l_7_reg_4966 = l_7_fu_2589_p2.read();
        lshr_ln8_reg_4987 = l_7_fu_2589_p2.read().range(31, 24);
        trunc_ln104_7_reg_4997 = xor_ln103_9_fu_2594_p2.read().range(15, 8);
        trunc_ln3_reg_4992 = xor_ln103_10_fu_2600_p2.read().range(23, 16);
        xor_ln103_10_reg_4976 = xor_ln103_10_fu_2600_p2.read();
        xor_ln103_11_reg_4981 = xor_ln103_11_fu_2606_p2.read();
        xor_ln103_9_reg_4971 = xor_ln103_9_fu_2594_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage30.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage30_11001.read(), ap_const_boolean_0))) {
        l_8_reg_5108 = l_8_fu_3058_p2.read();
        lshr_ln10_reg_5129 = l_8_fu_3058_p2.read().range(31, 24);
        trunc_ln106_7_reg_5139 = xor_ln105_9_fu_3064_p2.read().range(15, 8);
        trunc_ln10_reg_5134 = xor_ln105_10_fu_3070_p2.read().range(23, 16);
        xor_ln105_10_reg_5118 = xor_ln105_10_fu_3070_p2.read();
        xor_ln105_11_reg_5123 = xor_ln105_11_fu_3076_p2.read();
        xor_ln105_9_reg_5113 = xor_ln105_9_fu_3064_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage7.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage7_11001.read(), ap_const_boolean_0))) {
        l_9_reg_5250 = l_9_fu_3528_p2.read();
        lshr_ln12_reg_5279 = l_9_fu_3528_p2.read().range(31, 24);
        trunc_ln108_7_reg_5289 = xor_ln107_9_fu_3534_p2.read().range(15, 8);
        trunc_ln12_reg_5284 = xor_ln107_10_fu_3540_p2.read().range(23, 16);
        xor_ln107_10_reg_5260 = xor_ln107_10_fu_3540_p2.read();
        xor_ln107_11_reg_5265 = xor_ln107_11_fu_3546_p2.read();
        xor_ln107_9_reg_5255 = xor_ln107_9_fu_3534_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage1.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage1_11001.read(), ap_const_boolean_0))) {
        l_reg_4360 = l_fu_690_p2.read();
        lshr_ln11_reg_5200 = r_5_fu_3292_p2.read().range(31, 24);
        r_5_reg_5179 = r_5_fu_3292_p2.read();
        trunc_ln107_7_reg_5210 = xor_ln106_9_fu_3297_p2.read().range(15, 8);
        trunc_ln11_reg_5205 = xor_ln106_10_fu_3303_p2.read().range(23, 16);
        trunc_ln96_7_reg_4391 = xor_ln94_1_fu_696_p2.read().range(15, 8);
        xor_ln106_10_reg_5189 = xor_ln106_10_fu_3303_p2.read();
        xor_ln106_11_reg_5194 = xor_ln106_11_fu_3309_p2.read();
        xor_ln106_9_reg_5184 = xor_ln106_9_fu_3297_p2.read();
        xor_ln94_1_reg_4365 = xor_ln94_1_fu_696_p2.read();
        xor_ln94_2_reg_4370 = xor_ln94_2_fu_702_p2.read();
        xor_ln94_3_reg_4375 = xor_ln94_3_fu_708_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage13.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage13_11001.read(), ap_const_boolean_0))) {
        lshr_ln13_reg_5371 = r_6_fu_3762_p2.read().range(31, 24);
        r_6_reg_5350 = r_6_fu_3762_p2.read();
        trunc_ln109_7_reg_5381 = xor_ln108_9_fu_3767_p2.read().range(15, 8);
        trunc_ln13_reg_5376 = xor_ln108_10_fu_3773_p2.read().range(23, 16);
        xor_ln108_10_reg_5360 = xor_ln108_10_fu_3773_p2.read();
        xor_ln108_11_reg_5365 = xor_ln108_11_fu_3779_p2.read();
        xor_ln108_9_reg_5355 = xor_ln108_9_fu_3767_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage25.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage25_11001.read(), ap_const_boolean_0))) {
        lshr_ln15_reg_5486 = r_7_fu_4228_p2.read().range(31, 24);
        r_8_reg_5501 = r_8_fu_4281_p2.read();
        trunc_ln111_4_reg_5496 = xor_ln110_9_fu_4233_p2.read().range(15, 8);
        trunc_ln15_reg_5491 = xor_ln110_10_fu_4239_p2.read().range(23, 16);
        xor_ln110_11_reg_5481 = xor_ln110_11_fu_4245_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage3.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage3_11001.read(), ap_const_boolean_0))) {
        lshr_ln1_reg_4442 = r_fu_945_p2.read().range(31, 24);
        r_reg_4421 = r_fu_945_p2.read();
        trunc_ln6_reg_4447 = xor_ln96_10_fu_957_p2.read().range(23, 16);
        trunc_ln97_7_reg_4452 = xor_ln96_9_fu_951_p2.read().range(15, 8);
        xor_ln96_10_reg_4431 = xor_ln96_10_fu_957_p2.read();
        xor_ln96_11_reg_4436 = xor_ln96_11_fu_963_p2.read();
        xor_ln96_9_reg_4426 = xor_ln96_9_fu_951_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage9.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage9_11001.read(), ap_const_boolean_0))) {
        lshr_ln3_reg_4632 = r_1_fu_1419_p2.read().range(31, 24);
        r_1_reg_4611 = r_1_fu_1419_p2.read();
        trunc_ln8_reg_4637 = xor_ln98_10_fu_1431_p2.read().range(23, 16);
        trunc_ln99_7_reg_4642 = xor_ln98_9_fu_1425_p2.read().range(15, 8);
        xor_ln98_10_reg_4621 = xor_ln98_10_fu_1431_p2.read();
        xor_ln98_11_reg_4626 = xor_ln98_11_fu_1437_p2.read();
        xor_ln98_9_reg_4616 = xor_ln98_9_fu_1425_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage15.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage15_11001.read(), ap_const_boolean_0))) {
        lshr_ln5_reg_4774 = r_2_fu_1890_p2.read().range(31, 24);
        r_2_reg_4753 = r_2_fu_1890_p2.read();
        trunc_ln101_7_reg_4784 = xor_ln100_9_fu_1895_p2.read().range(15, 8);
        trunc_ln_reg_4779 = xor_ln100_10_fu_1901_p2.read().range(23, 16);
        xor_ln100_10_reg_4763 = xor_ln100_10_fu_1901_p2.read();
        xor_ln100_11_reg_4768 = xor_ln100_11_fu_1907_p2.read();
        xor_ln100_9_reg_4758 = xor_ln100_9_fu_1895_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage21.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage21_11001.read(), ap_const_boolean_0))) {
        lshr_ln7_reg_4916 = r_3_fu_2356_p2.read().range(31, 24);
        r_3_reg_4895 = r_3_fu_2356_p2.read();
        trunc_ln103_7_reg_4926 = xor_ln102_9_fu_2361_p2.read().range(15, 8);
        trunc_ln2_reg_4921 = xor_ln102_10_fu_2367_p2.read().range(23, 16);
        xor_ln102_10_reg_4905 = xor_ln102_10_fu_2367_p2.read();
        xor_ln102_11_reg_4910 = xor_ln102_11_fu_2373_p2.read();
        xor_ln102_9_reg_4900 = xor_ln102_9_fu_2361_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage27.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage27_11001.read(), ap_const_boolean_0))) {
        lshr_ln9_reg_5058 = r_4_fu_2822_p2.read().range(31, 24);
        r_4_reg_5037 = r_4_fu_2822_p2.read();
        trunc_ln105_7_reg_5068 = xor_ln104_9_fu_2827_p2.read().range(15, 8);
        trunc_ln4_reg_5063 = xor_ln104_10_fu_2833_p2.read().range(23, 16);
        xor_ln104_10_reg_5047 = xor_ln104_10_fu_2833_p2.read();
        xor_ln104_11_reg_5052 = xor_ln104_11_fu_2839_p2.read();
        xor_ln104_9_reg_5042 = xor_ln104_9_fu_2827_p2.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage5.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage5_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage8.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage8_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage11.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage11_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage14.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage14_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage17.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage17_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage20.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage20_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage23.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage23_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage26.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage26_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage29.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage29_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0)))) {
        reg_649 = grp_fu_638_p2.read();
    }
    if (((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage2.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage2_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
  esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage6.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage6_11001.read(), ap_const_boolean_0)))) {
        reg_653 = key_P_q0.read();
    }
    if (((esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage4.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage4_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage10.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage10_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage16.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage16_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage22.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage22_11001.read(), ap_const_boolean_0)) || (esl_seteq<1,1,1>(ap_ce.read(), ap_const_logic_1) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage28.read()) && 
  esl_seteq<1,1,1>(ap_block_pp0_stage28_11001.read(), ap_const_boolean_0)))) {
        reg_662 = grp_fu_638_p2.read();
    }
}

void BF_encrypt::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_subdone.read(), ap_const_boolean_0) && !(esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_1to1.read())))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage1;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            }
            break;
        case 2 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage1_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage2;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage1;
            }
            break;
        case 4 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage2_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage3;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage2;
            }
            break;
        case 8 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage3_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage4;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage3;
            }
            break;
        case 16 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage4_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage5;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage4;
            }
            break;
        case 32 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage5_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage6;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage5;
            }
            break;
        case 64 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage6_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage7;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage6;
            }
            break;
        case 128 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage7_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage8;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage7;
            }
            break;
        case 256 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage8_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage9;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage8;
            }
            break;
        case 512 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage9_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage10;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage9;
            }
            break;
        case 1024 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage10_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage11;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage10;
            }
            break;
        case 2048 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage11_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage12;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage11;
            }
            break;
        case 4096 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage12_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage13;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage12;
            }
            break;
        case 8192 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage13_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage14;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage13;
            }
            break;
        case 16384 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage14_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage15;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage14;
            }
            break;
        case 32768 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage15_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage16;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage15;
            }
            break;
        case 65536 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage16_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage17;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage16;
            }
            break;
        case 131072 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage17_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage18;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage17;
            }
            break;
        case 262144 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage18_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage19;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage18;
            }
            break;
        case 524288 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage19_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage20;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage19;
            }
            break;
        case 1048576 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage20_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage21;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage20;
            }
            break;
        case 2097152 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage21_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage22;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage21;
            }
            break;
        case 4194304 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage22_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage23;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage22;
            }
            break;
        case 8388608 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage23_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage24;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage23;
            }
            break;
        case 16777216 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage24_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage25;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage24;
            }
            break;
        case 33554432 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage25_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage26;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage25;
            }
            break;
        case 67108864 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage26_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage27;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage26;
            }
            break;
        case 134217728 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage27_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage28;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage27;
            }
            break;
        case 268435456 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage28_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage29;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage28;
            }
            break;
        case 536870912 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage29_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage30;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage29;
            }
            break;
        case 1073741824 : 
            if (esl_seteq<1,1,1>(ap_block_pp0_stage30_subdone.read(), ap_const_boolean_0)) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage31;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage30;
            }
            break;
        case 2147483648 : 
            if (((esl_seteq<1,1,1>(ap_block_pp0_stage31_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(ap_const_logic_1, ap_reset_idle_pp0.read())) || (esl_seteq<1,1,1>(ap_block_pp0_stage31_subdone.read(), ap_const_boolean_0) && 
  esl_seteq<1,1,1>(ap_reset_idle_pp0.read(), ap_const_logic_0)))) {
                ap_NS_fsm = ap_ST_fsm_pp0_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp0_stage31;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
            break;
    }
}

}

