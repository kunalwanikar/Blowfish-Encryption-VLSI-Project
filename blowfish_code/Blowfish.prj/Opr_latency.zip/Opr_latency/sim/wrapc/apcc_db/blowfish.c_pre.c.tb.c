/* Provide Declarations */
#include <stdarg.h>
#include <setjmp.h>
#include <limits.h>
#ifdef NEED_CBEAPINT
#include <autopilot_cbe.h>
#else
#define aesl_fopen fopen
#define aesl_freopen freopen
#define aesl_tmpfile tmpfile
#endif
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#ifdef __STRICT_ANSI__
#define inline __inline__
#define typeof __typeof__ 
#endif
#define __isoc99_fscanf fscanf
#define __isoc99_sscanf sscanf
#undef ferror
#undef feof
/* get a declaration for alloca */
#if defined(__CYGWIN__) || defined(__MINGW32__)
#define  alloca(x) __builtin_alloca((x))
#define _alloca(x) __builtin_alloca((x))
#elif defined(__APPLE__)
extern void *__builtin_alloca(unsigned long);
#define alloca(x) __builtin_alloca(x)
#define longjmp _longjmp
#define setjmp _setjmp
#elif defined(__sun__)
#if defined(__sparcv9)
extern void *__builtin_alloca(unsigned long);
#else
extern void *__builtin_alloca(unsigned int);
#endif
#define alloca(x) __builtin_alloca(x)
#elif defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__DragonFly__) || defined(__arm__)
#define alloca(x) __builtin_alloca(x)
#elif defined(_MSC_VER)
#define inline _inline
#define alloca(x) _alloca(x)
#else
#include <alloca.h>
#endif

#ifndef __GNUC__  /* Can only support "linkonce" vars with GCC */
#define __attribute__(X)
#endif

#if defined(__GNUC__) && defined(__APPLE_CC__)
#define __EXTERNAL_WEAK__ __attribute__((weak_import))
#elif defined(__GNUC__)
#define __EXTERNAL_WEAK__ __attribute__((weak))
#else
#define __EXTERNAL_WEAK__
#endif

#if defined(__GNUC__) && (defined(__APPLE_CC__) || defined(__CYGWIN__) || defined(__MINGW32__))
#define __ATTRIBUTE_WEAK__
#elif defined(__GNUC__)
#define __ATTRIBUTE_WEAK__ __attribute__((weak))
#else
#define __ATTRIBUTE_WEAK__
#endif

#if defined(__GNUC__)
#define __HIDDEN__ __attribute__((visibility("hidden")))
#endif

#ifdef __GNUC__
#define LLVM_NAN(NanStr)   __builtin_nan(NanStr)   /* Double */
#define LLVM_NANF(NanStr)  __builtin_nanf(NanStr)  /* Float */
#define LLVM_NANS(NanStr)  __builtin_nans(NanStr)  /* Double */
#define LLVM_NANSF(NanStr) __builtin_nansf(NanStr) /* Float */
#define LLVM_INF           __builtin_inf()         /* Double */
#define LLVM_INFF          __builtin_inff()        /* Float */
#define LLVM_PREFETCH(addr,rw,locality) __builtin_prefetch(addr,rw,locality)
#define __ATTRIBUTE_CTOR__ __attribute__((constructor))
#define __ATTRIBUTE_DTOR__ __attribute__((destructor))
#define LLVM_ASM           __asm__
#else
#define LLVM_NAN(NanStr)   ((double)0.0)           /* Double */
#define LLVM_NANF(NanStr)  0.0F                    /* Float */
#define LLVM_NANS(NanStr)  ((double)0.0)           /* Double */
#define LLVM_NANSF(NanStr) 0.0F                    /* Float */
#define LLVM_INF           ((double)0.0)           /* Double */
#define LLVM_INFF          0.0F                    /* Float */
#define LLVM_PREFETCH(addr,rw,locality)            /* PREFETCH */
#define __ATTRIBUTE_CTOR__
#define __ATTRIBUTE_DTOR__
#define LLVM_ASM(X)
#endif

#if __GNUC__ < 4 /* Old GCC's, or compilers not GCC */ 
#define __builtin_stack_save() 0   /* not implemented */
#define __builtin_stack_restore(X) /* noop */
#endif

#if __GNUC__ && __LP64__ /* 128-bit integer types */
typedef int __attribute__((mode(TI))) llvmInt128;
typedef unsigned __attribute__((mode(TI))) llvmUInt128;
#endif

#define CODE_FOR_MAIN() /* Any target-specific code for main()*/

#ifndef __cplusplus
typedef unsigned char bool;
#endif


/* Support for floating point constants */
typedef unsigned long long ConstantDoubleTy;
typedef unsigned int        ConstantFloatTy;
typedef struct { unsigned long long f1; unsigned short f2; unsigned short pad[3]; } ConstantFP80Ty;
typedef struct { unsigned long long f1; unsigned long long f2; } ConstantFP128Ty;


/* Global Declarations */
/* Helper union for bitcasts */
typedef union {
  unsigned int Int32;
  unsigned long long Int64;
  float Float;
  double Double;
} llvmBitCastUnion;

/* External Global Variable Declarations */
extern signed int sbox[4][256];
extern signed int pbox[18];

/* Function Declarations */
double fmod(double, double);
float fmodf(float, float);
long double fmodl(long double, long double);
signed int feistel_function(signed int llvm_cbe_arg);
void _encrypt(signed int *llvm_cbe_left, signed int *llvm_cbe_right);
void _decrypt(signed int *llvm_cbe_left, signed int *llvm_cbe_right);
void blowfish_init( char *llvm_cbe_key, signed int llvm_cbe_size);
 char *blowfish_encrypt( char *llvm_cbe_data, signed int llvm_cbe_padsize);
 char *blowfish_decrypt( char *llvm_cbe_crypt_data, signed int llvm_cbe_padsize);


/* Global Variable Definitions and Initialization */
signed int sbox[4][256] = { { 3509652390u, 2564797868u, 805139163u, 3491422135u, 3101798381u, 1780907670u, 3128725573u, 4046225305u, 614570311u, 3012652279u, 134345442u, 2240740374u, 1667834072u, 1901547113u, 2757295779u, 4103290238u, 227898511u, 1921955416u, 1904987480u, 2182433518u, 2069144605u, 3260701109u, 2620446009u, 720527379u, 3318853667u, 677414384u, 3393288472u, 3101374703u, 2390351024u, 1614419982u, 1822297739u, 2954791486u, 3608508353u, 3174124327u, 2024746970u, 1432378464u, 3864339955u, 2857741204u, 1464375394u, 1676153920u, 1439316330u, 715854006u, 3033291828u, 289532110u, 2706671279u, 2087905683u, 3018724369u, 1668267050u, 732546397u, 1947742710u, 3462151702u, 2609353502u, 2950085171u, 1814351708u, 2050118529u, 680887927u, 999245976u, 1800124847u, 3300911131u, 1713906067u, 1641548236u, 4213287313u, 1216130144u, 1575780402u, 4018429277u, 3917837745u, 3693486850u, 3949271944u, 596196993u, 3549867205u, 258830323u, 2213823033u, 772490370u, 2760122372u, 1774776394u, 2652871518u, 566650946u, 4142492826u, 1728879713u, 2882767088u, 1783734482u, 3629395816u, 2517608232u, 2874225571u, 1861159788u, 326777828u, 3124490320u, 2130389656u, 2716951837u, 967770486u, 1724537150u, 2185432712u, 2364442137u, 1164943284u, 2105845187u, 998989502u, 3765401048u, 2244026483u, 1075463327u, 1455516326u, 1322494562u, 910128902u, 469688178u, 1117454909u, 936433444u, 3490320968u, 3675253459u, 1240580251u, 122909385u, 2157517691u, 634681816u, 4142456567u, 3825094682u, 3061402683u, 2540495037u, 79693498u, 3249098678u, 1084186820u, 1583128258u, 426386531u, 1761308591u, 1047286709u, 322548459u, 995290223u, 1845252383u, 2603652396u, 3431023940u, 2942221577u, 3202600964u, 3727903485u, 1712269319u, 422464435u, 3234572375u, 1170764815u, 3523960633u, 3117677531u, 1434042557u, 442511882u, 3600875718u, 1076654713u, 1738483198u, 4213154764u, 2393238008u, 3677496056u, 1014306527u, 4251020053u, 793779912u, 2902807211u, 842905082u, 4246964064u, 1395751752u, 1040244610u, 2656851899u, 3396308128u, 445077038u, 3742853595u, 3577915638u, 679411651u, 2892444358u, 2354009459u, 1767581616u, 3150600392u, 3791627101u, 3102740896u, 284835224u, 4246832056u, 1258075500u, 768725851u, 2589189241u, 3069724005u, 3532540348u, 1274779536u, 3789419226u, 2764799539u, 1660621633u, 3471099624u, 4011903706u, 913787905u, 3497959166u, 737222580u, 2514213453u, 2928710040u, 3937242737u, 1804850592u, 3499020752u, 2949064160u, 2386320175u, 2390070455u, 2415321851u, 4061277028u, 2290661394u, 2416832540u, 1336762016u, 1754252060u, 3520065937u, 3014181293u, 791618072u, 3188594551u, 3933548030u, 2332172193u, 3852520463u, 3043980520u, 413987798u, 3465142937u, 3030929376u, 4245938359u, 2093235073u, 3534596313u, 375366246u, 2157278981u, 2479649556u, 555357303u, 3870105701u, 2008414854u, 3344188149u, 4221384143u, 3956125452u, 2067696032u, 3594591187u, 2921233993u, 2428461u, 544322398u, 577241275u, 1471733935u, 610547355u, 4027169054u, 1432588573u, 1507829418u, 2025931657u, 3646575487u, 545086370u, 48609733u, 2200306550u, 1653985193u, 298326376u, 1316178497u, 3007786442u, 2064951626u, 458293330u, 2589141269u, 3591329599u, 3164325604u, 727753846u, 2179363840u, 146436021u, 1461446943u, 4069977195u, 705550613u, 3059967265u, 3887724982u, 4281599278u, 3313849956u, 1404054877u, 2845806497u, 146425753u, 1854211946u }, { 1266315497u, 3048417604u, 3681880366u, 3289982499u, 2909710000u, 1235738493u, 2632868024u, 2414719590u, 3970600049u, 1771706367u, 1449415276u, 3266420449u, 422970021u, 1963543593u, 2690192192u, 3826793022u, 1062508698u, 1531092325u, 1804592342u, 2583117782u, 2714934279u, 4024971509u, 1294809318u, 4028980673u, 1289560198u, 2221992742u, 1669523910u, 35572830u, 157838143u, 1052438473u, 1016535060u, 1802137761u, 1753167236u, 1386275462u, 3080475397u, 2857371447u, 1040679964u, 2145300060u, 2390574316u, 1461121720u, 2956646967u, 4031777805u, 4028374788u, 33600511u, 2920084762u, 1018524850u, 629373528u, 3691585981u, 3515945977u, 2091462646u, 2486323059u, 586499841u, 988145025u, 935516892u, 3367335476u, 2599673255u, 2839830854u, 265290510u, 3972581182u, 2759138881u, 3795373465u, 1005194799u, 847297441u, 406762289u, 1314163512u, 1332590856u, 1866599683u, 4127851711u, 750260880u, 613907577u, 1450815602u, 3165620655u, 3734664991u, 3650291728u, 3012275730u, 3704569646u, 1427272223u, 778793252u, 1343938022u, 2676280711u, 2052605720u, 1946737175u, 3164576444u, 3914038668u, 3967478842u, 3682934266u, 1661551462u, 3294938066u, 4011595847u, 840292616u, 3712170807u, 616741398u, 312560963u, 711312465u, 1351876610u, 322626781u, 1910503582u, 271666773u, 2175563734u, 1594956187u, 70604529u, 3617834859u, 1007753275u, 1495573769u, 4069517037u, 2549218298u, 2663038764u, 504708206u, 2263041392u, 3941167025u, 2249088522u, 1514023603u, 1998579484u, 1312622330u, 694541497u, 2582060303u, 2151582166u, 1382467621u, 776784248u, 2618340202u, 3323268794u, 2497899128u, 2784771155u, 503983604u, 4076293799u, 907881277u, 423175695u, 432175456u, 1378068232u, 4145222326u, 3954048622u, 3938656102u, 3820766613u, 2793130115u, 2977904593u, 26017576u, 3274890735u, 3194772133u, 1700274565u, 1756076034u, 4006520079u, 3677328699u, 720338349u, 1533947780u, 354530856u, 688349552u, 3973924725u, 1637815568u, 332179504u, 3949051286u, 53804574u, 2852348879u, 3044236432u, 1282449977u, 3583942155u, 3416972820u, 4006381244u, 1617046695u, 2628476075u, 3002303598u, 1686838959u, 431878346u, 2686675385u, 1700445008u, 1080580658u, 1009431731u, 832498133u, 3223435511u, 2605976345u, 2271191193u, 2516031870u, 1648197032u, 4164389018u, 2548247927u, 300782431u, 375919233u, 238389289u, 3353747414u, 2531188641u, 2019080857u, 1475708069u, 455242339u, 2609103871u, 448939670u, 3451063019u, 1395535956u, 2413381860u, 1841049896u, 1491858159u, 885456874u, 4264095073u, 4001119347u, 1565136089u, 3898914787u, 1108368660u, 540939232u, 1173283510u, 2745871338u, 3681308437u, 4207628240u, 3343053890u, 4016749493u, 1699691293u, 1103962373u, 3625875870u, 2256883143u, 3830138730u, 1031889488u, 3479347698u, 1535977030u, 4236805024u, 3251091107u, 2132092099u, 1774941330u, 1199868427u, 1452454533u, 157007616u, 2904115357u, 342012276u, 595725824u, 1480756522u, 206960106u, 497939518u, 591360097u, 863170706u, 2375253569u, 3596610801u, 1814182875u, 2094937945u, 3421402208u, 1082520231u, 3463918190u, 2785509508u, 435703966u, 3908032597u, 1641649973u, 2842273706u, 3305899714u, 1510255612u, 2148256476u, 2655287854u, 3276092548u, 4258621189u, 236887753u, 3681803219u, 274041037u, 1734335097u, 3815195456u, 3317970021u, 1899903192u, 1026095262u, 4050517792u, 356393447u, 2410691914u, 3873677099u, 3682840055u }, { 3913112168u, 2491498743u, 4132185628u, 2489919796u, 1091903735u, 1979897079u, 3170134830u, 3567386728u, 3557303409u, 857797738u, 1136121015u, 1342202287u, 507115054u, 2535736646u, 337727348u, 3213592640u, 1301675037u, 2528481711u, 1895095763u, 1721773893u, 3216771564u, 62756741u, 2142006736u, 835421444u, 2531993523u, 1442658625u, 3659876326u, 2882144922u, 676362277u, 1392781812u, 170690266u, 3921047035u, 1759253602u, 3611846912u, 1745797284u, 664899054u, 1329594018u, 3901205900u, 3045908486u, 2062866102u, 2865634940u, 3543621612u, 3464012697u, 1080764994u, 553557557u, 3656615353u, 3996768171u, 991055499u, 499776247u, 1265440854u, 648242737u, 3940784050u, 980351604u, 3713745714u, 1749149687u, 3396870395u, 4211799374u, 3640570775u, 1161844396u, 3125318951u, 1431517754u, 545492359u, 4268468663u, 3499529547u, 1437099964u, 2702547544u, 3433638243u, 2581715763u, 2787789398u, 1060185593u, 1593081372u, 2418618748u, 4260947970u, 69676912u, 2159744348u, 86519011u, 2512459080u, 3838209314u, 1220612927u, 3339683548u, 133810670u, 1090789135u, 1078426020u, 1569222167u, 845107691u, 3583754449u, 4072456591u, 1091646820u, 628848692u, 1613405280u, 3757631651u, 526609435u, 236106946u, 48312990u, 2942717905u, 3402727701u, 1797494240u, 859738849u, 992217954u, 4005476642u, 2243076622u, 3870952857u, 3732016268u, 765654824u, 3490871365u, 2511836413u, 1685915746u, 3888969200u, 1414112111u, 2273134842u, 3281911079u, 4080962846u, 172450625u, 2569994100u, 980381355u, 4109958455u, 2819808352u, 2716589560u, 2568741196u, 3681446669u, 3329971472u, 1835478071u, 660984891u, 3704678404u, 4045999559u, 3422617507u, 3040415634u, 1762651403u, 1719377915u, 3470491036u, 2693910283u, 3642056355u, 3138596744u, 1364962596u, 2073328063u, 1983633131u, 926494387u, 3423689081u, 2150032023u, 4096667949u, 1749200295u, 3328846651u, 309677260u, 2016342300u, 1779581495u, 3079819751u, 111262694u, 1274766160u, 443224088u, 298511866u, 1025883608u, 3806446537u, 1145181785u, 168956806u, 3641502830u, 3584813610u, 1689216846u, 3666258015u, 3200248200u, 1692713982u, 2646376535u, 4042768518u, 1618508792u, 1610833997u, 3523052358u, 4130873264u, 2001055236u, 3610705100u, 2202168115u, 4028541809u, 2961195399u, 1006657119u, 2006996926u, 3186142756u, 1430667929u, 3210227297u, 1314452623u, 4074634658u, 4101304120u, 2273951170u, 1399257539u, 3367210612u, 3027628629u, 1190975929u, 2062231137u, 2333990788u, 2221543033u, 2438960610u, 1181637006u, 548689776u, 2362791313u, 3372408396u, 3104550113u, 3145860560u, 296247880u, 1970579870u, 3078560182u, 3769228297u, 1714227617u, 3291629107u, 3898220290u, 166772364u, 1251581989u, 493813264u, 448347421u, 195405023u, 2709975567u, 677966185u, 3703036547u, 1463355134u, 2715995803u, 1338867538u, 1343315457u, 2802222074u, 2684532164u, 233230375u, 2599980071u, 2000651841u, 3277868038u, 1638401717u, 4028070440u, 3237316320u, 6314154u, 819756386u, 300326615u, 590932579u, 1405279636u, 3267499572u, 3150704214u, 2428286686u, 3959192993u, 3461946742u, 1862657033u, 1266418056u, 963775037u, 2089974820u, 2263052895u, 1917689273u, 448879540u, 3550394620u, 3981727096u, 150775221u, 3627908307u, 1303187396u, 508620638u, 2975983352u, 2726630617u, 1817252668u, 1876281319u, 1457606340u, 908771278u, 3720792119u, 3617206836u, 2455994898u, 1729034894u, 1080033504u }, { 976866871u, 3556439503u, 2881648439u, 1522871579u, 1555064734u, 1336096578u, 3548522304u, 2579274686u, 3574697629u, 3205460757u, 3593280638u, 3338716283u, 3079412587u, 564236357u, 2993598910u, 1781952180u, 1464380207u, 3163844217u, 3332601554u, 1699332808u, 1393555694u, 1183702653u, 3581086237u, 1288719814u, 691649499u, 2847557200u, 2895455976u, 3193889540u, 2717570544u, 1781354906u, 1676643554u, 2592534050u, 3230253752u, 1126444790u, 2770207658u, 2633158820u, 2210423226u, 2615765581u, 2414155088u, 3127139286u, 673620729u, 2805611233u, 1269405062u, 4015350505u, 3341807571u, 4149409754u, 1057255273u, 2012875353u, 2162469141u, 2276492801u, 2601117357u, 993977747u, 3918593370u, 2654263191u, 753973209u, 36408145u, 2530585658u, 25011837u, 3520020182u, 2088578344u, 530523599u, 2918365339u, 1524020338u, 1518925132u, 3760827505u, 3759777254u, 1202760957u, 3985898139u, 3906192525u, 674977740u, 4174734889u, 2031300136u, 2019492241u, 3983892565u, 4153806404u, 3822280332u, 352677332u, 2297720250u, 60907813u, 90501309u, 3286998549u, 1016092578u, 2535922412u, 2839152426u, 457141659u, 509813237u, 4120667899u, 652014361u, 1966332200u, 2975202805u, 55981186u, 2327461051u, 676427537u, 3255491064u, 2882294119u, 3433927263u, 1307055953u, 942726286u, 933058658u, 2468411793u, 3933900994u, 4215176142u, 1361170020u, 2001714738u, 2830558078u, 3274259782u, 1222529897u, 1679025792u, 2729314320u, 3714953764u, 1770335741u, 151462246u, 3013232138u, 1682292957u, 1483529935u, 471910574u, 1539241949u, 458788160u, 3436315007u, 1807016891u, 3718408830u, 978976581u, 1043663428u, 3165965781u, 1927990952u, 4200891579u, 2372276910u, 3208408903u, 3533431907u, 1412390302u, 2931980059u, 4132332400u, 1947078029u, 3881505623u, 4168226417u, 2941484381u, 1077988104u, 1320477388u, 886195818u, 18198404u, 3786409000u, 2509781533u, 112762804u, 3463356488u, 1866414978u, 891333506u, 18488651u, 661792760u, 1628790961u, 3885187036u, 3141171499u, 876946877u, 2693282273u, 1372485963u, 791857591u, 2686433993u, 3759982718u, 3167212022u, 3472953795u, 2716379847u, 445679433u, 3561995674u, 3504004811u, 3574258232u, 54117162u, 3331405415u, 2381918588u, 3769707343u, 4154350007u, 1140177722u, 4074052095u, 668550556u, 3214352940u, 367459370u, 261225585u, 2610173221u, 4209349473u, 3468074219u, 3265815641u, 314222801u, 3066103646u, 3808782860u, 282218597u, 3406013506u, 3773591054u, 379116347u, 1285071038u, 846784868u, 2669647154u, 3771962079u, 3550491691u, 2305946142u, 453669953u, 1268987020u, 3317592352u, 3279303384u, 3744833421u, 2610507566u, 3859509063u, 266596637u, 3847019092u, 517658769u, 3462560207u, 3443424879u, 370717030u, 4247526661u, 2224018117u, 4143653529u, 4112773975u, 2788324899u, 2477274417u, 1456262402u, 2901442914u, 1517677493u, 1846949527u, 2295493580u, 3734397586u, 2176403920u, 1280348187u, 1908823572u, 3871786941u, 846861322u, 1172426758u, 3287448474u, 3383383037u, 1655181056u, 3139813346u, 901632758u, 1897031941u, 2986607138u, 3066810236u, 3447102507u, 1393639104u, 373351379u, 950779232u, 625454576u, 3124240540u, 4148612726u, 2007998917u, 544563296u, 2244738638u, 2330496472u, 2058025392u, 1291430526u, 424198748u, 50039436u, 29584100u, 3605783033u, 2429876329u, 2791104160u, 1057563949u, 3255363231u, 3075367218u, 3463963227u, 1469046755u, 985887462u } };
signed int pbox[18] = { 608135816u, 2242054355u, 320440878u, 57701188u, 2752067618u, 698298832u, 137296536u, 3964562569u, 1160258022u, 953160567u, 3193202383u, 887688300u, 3232508343u, 3380367581u, 1065670069u, 3041331479u, 2450970073u, 2306472731u };


/* Function Bodies */
static inline int llvm_fcmp_ord(double X, double Y) { return X == X && Y == Y; }
static inline int llvm_fcmp_uno(double X, double Y) { return X != X || Y != Y; }
static inline int llvm_fcmp_ueq(double X, double Y) { return X == Y || llvm_fcmp_uno(X, Y); }
static inline int llvm_fcmp_une(double X, double Y) { return X != Y; }
static inline int llvm_fcmp_ult(double X, double Y) { return X <  Y || llvm_fcmp_uno(X, Y); }
static inline int llvm_fcmp_ugt(double X, double Y) { return X >  Y || llvm_fcmp_uno(X, Y); }
static inline int llvm_fcmp_ule(double X, double Y) { return X <= Y || llvm_fcmp_uno(X, Y); }
static inline int llvm_fcmp_uge(double X, double Y) { return X >= Y || llvm_fcmp_uno(X, Y); }
static inline int llvm_fcmp_oeq(double X, double Y) { return X == Y ; }
static inline int llvm_fcmp_one(double X, double Y) { return X != Y && llvm_fcmp_ord(X, Y); }
static inline int llvm_fcmp_olt(double X, double Y) { return X <  Y ; }
static inline int llvm_fcmp_ogt(double X, double Y) { return X >  Y ; }
static inline int llvm_fcmp_ole(double X, double Y) { return X <= Y ; }
static inline int llvm_fcmp_oge(double X, double Y) { return X >= Y ; }

signed int feistel_function(signed int llvm_cbe_arg) {
  static  unsigned long long aesl_llvm_cbe_1_count = 0;
  static  unsigned long long aesl_llvm_cbe_2_count = 0;
  static  unsigned long long aesl_llvm_cbe_3_count = 0;
  static  unsigned long long aesl_llvm_cbe_4_count = 0;
  static  unsigned long long aesl_llvm_cbe_5_count = 0;
  static  unsigned long long aesl_llvm_cbe_6_count = 0;
  unsigned int llvm_cbe_tmp__1;
  static  unsigned long long aesl_llvm_cbe_7_count = 0;
  unsigned long long llvm_cbe_tmp__2;
  static  unsigned long long aesl_llvm_cbe_8_count = 0;
  signed int *llvm_cbe_tmp__3;
  static  unsigned long long aesl_llvm_cbe_9_count = 0;
  unsigned int llvm_cbe_tmp__4;
  static  unsigned long long aesl_llvm_cbe_10_count = 0;
  unsigned int llvm_cbe_tmp__5;
  static  unsigned long long aesl_llvm_cbe_11_count = 0;
  unsigned char llvm_cbe_tmp__6;
  static  unsigned long long aesl_llvm_cbe_12_count = 0;
  unsigned long long llvm_cbe_tmp__7;
  static  unsigned long long aesl_llvm_cbe_13_count = 0;
  signed int *llvm_cbe_tmp__8;
  static  unsigned long long aesl_llvm_cbe_14_count = 0;
  unsigned int llvm_cbe_tmp__9;
  static  unsigned long long aesl_llvm_cbe_15_count = 0;
  unsigned int llvm_cbe_tmp__10;
  static  unsigned long long aesl_llvm_cbe_16_count = 0;
  static  unsigned long long aesl_llvm_cbe_17_count = 0;
  static  unsigned long long aesl_llvm_cbe_18_count = 0;
  unsigned int llvm_cbe_tmp__11;
  static  unsigned long long aesl_llvm_cbe_19_count = 0;
  unsigned char llvm_cbe_tmp__12;
  static  unsigned long long aesl_llvm_cbe_20_count = 0;
  unsigned long long llvm_cbe_tmp__13;
  static  unsigned long long aesl_llvm_cbe_21_count = 0;
  signed int *llvm_cbe_tmp__14;
  static  unsigned long long aesl_llvm_cbe_22_count = 0;
  unsigned int llvm_cbe_tmp__15;
  static  unsigned long long aesl_llvm_cbe_23_count = 0;
  unsigned int llvm_cbe_tmp__16;
  static  unsigned long long aesl_llvm_cbe_24_count = 0;
  unsigned char llvm_cbe_tmp__17;
  static  unsigned long long aesl_llvm_cbe_25_count = 0;
  unsigned long long llvm_cbe_tmp__18;
  static  unsigned long long aesl_llvm_cbe_26_count = 0;
  signed int *llvm_cbe_tmp__19;
  static  unsigned long long aesl_llvm_cbe_27_count = 0;
  unsigned int llvm_cbe_tmp__20;
  static  unsigned long long aesl_llvm_cbe_28_count = 0;
  unsigned int llvm_cbe_tmp__21;
  static  unsigned long long aesl_llvm_cbe_29_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @feistel_function\n");
if (AESL_DEBUG_TRACE)
printf("\n  %%1 = lshr i32 %%arg, 24, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_6_count);
  llvm_cbe_tmp__1 = (unsigned int )((unsigned int )(((unsigned int )(llvm_cbe_arg&4294967295ull)) >> ((unsigned int )(24u&4294967295ull))));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__1&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = zext i32 %%1 to i64, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_7_count);
  llvm_cbe_tmp__2 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_tmp__1&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__2);
if (AESL_DEBUG_TRACE)
printf("\n  %%3 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 0, i64 %%2, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_8_count);
  llvm_cbe_tmp__3 = (signed int *)(&sbox[(((signed long long )0ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__2))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__2));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )0ull) < 4)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);
  if (!(((signed long long )llvm_cbe_tmp__2) < 256)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = load i32* %%3, align 4, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_9_count);
  llvm_cbe_tmp__4 = (unsigned int )*llvm_cbe_tmp__3;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__4);
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = lshr i32 %%arg, 16, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_10_count);
  llvm_cbe_tmp__5 = (unsigned int )((unsigned int )(((unsigned int )(llvm_cbe_arg&4294967295ull)) >> ((unsigned int )(16u&4294967295ull))));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__5&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = trunc i32 %%5 to i8, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_11_count);
  llvm_cbe_tmp__6 = (unsigned char )((unsigned char )llvm_cbe_tmp__5&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__6);
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = zext i8 %%6 to i64, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_12_count);
  llvm_cbe_tmp__7 = (unsigned long long )((unsigned long long )(unsigned char )llvm_cbe_tmp__6&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__7);
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 1, i64 %%7, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_13_count);
  llvm_cbe_tmp__8 = (signed int *)(&sbox[(((signed long long )1ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__7))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__7));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )1ull) < 4)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);
  if (!(((signed long long )llvm_cbe_tmp__7) < 256)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = load i32* %%8, align 4, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_14_count);
  llvm_cbe_tmp__9 = (unsigned int )*llvm_cbe_tmp__8;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__9);
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = add i32 %%9, %%4, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_15_count);
  llvm_cbe_tmp__10 = (unsigned int )((unsigned int )(llvm_cbe_tmp__9&4294967295ull)) + ((unsigned int )(llvm_cbe_tmp__4&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__10&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = lshr i32 %%arg, 8, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_18_count);
  llvm_cbe_tmp__11 = (unsigned int )((unsigned int )(((unsigned int )(llvm_cbe_arg&4294967295ull)) >> ((unsigned int )(8u&4294967295ull))));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__11&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%12 = trunc i32 %%11 to i8, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_19_count);
  llvm_cbe_tmp__12 = (unsigned char )((unsigned char )llvm_cbe_tmp__11&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__12);
if (AESL_DEBUG_TRACE)
printf("\n  %%13 = zext i8 %%12 to i64, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_20_count);
  llvm_cbe_tmp__13 = (unsigned long long )((unsigned long long )(unsigned char )llvm_cbe_tmp__12&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__13);
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 2, i64 %%13, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_21_count);
  llvm_cbe_tmp__14 = (signed int *)(&sbox[(((signed long long )2ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__13))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__13));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )2ull) < 4)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);
  if (!(((signed long long )llvm_cbe_tmp__13) < 256)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = load i32* %%14, align 4, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_22_count);
  llvm_cbe_tmp__15 = (unsigned int )*llvm_cbe_tmp__14;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__15);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = xor i32 %%10, %%15, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_23_count);
  llvm_cbe_tmp__16 = (unsigned int )llvm_cbe_tmp__10 ^ llvm_cbe_tmp__15;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__16);
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = trunc i32 %%arg to i8, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_24_count);
  llvm_cbe_tmp__17 = (unsigned char )((unsigned char )llvm_cbe_arg&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__17);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = zext i8 %%17 to i64, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_25_count);
  llvm_cbe_tmp__18 = (unsigned long long )((unsigned long long )(unsigned char )llvm_cbe_tmp__17&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__18);
if (AESL_DEBUG_TRACE)
printf("\n  %%19 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 3, i64 %%18, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_26_count);
  llvm_cbe_tmp__19 = (signed int *)(&sbox[(((signed long long )3ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__18))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__18));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )3ull) < 4)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);
  if (!(((signed long long )llvm_cbe_tmp__18) < 256)) fprintf(stderr, "%s:%d: warning: Read access out of array 'sbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%20 = load i32* %%19, align 4, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_27_count);
  llvm_cbe_tmp__20 = (unsigned int )*llvm_cbe_tmp__19;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__20);
if (AESL_DEBUG_TRACE)
printf("\n  %%21 = add i32 %%16, %%20, !dbg !7 for 0x%I64xth hint within @feistel_function  --> \n", ++aesl_llvm_cbe_28_count);
  llvm_cbe_tmp__21 = (unsigned int )((unsigned int )(llvm_cbe_tmp__16&4294967295ull)) + ((unsigned int )(llvm_cbe_tmp__20&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__21&4294967295ull)));
  if (AESL_DEBUG_TRACE)
      printf("\nEND @feistel_function}\n");
  return llvm_cbe_tmp__21;
}


void _encrypt(signed int *llvm_cbe_left, signed int *llvm_cbe_right) {
  static  unsigned long long aesl_llvm_cbe_30_count = 0;
  static  unsigned long long aesl_llvm_cbe_31_count = 0;
  static  unsigned long long aesl_llvm_cbe_32_count = 0;
  static  unsigned long long aesl_llvm_cbe_33_count = 0;
  static  unsigned long long aesl_llvm_cbe_34_count = 0;
  static  unsigned long long aesl_llvm_cbe_35_count = 0;
  static  unsigned long long aesl_llvm_cbe_36_count = 0;
  static  unsigned long long aesl_llvm_cbe_37_count = 0;
  static  unsigned long long aesl_llvm_cbe_38_count = 0;
  static  unsigned long long aesl_llvm_cbe_39_count = 0;
  static  unsigned long long aesl_llvm_cbe_40_count = 0;
  static  unsigned long long aesl_llvm_cbe_41_count = 0;
  static  unsigned long long aesl_llvm_cbe_42_count = 0;
  static  unsigned long long aesl_llvm_cbe_43_count = 0;
  static  unsigned long long aesl_llvm_cbe_44_count = 0;
  static  unsigned long long aesl_llvm_cbe_45_count = 0;
  static  unsigned long long aesl_llvm_cbe_46_count = 0;
  static  unsigned long long aesl_llvm_cbe_47_count = 0;
  static  unsigned long long aesl_llvm_cbe_48_count = 0;
  static  unsigned long long aesl_llvm_cbe_49_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge1_count = 0;
  unsigned int llvm_cbe_storemerge1;
  unsigned int llvm_cbe_storemerge1__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_50_count = 0;
  unsigned long long llvm_cbe_tmp__22;
  static  unsigned long long aesl_llvm_cbe_51_count = 0;
  signed int *llvm_cbe_tmp__23;
  static  unsigned long long aesl_llvm_cbe_52_count = 0;
  unsigned int llvm_cbe_tmp__24;
  static  unsigned long long aesl_llvm_cbe_53_count = 0;
  unsigned int llvm_cbe_tmp__25;
  static  unsigned long long aesl_llvm_cbe_54_count = 0;
  unsigned int llvm_cbe_tmp__26;
  static  unsigned long long aesl_llvm_cbe_55_count = 0;
  static  unsigned long long aesl_llvm_cbe_56_count = 0;
  unsigned int llvm_cbe_tmp__27;
  static  unsigned long long aesl_llvm_cbe_57_count = 0;
  unsigned int llvm_cbe_tmp__28;
  static  unsigned long long aesl_llvm_cbe_58_count = 0;
  unsigned int llvm_cbe_tmp__29;
  static  unsigned long long aesl_llvm_cbe_59_count = 0;
  static  unsigned long long aesl_llvm_cbe_60_count = 0;
  unsigned int llvm_cbe_tmp__30;
  static  unsigned long long aesl_llvm_cbe_61_count = 0;
  static  unsigned long long aesl_llvm_cbe_62_count = 0;
  static  unsigned long long aesl_llvm_cbe_63_count = 0;
  static  unsigned long long aesl_llvm_cbe_64_count = 0;
  static  unsigned long long aesl_llvm_cbe_65_count = 0;
  static  unsigned long long aesl_llvm_cbe_66_count = 0;
  unsigned int llvm_cbe_tmp__31;
  static  unsigned long long aesl_llvm_cbe_67_count = 0;
  static  unsigned long long aesl_llvm_cbe_68_count = 0;
  static  unsigned long long aesl_llvm_cbe_69_count = 0;
  static  unsigned long long aesl_llvm_cbe_70_count = 0;
  static  unsigned long long aesl_llvm_cbe_exitcond_count = 0;
  static  unsigned long long aesl_llvm_cbe_71_count = 0;
  static  unsigned long long aesl_llvm_cbe_72_count = 0;
  unsigned int llvm_cbe_tmp__32;
  static  unsigned long long aesl_llvm_cbe_73_count = 0;
  static  unsigned long long aesl_llvm_cbe_74_count = 0;
  static  unsigned long long aesl_llvm_cbe_75_count = 0;
  static  unsigned long long aesl_llvm_cbe_76_count = 0;
  static  unsigned long long aesl_llvm_cbe_77_count = 0;
  static  unsigned long long aesl_llvm_cbe_78_count = 0;
  unsigned int llvm_cbe_tmp__33;
  static  unsigned long long aesl_llvm_cbe_79_count = 0;
  unsigned int llvm_cbe_tmp__34;
  static  unsigned long long aesl_llvm_cbe_80_count = 0;
  static  unsigned long long aesl_llvm_cbe_81_count = 0;
  unsigned int llvm_cbe_tmp__35;
  static  unsigned long long aesl_llvm_cbe_82_count = 0;
  unsigned int llvm_cbe_tmp__36;
  static  unsigned long long aesl_llvm_cbe_83_count = 0;
  unsigned int llvm_cbe_tmp__37;
  static  unsigned long long aesl_llvm_cbe_84_count = 0;
  static  unsigned long long aesl_llvm_cbe_85_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @_encrypt\n");
  llvm_cbe_storemerge1__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
  goto llvm_cbe_tmp__38;

  do {     /* Syntactic loop '' to make GCC happy */
llvm_cbe_tmp__38:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge1 = phi i32 [ 0, %%0 ], [ %%11, %%1  for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_storemerge1_count);
  llvm_cbe_storemerge1 = (unsigned int )llvm_cbe_storemerge1__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge1 = 0x%X",llvm_cbe_storemerge1);
printf("\n = 0x%X",0u);
printf("\n = 0x%X",llvm_cbe_tmp__31);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = zext i32 %%storemerge1 to i64, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_50_count);
  llvm_cbe_tmp__22 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_storemerge1&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__22);
if (AESL_DEBUG_TRACE)
printf("\n  %%3 = getelementptr inbounds [18 x i32]* @pbox, i64 0, i64 %%2, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_51_count);
  llvm_cbe_tmp__23 = (signed int *)(&pbox[(((signed long long )llvm_cbe_tmp__22))
#ifdef AESL_BC_SIM
 % 18
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__22));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )llvm_cbe_tmp__22) < 18)) fprintf(stderr, "%s:%d: warning: Read access out of array 'pbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = load i32* %%3, align 4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_52_count);
  llvm_cbe_tmp__24 = (unsigned int )*llvm_cbe_tmp__23;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__24);
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = load i32* %%left, align 4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_53_count);
  llvm_cbe_tmp__25 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__25);
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = xor i32 %%5, %%4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_54_count);
  llvm_cbe_tmp__26 = (unsigned int )llvm_cbe_tmp__25 ^ llvm_cbe_tmp__24;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__26);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%6, i32* %%left, align 4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_55_count);
  *llvm_cbe_left = llvm_cbe_tmp__26;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__26);
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = tail call i32 @feistel_function(i32 %%6), !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_56_count);
  llvm_cbe_tmp__27 = (unsigned int ) /*tail*/ feistel_function(llvm_cbe_tmp__26);
if (AESL_DEBUG_TRACE) {
printf("\nArgument  = 0x%X",llvm_cbe_tmp__26);
printf("\nReturn  = 0x%X",llvm_cbe_tmp__27);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = load i32* %%right, align 4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_57_count);
  llvm_cbe_tmp__28 = (unsigned int )*llvm_cbe_right;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__28);
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = xor i32 %%8, %%7, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_58_count);
  llvm_cbe_tmp__29 = (unsigned int )llvm_cbe_tmp__28 ^ llvm_cbe_tmp__27;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__29);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%right, align 4, !dbg !7 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_59_count);
  *llvm_cbe_right = llvm_cbe_tmp__29;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__29);
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_60_count);
  llvm_cbe_tmp__30 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__30);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_64_count);
  *llvm_cbe_left = llvm_cbe_tmp__29;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__29);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%10, i32* %%right, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_65_count);
  *llvm_cbe_right = llvm_cbe_tmp__30;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__30);
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = add i32 %%storemerge1, 1, !dbg !9 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_66_count);
  llvm_cbe_tmp__31 = (unsigned int )((unsigned int )(llvm_cbe_storemerge1&4294967295ull)) + ((unsigned int )(1u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__31&4294967295ull)));
  if (((llvm_cbe_tmp__31&4294967295U) == (16u&4294967295U))) {
    goto llvm_cbe_tmp__39;
  } else {
    llvm_cbe_storemerge1__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__31;   /* for PHI node */
    goto llvm_cbe_tmp__38;
  }

  } while (1); /* end of syntactic loop '' */
llvm_cbe_tmp__39:
if (AESL_DEBUG_TRACE)
printf("\n  %%13 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_72_count);
  llvm_cbe_tmp__32 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__32);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%10, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_76_count);
  *llvm_cbe_left = llvm_cbe_tmp__30;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__30);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%13, i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_77_count);
  *llvm_cbe_right = llvm_cbe_tmp__32;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__32);
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = load i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 16), align 16, !dbg !9 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_78_count);
  llvm_cbe_tmp__33 = (unsigned int )*((&pbox[(((signed long long )16ull))
#ifdef AESL_BC_SIM
 % 18
#endif
]));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__33);
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = xor i32 %%14, %%13, !dbg !9 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_79_count);
  llvm_cbe_tmp__34 = (unsigned int )llvm_cbe_tmp__33 ^ llvm_cbe_tmp__32;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__34);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%15, i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_80_count);
  *llvm_cbe_right = llvm_cbe_tmp__34;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__34);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = load i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 17), align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_81_count);
  llvm_cbe_tmp__35 = (unsigned int )*((&pbox[(((signed long long )17ull))
#ifdef AESL_BC_SIM
 % 18
#endif
]));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__35);
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_82_count);
  llvm_cbe_tmp__36 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__36);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = xor i32 %%17, %%16, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_83_count);
  llvm_cbe_tmp__37 = (unsigned int )llvm_cbe_tmp__36 ^ llvm_cbe_tmp__35;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__37);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%18, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_encrypt  --> \n", ++aesl_llvm_cbe_84_count);
  *llvm_cbe_left = llvm_cbe_tmp__37;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__37);
  if (AESL_DEBUG_TRACE)
      printf("\nEND @_encrypt}\n");
  return;
}


void _decrypt(signed int *llvm_cbe_left, signed int *llvm_cbe_right) {
  static  unsigned long long aesl_llvm_cbe_86_count = 0;
  static  unsigned long long aesl_llvm_cbe_87_count = 0;
  static  unsigned long long aesl_llvm_cbe_88_count = 0;
  static  unsigned long long aesl_llvm_cbe_89_count = 0;
  static  unsigned long long aesl_llvm_cbe_90_count = 0;
  static  unsigned long long aesl_llvm_cbe_91_count = 0;
  static  unsigned long long aesl_llvm_cbe_92_count = 0;
  static  unsigned long long aesl_llvm_cbe_93_count = 0;
  static  unsigned long long aesl_llvm_cbe_94_count = 0;
  static  unsigned long long aesl_llvm_cbe_95_count = 0;
  static  unsigned long long aesl_llvm_cbe_96_count = 0;
  static  unsigned long long aesl_llvm_cbe_97_count = 0;
  static  unsigned long long aesl_llvm_cbe_98_count = 0;
  static  unsigned long long aesl_llvm_cbe_99_count = 0;
  static  unsigned long long aesl_llvm_cbe_100_count = 0;
  static  unsigned long long aesl_llvm_cbe_101_count = 0;
  static  unsigned long long aesl_llvm_cbe_102_count = 0;
  static  unsigned long long aesl_llvm_cbe_103_count = 0;
  static  unsigned long long aesl_llvm_cbe_104_count = 0;
  static  unsigned long long aesl_llvm_cbe_105_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge1_count = 0;
  unsigned int llvm_cbe_storemerge1;
  unsigned int llvm_cbe_storemerge1__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_106_count = 0;
  unsigned long long llvm_cbe_tmp__40;
  static  unsigned long long aesl_llvm_cbe_107_count = 0;
  signed int *llvm_cbe_tmp__41;
  static  unsigned long long aesl_llvm_cbe_108_count = 0;
  unsigned int llvm_cbe_tmp__42;
  static  unsigned long long aesl_llvm_cbe_109_count = 0;
  unsigned int llvm_cbe_tmp__43;
  static  unsigned long long aesl_llvm_cbe_110_count = 0;
  unsigned int llvm_cbe_tmp__44;
  static  unsigned long long aesl_llvm_cbe_111_count = 0;
  static  unsigned long long aesl_llvm_cbe_112_count = 0;
  unsigned int llvm_cbe_tmp__45;
  static  unsigned long long aesl_llvm_cbe_113_count = 0;
  unsigned int llvm_cbe_tmp__46;
  static  unsigned long long aesl_llvm_cbe_114_count = 0;
  unsigned int llvm_cbe_tmp__47;
  static  unsigned long long aesl_llvm_cbe_115_count = 0;
  static  unsigned long long aesl_llvm_cbe_116_count = 0;
  unsigned int llvm_cbe_tmp__48;
  static  unsigned long long aesl_llvm_cbe_117_count = 0;
  static  unsigned long long aesl_llvm_cbe_118_count = 0;
  static  unsigned long long aesl_llvm_cbe_119_count = 0;
  static  unsigned long long aesl_llvm_cbe_120_count = 0;
  static  unsigned long long aesl_llvm_cbe_121_count = 0;
  static  unsigned long long aesl_llvm_cbe_122_count = 0;
  unsigned int llvm_cbe_tmp__49;
  static  unsigned long long aesl_llvm_cbe_123_count = 0;
  static  unsigned long long aesl_llvm_cbe_124_count = 0;
  static  unsigned long long aesl_llvm_cbe_125_count = 0;
  static  unsigned long long aesl_llvm_cbe_126_count = 0;
  static  unsigned long long aesl_llvm_cbe_127_count = 0;
  static  unsigned long long aesl_llvm_cbe_128_count = 0;
  static  unsigned long long aesl_llvm_cbe_129_count = 0;
  unsigned int llvm_cbe_tmp__50;
  static  unsigned long long aesl_llvm_cbe_130_count = 0;
  static  unsigned long long aesl_llvm_cbe_131_count = 0;
  static  unsigned long long aesl_llvm_cbe_132_count = 0;
  static  unsigned long long aesl_llvm_cbe_133_count = 0;
  static  unsigned long long aesl_llvm_cbe_134_count = 0;
  static  unsigned long long aesl_llvm_cbe_135_count = 0;
  unsigned int llvm_cbe_tmp__51;
  static  unsigned long long aesl_llvm_cbe_136_count = 0;
  unsigned int llvm_cbe_tmp__52;
  static  unsigned long long aesl_llvm_cbe_137_count = 0;
  static  unsigned long long aesl_llvm_cbe_138_count = 0;
  unsigned int llvm_cbe_tmp__53;
  static  unsigned long long aesl_llvm_cbe_139_count = 0;
  unsigned int llvm_cbe_tmp__54;
  static  unsigned long long aesl_llvm_cbe_140_count = 0;
  unsigned int llvm_cbe_tmp__55;
  static  unsigned long long aesl_llvm_cbe_141_count = 0;
  static  unsigned long long aesl_llvm_cbe_142_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @_decrypt\n");
  llvm_cbe_storemerge1__PHI_TEMPORARY = (unsigned int )17u;   /* for PHI node */
  goto llvm_cbe_tmp__56;

  do {     /* Syntactic loop '' to make GCC happy */
llvm_cbe_tmp__56:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge1 = phi i32 [ 17, %%0 ], [ %%11, %%1  for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_storemerge1_count);
  llvm_cbe_storemerge1 = (unsigned int )llvm_cbe_storemerge1__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge1 = 0x%X",llvm_cbe_storemerge1);
printf("\n = 0x%X",17u);
printf("\n = 0x%X",llvm_cbe_tmp__49);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = zext i32 %%storemerge1 to i64, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_106_count);
  llvm_cbe_tmp__40 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_storemerge1&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__40);
if (AESL_DEBUG_TRACE)
printf("\n  %%3 = getelementptr inbounds [18 x i32]* @pbox, i64 0, i64 %%2, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_107_count);
  llvm_cbe_tmp__41 = (signed int *)(&pbox[(((signed long long )llvm_cbe_tmp__40))
#ifdef AESL_BC_SIM
 % 18
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__40));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )llvm_cbe_tmp__40) < 18)) fprintf(stderr, "%s:%d: warning: Read access out of array 'pbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = load i32* %%3, align 4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_108_count);
  llvm_cbe_tmp__42 = (unsigned int )*llvm_cbe_tmp__41;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__42);
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = load i32* %%left, align 4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_109_count);
  llvm_cbe_tmp__43 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__43);
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = xor i32 %%5, %%4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_110_count);
  llvm_cbe_tmp__44 = (unsigned int )llvm_cbe_tmp__43 ^ llvm_cbe_tmp__42;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__44);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%6, i32* %%left, align 4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_111_count);
  *llvm_cbe_left = llvm_cbe_tmp__44;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__44);
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = tail call i32 @feistel_function(i32 %%6), !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_112_count);
  llvm_cbe_tmp__45 = (unsigned int ) /*tail*/ feistel_function(llvm_cbe_tmp__44);
if (AESL_DEBUG_TRACE) {
printf("\nArgument  = 0x%X",llvm_cbe_tmp__44);
printf("\nReturn  = 0x%X",llvm_cbe_tmp__45);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = load i32* %%right, align 4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_113_count);
  llvm_cbe_tmp__46 = (unsigned int )*llvm_cbe_right;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__46);
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = xor i32 %%8, %%7, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_114_count);
  llvm_cbe_tmp__47 = (unsigned int )llvm_cbe_tmp__46 ^ llvm_cbe_tmp__45;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__47);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%right, align 4, !dbg !7 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_115_count);
  *llvm_cbe_right = llvm_cbe_tmp__47;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__47);
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_116_count);
  llvm_cbe_tmp__48 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__48);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_120_count);
  *llvm_cbe_left = llvm_cbe_tmp__47;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__47);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%10, i32* %%right, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_121_count);
  *llvm_cbe_right = llvm_cbe_tmp__48;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__48);
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = add i32 %%storemerge1, -1, !dbg !9 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_122_count);
  llvm_cbe_tmp__49 = (unsigned int )((unsigned int )(llvm_cbe_storemerge1&4294967295ull)) + ((unsigned int )(4294967295u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__49&4294967295ull)));
  if ((((unsigned int )llvm_cbe_tmp__49&4294967295U) > ((unsigned int )1u&4294967295U))) {
    llvm_cbe_storemerge1__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__49;   /* for PHI node */
    goto llvm_cbe_tmp__56;
  } else {
    goto llvm_cbe_tmp__57;
  }

  } while (1); /* end of syntactic loop '' */
llvm_cbe_tmp__57:
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_129_count);
  llvm_cbe_tmp__50 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__50);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%10, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_133_count);
  *llvm_cbe_left = llvm_cbe_tmp__48;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__48);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%14, i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_134_count);
  *llvm_cbe_right = llvm_cbe_tmp__50;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__50);
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = load i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 1), align 4, !dbg !9 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_135_count);
  llvm_cbe_tmp__51 = (unsigned int )*((&pbox[(((signed long long )1ull))
#ifdef AESL_BC_SIM
 % 18
#endif
]));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__51);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = xor i32 %%15, %%14, !dbg !9 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_136_count);
  llvm_cbe_tmp__52 = (unsigned int )llvm_cbe_tmp__51 ^ llvm_cbe_tmp__50;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__52);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%16, i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_137_count);
  *llvm_cbe_right = llvm_cbe_tmp__52;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__52);
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = load i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 0), align 16, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_138_count);
  llvm_cbe_tmp__53 = (unsigned int )*((&pbox[(((signed long long )0ull))
#ifdef AESL_BC_SIM
 % 18
#endif
]));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__53);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = load i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_139_count);
  llvm_cbe_tmp__54 = (unsigned int )*llvm_cbe_left;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__54);
if (AESL_DEBUG_TRACE)
printf("\n  %%19 = xor i32 %%18, %%17, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_140_count);
  llvm_cbe_tmp__55 = (unsigned int )llvm_cbe_tmp__54 ^ llvm_cbe_tmp__53;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__55);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%19, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @_decrypt  --> \n", ++aesl_llvm_cbe_141_count);
  *llvm_cbe_left = llvm_cbe_tmp__55;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__55);
  if (AESL_DEBUG_TRACE)
      printf("\nEND @_decrypt}\n");
  return;
}


void blowfish_init( char *llvm_cbe_key, signed int llvm_cbe_size) {
  static  unsigned long long aesl_llvm_cbe_left_count = 0;
  signed int llvm_cbe_left;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_right_count = 0;
  signed int llvm_cbe_right;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_143_count = 0;
  static  unsigned long long aesl_llvm_cbe_144_count = 0;
  static  unsigned long long aesl_llvm_cbe_145_count = 0;
  static  unsigned long long aesl_llvm_cbe_146_count = 0;
  static  unsigned long long aesl_llvm_cbe_147_count = 0;
  static  unsigned long long aesl_llvm_cbe_148_count = 0;
  static  unsigned long long aesl_llvm_cbe_149_count = 0;
  static  unsigned long long aesl_llvm_cbe_150_count = 0;
  static  unsigned long long aesl_llvm_cbe_151_count = 0;
  static  unsigned long long aesl_llvm_cbe_152_count = 0;
  static  unsigned long long aesl_llvm_cbe_153_count = 0;
  static  unsigned long long aesl_llvm_cbe_154_count = 0;
  static  unsigned long long aesl_llvm_cbe_155_count = 0;
  static  unsigned long long aesl_llvm_cbe_156_count = 0;
  static  unsigned long long aesl_llvm_cbe_157_count = 0;
  static  unsigned long long aesl_llvm_cbe_158_count = 0;
  static  unsigned long long aesl_llvm_cbe_159_count = 0;
  static  unsigned long long aesl_llvm_cbe_160_count = 0;
  static  unsigned long long aesl_llvm_cbe_161_count = 0;
  static  unsigned long long aesl_llvm_cbe_162_count = 0;
  static  unsigned long long aesl_llvm_cbe_163_count = 0;
  static  unsigned long long aesl_llvm_cbe_164_count = 0;
  static  unsigned long long aesl_llvm_cbe_165_count = 0;
  static  unsigned long long aesl_llvm_cbe_166_count = 0;
  static  unsigned long long aesl_llvm_cbe_167_count = 0;
  static  unsigned long long aesl_llvm_cbe_168_count = 0;
  static  unsigned long long aesl_llvm_cbe_169_count = 0;
  static  unsigned long long aesl_llvm_cbe_170_count = 0;
  static  unsigned long long aesl_llvm_cbe_171_count = 0;
  static  unsigned long long aesl_llvm_cbe_172_count = 0;
  static  unsigned long long aesl_llvm_cbe_173_count = 0;
  static  unsigned long long aesl_llvm_cbe_174_count = 0;
  static  unsigned long long aesl_llvm_cbe_175_count = 0;
  static  unsigned long long aesl_llvm_cbe_176_count = 0;
  static  unsigned long long aesl_llvm_cbe_177_count = 0;
  static  unsigned long long aesl_llvm_cbe_178_count = 0;
  static  unsigned long long aesl_llvm_cbe_179_count = 0;
  static  unsigned long long aesl_llvm_cbe_180_count = 0;
  static  unsigned long long aesl_llvm_cbe_181_count = 0;
  static  unsigned long long aesl_llvm_cbe_182_count = 0;
  static  unsigned long long aesl_llvm_cbe_183_count = 0;
  static  unsigned long long aesl_llvm_cbe_184_count = 0;
  static  unsigned long long aesl_llvm_cbe_185_count = 0;
  static  unsigned long long aesl_llvm_cbe_186_count = 0;
  static  unsigned long long aesl_llvm_cbe_187_count = 0;
  static  unsigned long long aesl_llvm_cbe_188_count = 0;
  static  unsigned long long aesl_llvm_cbe_189_count = 0;
  static  unsigned long long aesl_llvm_cbe_190_count = 0;
  static  unsigned long long aesl_llvm_cbe_191_count = 0;
  static  unsigned long long aesl_llvm_cbe_192_count = 0;
  static  unsigned long long aesl_llvm_cbe_193_count = 0;
  static  unsigned long long aesl_llvm_cbe_194_count = 0;
  static  unsigned long long aesl_llvm_cbe_195_count = 0;
  static  unsigned long long aesl_llvm_cbe_196_count = 0;
  static  unsigned long long aesl_llvm_cbe_197_count = 0;
  static  unsigned long long aesl_llvm_cbe_198_count = 0;
  static  unsigned long long aesl_llvm_cbe_199_count = 0;
  static  unsigned long long aesl_llvm_cbe_200_count = 0;
  static  unsigned long long aesl_llvm_cbe_201_count = 0;
  static  unsigned long long aesl_llvm_cbe_202_count = 0;
  static  unsigned long long aesl_llvm_cbe_203_count = 0;
  static  unsigned long long aesl_llvm_cbe_204_count = 0;
  static  unsigned long long aesl_llvm_cbe_205_count = 0;
  static  unsigned long long aesl_llvm_cbe_206_count = 0;
  static  unsigned long long aesl_llvm_cbe_207_count = 0;
  static  unsigned long long aesl_llvm_cbe_208_count = 0;
  static  unsigned long long aesl_llvm_cbe_209_count = 0;
  static  unsigned long long aesl_llvm_cbe_210_count = 0;
  unsigned int llvm_cbe_tmp__58;
  static  unsigned long long aesl_llvm_cbe_211_count = 0;
  static  unsigned long long aesl_llvm_cbe_212_count = 0;
  static  unsigned long long aesl_llvm_cbe_213_count = 0;
  static  unsigned long long aesl_llvm_cbe_214_count = 0;
  static  unsigned long long aesl_llvm_cbe_215_count = 0;
  static  unsigned long long aesl_llvm_cbe_216_count = 0;
  static  unsigned long long aesl_llvm_cbe_217_count = 0;
  static  unsigned long long aesl_llvm_cbe_218_count = 0;
  unsigned int llvm_cbe_tmp__59;
  static  unsigned long long aesl_llvm_cbe_219_count = 0;
  static  unsigned long long aesl_llvm_cbe_220_count = 0;
  static  unsigned long long aesl_llvm_cbe_221_count = 0;
  static  unsigned long long aesl_llvm_cbe_222_count = 0;
  static  unsigned long long aesl_llvm_cbe_223_count = 0;
  static  unsigned long long aesl_llvm_cbe_224_count = 0;
  static  unsigned long long aesl_llvm_cbe_225_count = 0;
  static  unsigned long long aesl_llvm_cbe_226_count = 0;
  static  unsigned long long aesl_llvm_cbe_227_count = 0;
  static  unsigned long long aesl_llvm_cbe_228_count = 0;
  static  unsigned long long aesl_llvm_cbe_229_count = 0;
  static  unsigned long long aesl_llvm_cbe_230_count = 0;
  static  unsigned long long aesl_llvm_cbe_231_count = 0;
  static  unsigned long long aesl_llvm_cbe_232_count = 0;
  static  unsigned long long aesl_llvm_cbe_233_count = 0;
  static  unsigned long long aesl_llvm_cbe_234_count = 0;
  static  unsigned long long aesl_llvm_cbe_235_count = 0;
  static  unsigned long long aesl_llvm_cbe_236_count = 0;
  static  unsigned long long aesl_llvm_cbe_237_count = 0;
  static  unsigned long long aesl_llvm_cbe_238_count = 0;
  static  unsigned long long aesl_llvm_cbe_239_count = 0;
  static  unsigned long long aesl_llvm_cbe_240_count = 0;
  static  unsigned long long aesl_llvm_cbe_241_count = 0;
  static  unsigned long long aesl_llvm_cbe_242_count = 0;
  static  unsigned long long aesl_llvm_cbe_243_count = 0;
  unsigned int llvm_cbe_tmp__60;
  static  unsigned long long aesl_llvm_cbe_244_count = 0;
  static  unsigned long long aesl_llvm_cbe_245_count = 0;
  static  unsigned long long aesl_llvm_cbe_246_count = 0;
  static  unsigned long long aesl_llvm_cbe_247_count = 0;
  static  unsigned long long aesl_llvm_cbe_248_count = 0;
  static  unsigned long long aesl_llvm_cbe_249_count = 0;
  static  unsigned long long aesl_llvm_cbe_250_count = 0;
  static  unsigned long long aesl_llvm_cbe_251_count = 0;
  unsigned int llvm_cbe_tmp__61;
  static  unsigned long long aesl_llvm_cbe_252_count = 0;
  static  unsigned long long aesl_llvm_cbe_253_count = 0;
  static  unsigned long long aesl_llvm_cbe_254_count = 0;
  static  unsigned long long aesl_llvm_cbe_255_count = 0;
  static  unsigned long long aesl_llvm_cbe_256_count = 0;
  static  unsigned long long aesl_llvm_cbe_257_count = 0;
  static  unsigned long long aesl_llvm_cbe_258_count = 0;
  static  unsigned long long aesl_llvm_cbe_259_count = 0;
  static  unsigned long long aesl_llvm_cbe_260_count = 0;
  static  unsigned long long aesl_llvm_cbe_261_count = 0;
  static  unsigned long long aesl_llvm_cbe_262_count = 0;
  static  unsigned long long aesl_llvm_cbe_263_count = 0;
  static  unsigned long long aesl_llvm_cbe_264_count = 0;
  static  unsigned long long aesl_llvm_cbe_265_count = 0;
  static  unsigned long long aesl_llvm_cbe_266_count = 0;
  static  unsigned long long aesl_llvm_cbe_267_count = 0;
  static  unsigned long long aesl_llvm_cbe_268_count = 0;
  static  unsigned long long aesl_llvm_cbe_269_count = 0;
  static  unsigned long long aesl_llvm_cbe_270_count = 0;
  static  unsigned long long aesl_llvm_cbe_271_count = 0;
  static  unsigned long long aesl_llvm_cbe_272_count = 0;
  static  unsigned long long aesl_llvm_cbe_273_count = 0;
  static  unsigned long long aesl_llvm_cbe_274_count = 0;
  static  unsigned long long aesl_llvm_cbe_275_count = 0;
  static  unsigned long long aesl_llvm_cbe_276_count = 0;
  unsigned int llvm_cbe_tmp__62;
  static  unsigned long long aesl_llvm_cbe_277_count = 0;
  static  unsigned long long aesl_llvm_cbe_278_count = 0;
  static  unsigned long long aesl_llvm_cbe_279_count = 0;
  static  unsigned long long aesl_llvm_cbe_280_count = 0;
  static  unsigned long long aesl_llvm_cbe_281_count = 0;
  static  unsigned long long aesl_llvm_cbe_282_count = 0;
  static  unsigned long long aesl_llvm_cbe_283_count = 0;
  static  unsigned long long aesl_llvm_cbe_284_count = 0;
  unsigned int llvm_cbe_tmp__63;
  static  unsigned long long aesl_llvm_cbe_285_count = 0;
  static  unsigned long long aesl_llvm_cbe_286_count = 0;
  static  unsigned long long aesl_llvm_cbe_287_count = 0;
  static  unsigned long long aesl_llvm_cbe_288_count = 0;
  static  unsigned long long aesl_llvm_cbe_289_count = 0;
  static  unsigned long long aesl_llvm_cbe_290_count = 0;
  static  unsigned long long aesl_llvm_cbe_291_count = 0;
  static  unsigned long long aesl_llvm_cbe_292_count = 0;
  static  unsigned long long aesl_llvm_cbe_293_count = 0;
  static  unsigned long long aesl_llvm_cbe_294_count = 0;
  static  unsigned long long aesl_llvm_cbe_295_count = 0;
  static  unsigned long long aesl_llvm_cbe_296_count = 0;
  static  unsigned long long aesl_llvm_cbe_297_count = 0;
  static  unsigned long long aesl_llvm_cbe_298_count = 0;
  static  unsigned long long aesl_llvm_cbe_299_count = 0;
  static  unsigned long long aesl_llvm_cbe_300_count = 0;
  static  unsigned long long aesl_llvm_cbe_301_count = 0;
  static  unsigned long long aesl_llvm_cbe_302_count = 0;
  static  unsigned long long aesl_llvm_cbe_303_count = 0;
  static  unsigned long long aesl_llvm_cbe_304_count = 0;
  static  unsigned long long aesl_llvm_cbe_305_count = 0;
  static  unsigned long long aesl_llvm_cbe_306_count = 0;
  static  unsigned long long aesl_llvm_cbe_307_count = 0;
  static  unsigned long long aesl_llvm_cbe_308_count = 0;
  static  unsigned long long aesl_llvm_cbe_309_count = 0;
  unsigned int llvm_cbe_tmp__64;
  static  unsigned long long aesl_llvm_cbe_310_count = 0;
  static  unsigned long long aesl_llvm_cbe_311_count = 0;
  static  unsigned long long aesl_llvm_cbe_312_count = 0;
  static  unsigned long long aesl_llvm_cbe_313_count = 0;
  static  unsigned long long aesl_llvm_cbe_314_count = 0;
  static  unsigned long long aesl_llvm_cbe_315_count = 0;
  static  unsigned long long aesl_llvm_cbe_316_count = 0;
  static  unsigned long long aesl_llvm_cbe_317_count = 0;
  unsigned int llvm_cbe_tmp__65;
  static  unsigned long long aesl_llvm_cbe_318_count = 0;
  static  unsigned long long aesl_llvm_cbe_319_count = 0;
  static  unsigned long long aesl_llvm_cbe_320_count = 0;
  static  unsigned long long aesl_llvm_cbe_321_count = 0;
  static  unsigned long long aesl_llvm_cbe_322_count = 0;
  static  unsigned long long aesl_llvm_cbe_323_count = 0;
  static  unsigned long long aesl_llvm_cbe_324_count = 0;
  static  unsigned long long aesl_llvm_cbe_325_count = 0;
  static  unsigned long long aesl_llvm_cbe_326_count = 0;
  static  unsigned long long aesl_llvm_cbe_327_count = 0;
  static  unsigned long long aesl_llvm_cbe_328_count = 0;
  static  unsigned long long aesl_llvm_cbe_329_count = 0;
  static  unsigned long long aesl_llvm_cbe_330_count = 0;
  static  unsigned long long aesl_llvm_cbe_331_count = 0;
  static  unsigned long long aesl_llvm_cbe_332_count = 0;
  static  unsigned long long aesl_llvm_cbe_333_count = 0;
  static  unsigned long long aesl_llvm_cbe_334_count = 0;
  static  unsigned long long aesl_llvm_cbe_335_count = 0;
  static  unsigned long long aesl_llvm_cbe_336_count = 0;
  static  unsigned long long aesl_llvm_cbe_337_count = 0;
  static  unsigned long long aesl_llvm_cbe_338_count = 0;
  static  unsigned long long aesl_llvm_cbe_339_count = 0;
  static  unsigned long long aesl_llvm_cbe_340_count = 0;
  static  unsigned long long aesl_llvm_cbe_341_count = 0;
  static  unsigned long long aesl_llvm_cbe_342_count = 0;
  unsigned int llvm_cbe_tmp__66;
  static  unsigned long long aesl_llvm_cbe_343_count = 0;
  static  unsigned long long aesl_llvm_cbe_344_count = 0;
  static  unsigned long long aesl_llvm_cbe_345_count = 0;
  static  unsigned long long aesl_llvm_cbe_346_count = 0;
  static  unsigned long long aesl_llvm_cbe_347_count = 0;
  static  unsigned long long aesl_llvm_cbe_348_count = 0;
  static  unsigned long long aesl_llvm_cbe_349_count = 0;
  static  unsigned long long aesl_llvm_cbe_350_count = 0;
  unsigned int llvm_cbe_tmp__67;
  static  unsigned long long aesl_llvm_cbe_351_count = 0;
  static  unsigned long long aesl_llvm_cbe_352_count = 0;
  static  unsigned long long aesl_llvm_cbe_353_count = 0;
  static  unsigned long long aesl_llvm_cbe_354_count = 0;
  static  unsigned long long aesl_llvm_cbe_355_count = 0;
  static  unsigned long long aesl_llvm_cbe_356_count = 0;
  static  unsigned long long aesl_llvm_cbe_357_count = 0;
  static  unsigned long long aesl_llvm_cbe_358_count = 0;
  static  unsigned long long aesl_llvm_cbe_359_count = 0;
  static  unsigned long long aesl_llvm_cbe_360_count = 0;
  static  unsigned long long aesl_llvm_cbe_361_count = 0;
  static  unsigned long long aesl_llvm_cbe_362_count = 0;
  static  unsigned long long aesl_llvm_cbe_363_count = 0;
  static  unsigned long long aesl_llvm_cbe_364_count = 0;
  static  unsigned long long aesl_llvm_cbe_365_count = 0;
  static  unsigned long long aesl_llvm_cbe_366_count = 0;
  static  unsigned long long aesl_llvm_cbe_367_count = 0;
  static  unsigned long long aesl_llvm_cbe_368_count = 0;
  static  unsigned long long aesl_llvm_cbe_369_count = 0;
  static  unsigned long long aesl_llvm_cbe_370_count = 0;
  static  unsigned long long aesl_llvm_cbe_371_count = 0;
  static  unsigned long long aesl_llvm_cbe_372_count = 0;
  static  unsigned long long aesl_llvm_cbe_373_count = 0;
  static  unsigned long long aesl_llvm_cbe_374_count = 0;
  static  unsigned long long aesl_llvm_cbe_375_count = 0;
  unsigned int llvm_cbe_tmp__68;
  static  unsigned long long aesl_llvm_cbe_376_count = 0;
  static  unsigned long long aesl_llvm_cbe_377_count = 0;
  static  unsigned long long aesl_llvm_cbe_378_count = 0;
  static  unsigned long long aesl_llvm_cbe_379_count = 0;
  static  unsigned long long aesl_llvm_cbe_380_count = 0;
  static  unsigned long long aesl_llvm_cbe_381_count = 0;
  static  unsigned long long aesl_llvm_cbe_382_count = 0;
  static  unsigned long long aesl_llvm_cbe_383_count = 0;
  unsigned int llvm_cbe_tmp__69;
  static  unsigned long long aesl_llvm_cbe_384_count = 0;
  static  unsigned long long aesl_llvm_cbe_385_count = 0;
  static  unsigned long long aesl_llvm_cbe_386_count = 0;
  static  unsigned long long aesl_llvm_cbe_387_count = 0;
  static  unsigned long long aesl_llvm_cbe_388_count = 0;
  static  unsigned long long aesl_llvm_cbe_389_count = 0;
  static  unsigned long long aesl_llvm_cbe_390_count = 0;
  static  unsigned long long aesl_llvm_cbe_391_count = 0;
  static  unsigned long long aesl_llvm_cbe_392_count = 0;
  static  unsigned long long aesl_llvm_cbe_393_count = 0;
  static  unsigned long long aesl_llvm_cbe_394_count = 0;
  static  unsigned long long aesl_llvm_cbe_395_count = 0;
  static  unsigned long long aesl_llvm_cbe_396_count = 0;
  static  unsigned long long aesl_llvm_cbe_397_count = 0;
  static  unsigned long long aesl_llvm_cbe_398_count = 0;
  static  unsigned long long aesl_llvm_cbe_399_count = 0;
  static  unsigned long long aesl_llvm_cbe_400_count = 0;
  static  unsigned long long aesl_llvm_cbe_401_count = 0;
  static  unsigned long long aesl_llvm_cbe_402_count = 0;
  static  unsigned long long aesl_llvm_cbe_403_count = 0;
  static  unsigned long long aesl_llvm_cbe_404_count = 0;
  static  unsigned long long aesl_llvm_cbe_405_count = 0;
  static  unsigned long long aesl_llvm_cbe_406_count = 0;
  static  unsigned long long aesl_llvm_cbe_407_count = 0;
  static  unsigned long long aesl_llvm_cbe_408_count = 0;
  unsigned int llvm_cbe_tmp__70;
  static  unsigned long long aesl_llvm_cbe_409_count = 0;
  static  unsigned long long aesl_llvm_cbe_410_count = 0;
  static  unsigned long long aesl_llvm_cbe_411_count = 0;
  static  unsigned long long aesl_llvm_cbe_412_count = 0;
  static  unsigned long long aesl_llvm_cbe_413_count = 0;
  static  unsigned long long aesl_llvm_cbe_414_count = 0;
  static  unsigned long long aesl_llvm_cbe_415_count = 0;
  static  unsigned long long aesl_llvm_cbe_416_count = 0;
  unsigned int llvm_cbe_tmp__71;
  static  unsigned long long aesl_llvm_cbe_417_count = 0;
  static  unsigned long long aesl_llvm_cbe_418_count = 0;
  static  unsigned long long aesl_llvm_cbe_419_count = 0;
  static  unsigned long long aesl_llvm_cbe_420_count = 0;
  static  unsigned long long aesl_llvm_cbe_421_count = 0;
  static  unsigned long long aesl_llvm_cbe_422_count = 0;
  static  unsigned long long aesl_llvm_cbe_423_count = 0;
  static  unsigned long long aesl_llvm_cbe_424_count = 0;
  static  unsigned long long aesl_llvm_cbe_425_count = 0;
  static  unsigned long long aesl_llvm_cbe_426_count = 0;
  static  unsigned long long aesl_llvm_cbe_427_count = 0;
  static  unsigned long long aesl_llvm_cbe_428_count = 0;
  static  unsigned long long aesl_llvm_cbe_429_count = 0;
  static  unsigned long long aesl_llvm_cbe_430_count = 0;
  static  unsigned long long aesl_llvm_cbe_431_count = 0;
  static  unsigned long long aesl_llvm_cbe_432_count = 0;
  static  unsigned long long aesl_llvm_cbe_433_count = 0;
  static  unsigned long long aesl_llvm_cbe_434_count = 0;
  static  unsigned long long aesl_llvm_cbe_435_count = 0;
  static  unsigned long long aesl_llvm_cbe_436_count = 0;
  static  unsigned long long aesl_llvm_cbe_437_count = 0;
  static  unsigned long long aesl_llvm_cbe_438_count = 0;
  static  unsigned long long aesl_llvm_cbe_439_count = 0;
  static  unsigned long long aesl_llvm_cbe_440_count = 0;
  static  unsigned long long aesl_llvm_cbe_441_count = 0;
  unsigned int llvm_cbe_tmp__72;
  static  unsigned long long aesl_llvm_cbe_442_count = 0;
  static  unsigned long long aesl_llvm_cbe_443_count = 0;
  static  unsigned long long aesl_llvm_cbe_444_count = 0;
  static  unsigned long long aesl_llvm_cbe_445_count = 0;
  static  unsigned long long aesl_llvm_cbe_446_count = 0;
  static  unsigned long long aesl_llvm_cbe_447_count = 0;
  static  unsigned long long aesl_llvm_cbe_448_count = 0;
  static  unsigned long long aesl_llvm_cbe_449_count = 0;
  unsigned int llvm_cbe_tmp__73;
  static  unsigned long long aesl_llvm_cbe_450_count = 0;
  static  unsigned long long aesl_llvm_cbe_451_count = 0;
  static  unsigned long long aesl_llvm_cbe_452_count = 0;
  static  unsigned long long aesl_llvm_cbe_453_count = 0;
  static  unsigned long long aesl_llvm_cbe_454_count = 0;
  static  unsigned long long aesl_llvm_cbe_455_count = 0;
  static  unsigned long long aesl_llvm_cbe_456_count = 0;
  static  unsigned long long aesl_llvm_cbe_457_count = 0;
  static  unsigned long long aesl_llvm_cbe_458_count = 0;
  static  unsigned long long aesl_llvm_cbe_459_count = 0;
  static  unsigned long long aesl_llvm_cbe_460_count = 0;
  static  unsigned long long aesl_llvm_cbe_461_count = 0;
  static  unsigned long long aesl_llvm_cbe_462_count = 0;
  static  unsigned long long aesl_llvm_cbe_463_count = 0;
  static  unsigned long long aesl_llvm_cbe_464_count = 0;
  static  unsigned long long aesl_llvm_cbe_465_count = 0;
  static  unsigned long long aesl_llvm_cbe_466_count = 0;
  static  unsigned long long aesl_llvm_cbe_467_count = 0;
  static  unsigned long long aesl_llvm_cbe_468_count = 0;
  static  unsigned long long aesl_llvm_cbe_469_count = 0;
  static  unsigned long long aesl_llvm_cbe_470_count = 0;
  static  unsigned long long aesl_llvm_cbe_471_count = 0;
  static  unsigned long long aesl_llvm_cbe_472_count = 0;
  static  unsigned long long aesl_llvm_cbe_473_count = 0;
  static  unsigned long long aesl_llvm_cbe_474_count = 0;
  unsigned int llvm_cbe_tmp__74;
  static  unsigned long long aesl_llvm_cbe_475_count = 0;
  static  unsigned long long aesl_llvm_cbe_476_count = 0;
  static  unsigned long long aesl_llvm_cbe_477_count = 0;
  static  unsigned long long aesl_llvm_cbe_478_count = 0;
  static  unsigned long long aesl_llvm_cbe_479_count = 0;
  static  unsigned long long aesl_llvm_cbe_480_count = 0;
  static  unsigned long long aesl_llvm_cbe_481_count = 0;
  static  unsigned long long aesl_llvm_cbe_482_count = 0;
  unsigned int llvm_cbe_tmp__75;
  static  unsigned long long aesl_llvm_cbe_483_count = 0;
  static  unsigned long long aesl_llvm_cbe_484_count = 0;
  static  unsigned long long aesl_llvm_cbe_485_count = 0;
  static  unsigned long long aesl_llvm_cbe_486_count = 0;
  static  unsigned long long aesl_llvm_cbe_487_count = 0;
  static  unsigned long long aesl_llvm_cbe_488_count = 0;
  static  unsigned long long aesl_llvm_cbe_489_count = 0;
  static  unsigned long long aesl_llvm_cbe_490_count = 0;
  static  unsigned long long aesl_llvm_cbe_491_count = 0;
  static  unsigned long long aesl_llvm_cbe_492_count = 0;
  static  unsigned long long aesl_llvm_cbe_493_count = 0;
  static  unsigned long long aesl_llvm_cbe_494_count = 0;
  static  unsigned long long aesl_llvm_cbe_495_count = 0;
  static  unsigned long long aesl_llvm_cbe_496_count = 0;
  static  unsigned long long aesl_llvm_cbe_497_count = 0;
  static  unsigned long long aesl_llvm_cbe_498_count = 0;
  static  unsigned long long aesl_llvm_cbe_499_count = 0;
  static  unsigned long long aesl_llvm_cbe_500_count = 0;
  static  unsigned long long aesl_llvm_cbe_501_count = 0;
  static  unsigned long long aesl_llvm_cbe_502_count = 0;
  static  unsigned long long aesl_llvm_cbe_503_count = 0;
  static  unsigned long long aesl_llvm_cbe_504_count = 0;
  static  unsigned long long aesl_llvm_cbe_505_count = 0;
  static  unsigned long long aesl_llvm_cbe_506_count = 0;
  static  unsigned long long aesl_llvm_cbe_507_count = 0;
  static  unsigned long long aesl_llvm_cbe_508_count = 0;
  static  unsigned long long aesl_llvm_cbe_509_count = 0;
  static  unsigned long long aesl_llvm_cbe_510_count = 0;
  static  unsigned long long aesl_llvm_cbe_511_count = 0;
  static  unsigned long long aesl_llvm_cbe_512_count = 0;
  static  unsigned long long aesl_llvm_cbe_513_count = 0;
  static  unsigned long long aesl_llvm_cbe_514_count = 0;
  static  unsigned long long aesl_llvm_cbe_515_count = 0;
  static  unsigned long long aesl_llvm_cbe_516_count = 0;
  static  unsigned long long aesl_llvm_cbe_517_count = 0;
  static  unsigned long long aesl_llvm_cbe_518_count = 0;
  static  unsigned long long aesl_llvm_cbe_519_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge9_count = 0;
  unsigned int llvm_cbe_storemerge9;
  unsigned int llvm_cbe_storemerge9__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_520_count = 0;
  unsigned int llvm_cbe_tmp__76;
  static  unsigned long long aesl_llvm_cbe_521_count = 0;
  unsigned long long llvm_cbe_tmp__77;
  static  unsigned long long aesl_llvm_cbe_522_count = 0;
   char *llvm_cbe_tmp__78;
  static  unsigned long long aesl_llvm_cbe_523_count = 0;
  unsigned char llvm_cbe_tmp__79;
  static  unsigned long long aesl_llvm_cbe_524_count = 0;
  unsigned int llvm_cbe_tmp__80;
  static  unsigned long long aesl_llvm_cbe_525_count = 0;
  unsigned int llvm_cbe_tmp__81;
  static  unsigned long long aesl_llvm_cbe_526_count = 0;
  unsigned int llvm_cbe_tmp__82;
  static  unsigned long long aesl_llvm_cbe_527_count = 0;
  unsigned int llvm_cbe_tmp__83;
  static  unsigned long long aesl_llvm_cbe_528_count = 0;
  unsigned long long llvm_cbe_tmp__84;
  static  unsigned long long aesl_llvm_cbe_529_count = 0;
   char *llvm_cbe_tmp__85;
  static  unsigned long long aesl_llvm_cbe_530_count = 0;
  unsigned char llvm_cbe_tmp__86;
  static  unsigned long long aesl_llvm_cbe_531_count = 0;
  unsigned int llvm_cbe_tmp__87;
  static  unsigned long long aesl_llvm_cbe_532_count = 0;
  unsigned int llvm_cbe_tmp__88;
  static  unsigned long long aesl_llvm_cbe_533_count = 0;
  unsigned int llvm_cbe_tmp__89;
  static  unsigned long long aesl_llvm_cbe_534_count = 0;
  unsigned int llvm_cbe_tmp__90;
  static  unsigned long long aesl_llvm_cbe_535_count = 0;
  unsigned long long llvm_cbe_tmp__91;
  static  unsigned long long aesl_llvm_cbe_536_count = 0;
   char *llvm_cbe_tmp__92;
  static  unsigned long long aesl_llvm_cbe_537_count = 0;
  unsigned char llvm_cbe_tmp__93;
  static  unsigned long long aesl_llvm_cbe_538_count = 0;
  unsigned int llvm_cbe_tmp__94;
  static  unsigned long long aesl_llvm_cbe_539_count = 0;
  unsigned int llvm_cbe_tmp__95;
  static  unsigned long long aesl_llvm_cbe_540_count = 0;
  unsigned int llvm_cbe_tmp__96;
  static  unsigned long long aesl_llvm_cbe_541_count = 0;
  unsigned int llvm_cbe_tmp__97;
  static  unsigned long long aesl_llvm_cbe_542_count = 0;
  unsigned long long llvm_cbe_tmp__98;
  static  unsigned long long aesl_llvm_cbe_543_count = 0;
   char *llvm_cbe_tmp__99;
  static  unsigned long long aesl_llvm_cbe_544_count = 0;
  unsigned char llvm_cbe_tmp__100;
  static  unsigned long long aesl_llvm_cbe_545_count = 0;
  unsigned int llvm_cbe_tmp__101;
  static  unsigned long long aesl_llvm_cbe_546_count = 0;
  unsigned int llvm_cbe_tmp__102;
  static  unsigned long long aesl_llvm_cbe_547_count = 0;
  unsigned int llvm_cbe_tmp__103;
  static  unsigned long long aesl_llvm_cbe_548_count = 0;
  unsigned int llvm_cbe_tmp__104;
  static  unsigned long long aesl_llvm_cbe_549_count = 0;
  unsigned long long llvm_cbe_tmp__105;
  static  unsigned long long aesl_llvm_cbe_550_count = 0;
  signed int *llvm_cbe_tmp__106;
  static  unsigned long long aesl_llvm_cbe_551_count = 0;
  unsigned int llvm_cbe_tmp__107;
  static  unsigned long long aesl_llvm_cbe_552_count = 0;
  unsigned int llvm_cbe_tmp__108;
  static  unsigned long long aesl_llvm_cbe_553_count = 0;
  static  unsigned long long aesl_llvm_cbe_554_count = 0;
  static  unsigned long long aesl_llvm_cbe_555_count = 0;
  static  unsigned long long aesl_llvm_cbe_556_count = 0;
  static  unsigned long long aesl_llvm_cbe_557_count = 0;
  static  unsigned long long aesl_llvm_cbe_558_count = 0;
  static  unsigned long long aesl_llvm_cbe_559_count = 0;
  static  unsigned long long aesl_llvm_cbe_560_count = 0;
  static  unsigned long long aesl_llvm_cbe_561_count = 0;
  static  unsigned long long aesl_llvm_cbe_562_count = 0;
  static  unsigned long long aesl_llvm_cbe_563_count = 0;
  static  unsigned long long aesl_llvm_cbe_564_count = 0;
  static  unsigned long long aesl_llvm_cbe_565_count = 0;
  static  unsigned long long aesl_llvm_cbe_566_count = 0;
  static  unsigned long long aesl_llvm_cbe_567_count = 0;
  static  unsigned long long aesl_llvm_cbe_568_count = 0;
  static  unsigned long long aesl_llvm_cbe_569_count = 0;
  static  unsigned long long aesl_llvm_cbe_exitcond_count = 0;
  static  unsigned long long aesl_llvm_cbe_570_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge34_count = 0;
  unsigned int llvm_cbe_storemerge34;
  unsigned int llvm_cbe_storemerge34__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_571_count = 0;
  static  unsigned long long aesl_llvm_cbe_572_count = 0;
  static  unsigned long long aesl_llvm_cbe_573_count = 0;
  static  unsigned long long aesl_llvm_cbe_574_count = 0;
  static  unsigned long long aesl_llvm_cbe_575_count = 0;
  static  unsigned long long aesl_llvm_cbe_576_count = 0;
  static  unsigned long long aesl_llvm_cbe_577_count = 0;
  static  unsigned long long aesl_llvm_cbe_578_count = 0;
  unsigned int llvm_cbe_tmp__109;
  static  unsigned long long aesl_llvm_cbe_579_count = 0;
  unsigned long long llvm_cbe_tmp__110;
  static  unsigned long long aesl_llvm_cbe_580_count = 0;
  signed int *llvm_cbe_tmp__111;
  static  unsigned long long aesl_llvm_cbe_581_count = 0;
  static  unsigned long long aesl_llvm_cbe_582_count = 0;
  static  unsigned long long aesl_llvm_cbe_583_count = 0;
  static  unsigned long long aesl_llvm_cbe_584_count = 0;
  static  unsigned long long aesl_llvm_cbe_585_count = 0;
  static  unsigned long long aesl_llvm_cbe_586_count = 0;
  static  unsigned long long aesl_llvm_cbe_587_count = 0;
  static  unsigned long long aesl_llvm_cbe_588_count = 0;
  unsigned int llvm_cbe_tmp__112;
  static  unsigned long long aesl_llvm_cbe_589_count = 0;
  unsigned int llvm_cbe_tmp__113;
  static  unsigned long long aesl_llvm_cbe_590_count = 0;
  unsigned long long llvm_cbe_tmp__114;
  static  unsigned long long aesl_llvm_cbe_591_count = 0;
  signed int *llvm_cbe_tmp__115;
  static  unsigned long long aesl_llvm_cbe_592_count = 0;
  static  unsigned long long aesl_llvm_cbe_593_count = 0;
  unsigned int llvm_cbe_tmp__116;
  static  unsigned long long aesl_llvm_cbe_594_count = 0;
  static  unsigned long long aesl_llvm_cbe_595_count = 0;
  static  unsigned long long aesl_llvm_cbe_596_count = 0;
  static  unsigned long long aesl_llvm_cbe_597_count = 0;
  static  unsigned long long aesl_llvm_cbe_598_count = 0;
  static  unsigned long long aesl_llvm_cbe_599_count = 0;
  static  unsigned long long aesl_llvm_cbe_600_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge34_2e_1_count = 0;
  unsigned int llvm_cbe_storemerge34_2e_1;
  unsigned int llvm_cbe_storemerge34_2e_1__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_601_count = 0;
  static  unsigned long long aesl_llvm_cbe_602_count = 0;
  static  unsigned long long aesl_llvm_cbe_603_count = 0;
  static  unsigned long long aesl_llvm_cbe_604_count = 0;
  static  unsigned long long aesl_llvm_cbe_605_count = 0;
  static  unsigned long long aesl_llvm_cbe_606_count = 0;
  static  unsigned long long aesl_llvm_cbe_607_count = 0;
  static  unsigned long long aesl_llvm_cbe_608_count = 0;
  unsigned int llvm_cbe_tmp__117;
  static  unsigned long long aesl_llvm_cbe_609_count = 0;
  unsigned long long llvm_cbe_tmp__118;
  static  unsigned long long aesl_llvm_cbe_610_count = 0;
  signed int *llvm_cbe_tmp__119;
  static  unsigned long long aesl_llvm_cbe_611_count = 0;
  static  unsigned long long aesl_llvm_cbe_612_count = 0;
  static  unsigned long long aesl_llvm_cbe_613_count = 0;
  static  unsigned long long aesl_llvm_cbe_614_count = 0;
  static  unsigned long long aesl_llvm_cbe_615_count = 0;
  static  unsigned long long aesl_llvm_cbe_616_count = 0;
  static  unsigned long long aesl_llvm_cbe_617_count = 0;
  static  unsigned long long aesl_llvm_cbe_618_count = 0;
  unsigned int llvm_cbe_tmp__120;
  static  unsigned long long aesl_llvm_cbe_619_count = 0;
  unsigned int llvm_cbe_tmp__121;
  static  unsigned long long aesl_llvm_cbe_620_count = 0;
  unsigned long long llvm_cbe_tmp__122;
  static  unsigned long long aesl_llvm_cbe_621_count = 0;
  signed int *llvm_cbe_tmp__123;
  static  unsigned long long aesl_llvm_cbe_622_count = 0;
  static  unsigned long long aesl_llvm_cbe_623_count = 0;
  unsigned int llvm_cbe_tmp__124;
  static  unsigned long long aesl_llvm_cbe_624_count = 0;
  static  unsigned long long aesl_llvm_cbe_625_count = 0;
  static  unsigned long long aesl_llvm_cbe_626_count = 0;
  static  unsigned long long aesl_llvm_cbe_627_count = 0;
  static  unsigned long long aesl_llvm_cbe_628_count = 0;
  static  unsigned long long aesl_llvm_cbe_629_count = 0;
  static  unsigned long long aesl_llvm_cbe_630_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge34_2e_2_count = 0;
  unsigned int llvm_cbe_storemerge34_2e_2;
  unsigned int llvm_cbe_storemerge34_2e_2__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_631_count = 0;
  static  unsigned long long aesl_llvm_cbe_632_count = 0;
  static  unsigned long long aesl_llvm_cbe_633_count = 0;
  static  unsigned long long aesl_llvm_cbe_634_count = 0;
  static  unsigned long long aesl_llvm_cbe_635_count = 0;
  static  unsigned long long aesl_llvm_cbe_636_count = 0;
  static  unsigned long long aesl_llvm_cbe_637_count = 0;
  static  unsigned long long aesl_llvm_cbe_638_count = 0;
  unsigned int llvm_cbe_tmp__125;
  static  unsigned long long aesl_llvm_cbe_639_count = 0;
  unsigned long long llvm_cbe_tmp__126;
  static  unsigned long long aesl_llvm_cbe_640_count = 0;
  signed int *llvm_cbe_tmp__127;
  static  unsigned long long aesl_llvm_cbe_641_count = 0;
  static  unsigned long long aesl_llvm_cbe_642_count = 0;
  static  unsigned long long aesl_llvm_cbe_643_count = 0;
  static  unsigned long long aesl_llvm_cbe_644_count = 0;
  static  unsigned long long aesl_llvm_cbe_645_count = 0;
  static  unsigned long long aesl_llvm_cbe_646_count = 0;
  static  unsigned long long aesl_llvm_cbe_647_count = 0;
  static  unsigned long long aesl_llvm_cbe_648_count = 0;
  unsigned int llvm_cbe_tmp__128;
  static  unsigned long long aesl_llvm_cbe_649_count = 0;
  unsigned int llvm_cbe_tmp__129;
  static  unsigned long long aesl_llvm_cbe_650_count = 0;
  unsigned long long llvm_cbe_tmp__130;
  static  unsigned long long aesl_llvm_cbe_651_count = 0;
  signed int *llvm_cbe_tmp__131;
  static  unsigned long long aesl_llvm_cbe_652_count = 0;
  static  unsigned long long aesl_llvm_cbe_653_count = 0;
  unsigned int llvm_cbe_tmp__132;
  static  unsigned long long aesl_llvm_cbe_654_count = 0;
  static  unsigned long long aesl_llvm_cbe_655_count = 0;
  static  unsigned long long aesl_llvm_cbe_656_count = 0;
  static  unsigned long long aesl_llvm_cbe_657_count = 0;
  static  unsigned long long aesl_llvm_cbe_658_count = 0;
  static  unsigned long long aesl_llvm_cbe_659_count = 0;
  static  unsigned long long aesl_llvm_cbe_660_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge34_2e_3_count = 0;
  unsigned int llvm_cbe_storemerge34_2e_3;
  unsigned int llvm_cbe_storemerge34_2e_3__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_661_count = 0;
  static  unsigned long long aesl_llvm_cbe_662_count = 0;
  static  unsigned long long aesl_llvm_cbe_663_count = 0;
  static  unsigned long long aesl_llvm_cbe_664_count = 0;
  static  unsigned long long aesl_llvm_cbe_665_count = 0;
  static  unsigned long long aesl_llvm_cbe_666_count = 0;
  static  unsigned long long aesl_llvm_cbe_667_count = 0;
  static  unsigned long long aesl_llvm_cbe_668_count = 0;
  unsigned int llvm_cbe_tmp__133;
  static  unsigned long long aesl_llvm_cbe_669_count = 0;
  unsigned long long llvm_cbe_tmp__134;
  static  unsigned long long aesl_llvm_cbe_670_count = 0;
  signed int *llvm_cbe_tmp__135;
  static  unsigned long long aesl_llvm_cbe_671_count = 0;
  static  unsigned long long aesl_llvm_cbe_672_count = 0;
  static  unsigned long long aesl_llvm_cbe_673_count = 0;
  static  unsigned long long aesl_llvm_cbe_674_count = 0;
  static  unsigned long long aesl_llvm_cbe_675_count = 0;
  static  unsigned long long aesl_llvm_cbe_676_count = 0;
  static  unsigned long long aesl_llvm_cbe_677_count = 0;
  static  unsigned long long aesl_llvm_cbe_678_count = 0;
  unsigned int llvm_cbe_tmp__136;
  static  unsigned long long aesl_llvm_cbe_679_count = 0;
  unsigned int llvm_cbe_tmp__137;
  static  unsigned long long aesl_llvm_cbe_680_count = 0;
  unsigned long long llvm_cbe_tmp__138;
  static  unsigned long long aesl_llvm_cbe_681_count = 0;
  signed int *llvm_cbe_tmp__139;
  static  unsigned long long aesl_llvm_cbe_682_count = 0;
  static  unsigned long long aesl_llvm_cbe_683_count = 0;
  unsigned int llvm_cbe_tmp__140;
  static  unsigned long long aesl_llvm_cbe_684_count = 0;
  static  unsigned long long aesl_llvm_cbe_685_count = 0;
  static  unsigned long long aesl_llvm_cbe_686_count = 0;
  static  unsigned long long aesl_llvm_cbe_687_count = 0;
  static  unsigned long long aesl_llvm_cbe_688_count = 0;
  static  unsigned long long aesl_llvm_cbe_689_count = 0;
  static  unsigned long long aesl_llvm_cbe_690_count = 0;
  static  unsigned long long aesl_llvm_cbe_691_count = 0;
  static  unsigned long long aesl_llvm_cbe_692_count = 0;
  static  unsigned long long aesl_llvm_cbe_693_count = 0;
  static  unsigned long long aesl_llvm_cbe_694_count = 0;
  static  unsigned long long aesl_llvm_cbe_695_count = 0;
  static  unsigned long long aesl_llvm_cbe_696_count = 0;
  static  unsigned long long aesl_llvm_cbe_697_count = 0;
  static  unsigned long long aesl_llvm_cbe_698_count = 0;
  static  unsigned long long aesl_llvm_cbe_699_count = 0;
  static  unsigned long long aesl_llvm_cbe_700_count = 0;
  static  unsigned long long aesl_llvm_cbe_701_count = 0;
  static  unsigned long long aesl_llvm_cbe_702_count = 0;
  static  unsigned long long aesl_llvm_cbe_703_count = 0;
  static  unsigned long long aesl_llvm_cbe_704_count = 0;
  static  unsigned long long aesl_llvm_cbe_705_count = 0;
  static  unsigned long long aesl_llvm_cbe_706_count = 0;
  static  unsigned long long aesl_llvm_cbe_707_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @blowfish_init\n");
if (AESL_DEBUG_TRACE)
printf("\n  store i32 0, i32* %%left, align 4, !dbg !8 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_162_count);
  *(&llvm_cbe_left) = 0u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", 0u);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 0, i32* %%right, align 4, !dbg !8 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_170_count);
  *(&llvm_cbe_right) = 0u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", 0u);
  llvm_cbe_storemerge9__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
  goto llvm_cbe_tmp__141;

llvm_cbe__2e_preheader7:
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_203_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%1 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_210_count);
  llvm_cbe_tmp__58 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__58);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%1, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 0), align 16, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_211_count);
  *((&pbox[(((signed long long )0ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__58;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__58);
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_218_count);
  llvm_cbe_tmp__59 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__59);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%2, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 1), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_219_count);
  *((&pbox[(((signed long long )1ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__59;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__59);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_236_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%3 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_243_count);
  llvm_cbe_tmp__60 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__60);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%3, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 2), align 8, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_244_count);
  *((&pbox[(((signed long long )2ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__60;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__60);
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_251_count);
  llvm_cbe_tmp__61 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__61);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%4, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 3), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_252_count);
  *((&pbox[(((signed long long )3ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__61;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__61);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_269_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_276_count);
  llvm_cbe_tmp__62 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__62);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%5, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 4), align 16, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_277_count);
  *((&pbox[(((signed long long )4ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__62;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__62);
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_284_count);
  llvm_cbe_tmp__63 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__63);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%6, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 5), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_285_count);
  *((&pbox[(((signed long long )5ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__63;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__63);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_302_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_309_count);
  llvm_cbe_tmp__64 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__64);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%7, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 6), align 8, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_310_count);
  *((&pbox[(((signed long long )6ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__64;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__64);
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_317_count);
  llvm_cbe_tmp__65 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__65);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%8, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 7), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_318_count);
  *((&pbox[(((signed long long )7ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__65;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__65);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_335_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_342_count);
  llvm_cbe_tmp__66 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__66);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 8), align 16, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_343_count);
  *((&pbox[(((signed long long )8ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__66;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__66);
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_350_count);
  llvm_cbe_tmp__67 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__67);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%10, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 9), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_351_count);
  *((&pbox[(((signed long long )9ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__67;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__67);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_368_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_375_count);
  llvm_cbe_tmp__68 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__68);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%11, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 10), align 8, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_376_count);
  *((&pbox[(((signed long long )10ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__68;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__68);
if (AESL_DEBUG_TRACE)
printf("\n  %%12 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_383_count);
  llvm_cbe_tmp__69 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__69);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%12, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 11), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_384_count);
  *((&pbox[(((signed long long )11ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__69;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__69);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_401_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%13 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_408_count);
  llvm_cbe_tmp__70 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__70);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%13, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 12), align 16, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_409_count);
  *((&pbox[(((signed long long )12ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__70;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__70);
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_416_count);
  llvm_cbe_tmp__71 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__71);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%14, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 13), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_417_count);
  *((&pbox[(((signed long long )13ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__71;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__71);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_434_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_441_count);
  llvm_cbe_tmp__72 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__72);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%15, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 14), align 8, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_442_count);
  *((&pbox[(((signed long long )14ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__72;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__72);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_449_count);
  llvm_cbe_tmp__73 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__73);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%16, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 15), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_450_count);
  *((&pbox[(((signed long long )15ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__73;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__73);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_467_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = load i32* %%left, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_474_count);
  llvm_cbe_tmp__74 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__74);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%17, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 16), align 16, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_475_count);
  *((&pbox[(((signed long long )16ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__74;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__74);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = load i32* %%right, align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_482_count);
  llvm_cbe_tmp__75 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__75);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%18, i32* getelementptr inbounds ([18 x i32]* @pbox, i64 0, i64 17), align 4, !dbg !9 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_483_count);
  *((&pbox[(((signed long long )17ull))
#ifdef AESL_BC_SIM
 % 18
#endif
])) = llvm_cbe_tmp__75;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__75);
  llvm_cbe_storemerge34__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
  goto llvm_cbe_tmp__142;

  do {     /* Syntactic loop '' to make GCC happy */
llvm_cbe_tmp__141:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge9 = phi i32 [ 0, %%0 ], [ %%26, %%19  for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_storemerge9_count);
  llvm_cbe_storemerge9 = (unsigned int )llvm_cbe_storemerge9__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge9 = 0x%X",llvm_cbe_storemerge9);
printf("\n = 0x%X",0u);
printf("\n = 0x%X",llvm_cbe_tmp__82);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%20 = srem i32 %%storemerge9, %%size, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_520_count);
  llvm_cbe_tmp__76 = (unsigned int )((signed int )(((signed int )llvm_cbe_storemerge9) % ((signed int )llvm_cbe_size)));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((signed int )llvm_cbe_tmp__76));
if (AESL_DEBUG_TRACE)
printf("\n  %%21 = sext i32 %%20 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_521_count);
  llvm_cbe_tmp__77 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__76);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__77);
if (AESL_DEBUG_TRACE)
printf("\n  %%22 = getelementptr inbounds i8* %%key, i64 %%21, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_522_count);
  llvm_cbe_tmp__78 = ( char *)(&llvm_cbe_key[(((signed long long )llvm_cbe_tmp__77))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__77));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%23 = load i8* %%22, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_523_count);
  llvm_cbe_tmp__79 = (unsigned char )*llvm_cbe_tmp__78;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__79);
if (AESL_DEBUG_TRACE)
printf("\n  %%24 = zext i8 %%23 to i32, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_524_count);
  llvm_cbe_tmp__80 = (unsigned int )((unsigned int )(unsigned char )llvm_cbe_tmp__79&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__80);
if (AESL_DEBUG_TRACE)
printf("\n  %%25 = shl nuw i32 %%24, 24, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_525_count);
  llvm_cbe_tmp__81 = (unsigned int )llvm_cbe_tmp__80 << 24u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__81);
if (AESL_DEBUG_TRACE)
printf("\n  %%26 = add nsw i32 %%storemerge9, 1, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_526_count);
  llvm_cbe_tmp__82 = (unsigned int )((unsigned int )(llvm_cbe_storemerge9&4294967295ull)) + ((unsigned int )(1u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__82&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%27 = srem i32 %%26, %%size, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_527_count);
  llvm_cbe_tmp__83 = (unsigned int )((signed int )(((signed int )llvm_cbe_tmp__82) % ((signed int )llvm_cbe_size)));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((signed int )llvm_cbe_tmp__83));
if (AESL_DEBUG_TRACE)
printf("\n  %%28 = sext i32 %%27 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_528_count);
  llvm_cbe_tmp__84 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__83);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__84);
if (AESL_DEBUG_TRACE)
printf("\n  %%29 = getelementptr inbounds i8* %%key, i64 %%28, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_529_count);
  llvm_cbe_tmp__85 = ( char *)(&llvm_cbe_key[(((signed long long )llvm_cbe_tmp__84))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__84));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%30 = load i8* %%29, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_530_count);
  llvm_cbe_tmp__86 = (unsigned char )*llvm_cbe_tmp__85;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__86);
if (AESL_DEBUG_TRACE)
printf("\n  %%31 = zext i8 %%30 to i32, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_531_count);
  llvm_cbe_tmp__87 = (unsigned int )((unsigned int )(unsigned char )llvm_cbe_tmp__86&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__87);
if (AESL_DEBUG_TRACE)
printf("\n  %%32 = shl nuw nsw i32 %%31, 16, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_532_count);
  llvm_cbe_tmp__88 = (unsigned int )llvm_cbe_tmp__87 << 16u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__88);
if (AESL_DEBUG_TRACE)
printf("\n  %%33 = add nsw i32 %%storemerge9, 2, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_533_count);
  llvm_cbe_tmp__89 = (unsigned int )((unsigned int )(llvm_cbe_storemerge9&4294967295ull)) + ((unsigned int )(2u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__89&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%34 = srem i32 %%33, %%size, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_534_count);
  llvm_cbe_tmp__90 = (unsigned int )((signed int )(((signed int )llvm_cbe_tmp__89) % ((signed int )llvm_cbe_size)));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((signed int )llvm_cbe_tmp__90));
if (AESL_DEBUG_TRACE)
printf("\n  %%35 = sext i32 %%34 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_535_count);
  llvm_cbe_tmp__91 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__90);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__91);
if (AESL_DEBUG_TRACE)
printf("\n  %%36 = getelementptr inbounds i8* %%key, i64 %%35, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_536_count);
  llvm_cbe_tmp__92 = ( char *)(&llvm_cbe_key[(((signed long long )llvm_cbe_tmp__91))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__91));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%37 = load i8* %%36, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_537_count);
  llvm_cbe_tmp__93 = (unsigned char )*llvm_cbe_tmp__92;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__93);
if (AESL_DEBUG_TRACE)
printf("\n  %%38 = zext i8 %%37 to i32, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_538_count);
  llvm_cbe_tmp__94 = (unsigned int )((unsigned int )(unsigned char )llvm_cbe_tmp__93&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__94);
if (AESL_DEBUG_TRACE)
printf("\n  %%39 = shl nuw nsw i32 %%38, 8, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_539_count);
  llvm_cbe_tmp__95 = (unsigned int )llvm_cbe_tmp__94 << 8u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__95);
if (AESL_DEBUG_TRACE)
printf("\n  %%40 = add nsw i32 %%storemerge9, 3, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_540_count);
  llvm_cbe_tmp__96 = (unsigned int )((unsigned int )(llvm_cbe_storemerge9&4294967295ull)) + ((unsigned int )(3u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__96&4294967295ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%41 = srem i32 %%40, %%size, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_541_count);
  llvm_cbe_tmp__97 = (unsigned int )((signed int )(((signed int )llvm_cbe_tmp__96) % ((signed int )llvm_cbe_size)));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((signed int )llvm_cbe_tmp__97));
if (AESL_DEBUG_TRACE)
printf("\n  %%42 = sext i32 %%41 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_542_count);
  llvm_cbe_tmp__98 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__97);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__98);
if (AESL_DEBUG_TRACE)
printf("\n  %%43 = getelementptr inbounds i8* %%key, i64 %%42, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_543_count);
  llvm_cbe_tmp__99 = ( char *)(&llvm_cbe_key[(((signed long long )llvm_cbe_tmp__98))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__98));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%44 = load i8* %%43, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_544_count);
  llvm_cbe_tmp__100 = (unsigned char )*llvm_cbe_tmp__99;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__100);
if (AESL_DEBUG_TRACE)
printf("\n  %%45 = zext i8 %%44 to i32, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_545_count);
  llvm_cbe_tmp__101 = (unsigned int )((unsigned int )(unsigned char )llvm_cbe_tmp__100&255U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__101);
if (AESL_DEBUG_TRACE)
printf("\n  %%46 = or i32 %%32, %%25, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_546_count);
  llvm_cbe_tmp__102 = (unsigned int )llvm_cbe_tmp__88 | llvm_cbe_tmp__81;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__102);
if (AESL_DEBUG_TRACE)
printf("\n  %%47 = or i32 %%46, %%39, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_547_count);
  llvm_cbe_tmp__103 = (unsigned int )llvm_cbe_tmp__102 | llvm_cbe_tmp__95;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__103);
if (AESL_DEBUG_TRACE)
printf("\n  %%48 = or i32 %%47, %%45, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_548_count);
  llvm_cbe_tmp__104 = (unsigned int )llvm_cbe_tmp__103 | llvm_cbe_tmp__101;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__104);
if (AESL_DEBUG_TRACE)
printf("\n  %%49 = sext i32 %%storemerge9 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_549_count);
  llvm_cbe_tmp__105 = (unsigned long long )((signed long long )(signed int )llvm_cbe_storemerge9);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__105);
if (AESL_DEBUG_TRACE)
printf("\n  %%50 = getelementptr inbounds [18 x i32]* @pbox, i64 0, i64 %%49, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_550_count);
  llvm_cbe_tmp__106 = (signed int *)(&pbox[(((signed long long )llvm_cbe_tmp__105))
#ifdef AESL_BC_SIM
 % 18
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__105));
}

#ifdef AESL_BC_SIM
  if (!(((signed long long )llvm_cbe_tmp__105) < 18)) fprintf(stderr, "%s:%d: warning: Read access out of array 'pbox' bound?\n", __FILE__, __LINE__);

#endif
if (AESL_DEBUG_TRACE)
printf("\n  %%51 = load i32* %%50, align 4, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_551_count);
  llvm_cbe_tmp__107 = (unsigned int )*llvm_cbe_tmp__106;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__107);
if (AESL_DEBUG_TRACE)
printf("\n  %%52 = xor i32 %%48, %%51, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_552_count);
  llvm_cbe_tmp__108 = (unsigned int )llvm_cbe_tmp__104 ^ llvm_cbe_tmp__107;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__108);

#ifdef AESL_BC_SIM
  assert(((signed long long )llvm_cbe_tmp__105) < 18 && "Write access out of array 'pbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%52, i32* %%50, align 4, !dbg !7 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_553_count);
  *llvm_cbe_tmp__106 = llvm_cbe_tmp__108;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__108);
  if (((llvm_cbe_tmp__82&4294967295U) == (18u&4294967295U))) {
    goto llvm_cbe__2e_preheader7;
  } else {
    llvm_cbe_storemerge9__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__82;   /* for PHI node */
    goto llvm_cbe_tmp__141;
  }

  } while (1); /* end of syntactic loop '' */
  do {     /* Syntactic loop '' to make GCC happy */
llvm_cbe_tmp__142:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge34 = phi i32 [ 0, %%.preheader7 ], [ %%61, %%53  for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_storemerge34_count);
  llvm_cbe_storemerge34 = (unsigned int )llvm_cbe_storemerge34__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge34 = 0x%X",llvm_cbe_storemerge34);
printf("\n = 0x%X",0u);
printf("\n = 0x%X",llvm_cbe_tmp__116);
}
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_571_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%54 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_578_count);
  llvm_cbe_tmp__109 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__109);
if (AESL_DEBUG_TRACE)
printf("\n  %%55 = sext i32 %%storemerge34 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_579_count);
  llvm_cbe_tmp__110 = (unsigned long long )((signed long long )(signed int )llvm_cbe_storemerge34);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__110);
if (AESL_DEBUG_TRACE)
printf("\n  %%56 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 0, i64 %%55, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_580_count);
  llvm_cbe_tmp__111 = (signed int *)(&sbox[(((signed long long )0ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__110))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__110));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )0ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__110) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%54, i32* %%56, align 8, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_581_count);
  *llvm_cbe_tmp__111 = llvm_cbe_tmp__109;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__109);
if (AESL_DEBUG_TRACE)
printf("\n  %%57 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_588_count);
  llvm_cbe_tmp__112 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__112);
if (AESL_DEBUG_TRACE)
printf("\n  %%58 = or i32 %%storemerge34, 1, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_589_count);
  llvm_cbe_tmp__113 = (unsigned int )llvm_cbe_storemerge34 | 1u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__113);
if (AESL_DEBUG_TRACE)
printf("\n  %%59 = sext i32 %%58 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_590_count);
  llvm_cbe_tmp__114 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__113);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__114);
if (AESL_DEBUG_TRACE)
printf("\n  %%60 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 0, i64 %%59, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_591_count);
  llvm_cbe_tmp__115 = (signed int *)(&sbox[(((signed long long )0ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__114))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__114));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )0ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__114) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%57, i32* %%60, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_592_count);
  *llvm_cbe_tmp__115 = llvm_cbe_tmp__112;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__112);
if (AESL_DEBUG_TRACE)
printf("\n  %%61 = add nsw i32 %%storemerge34, 2, !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_593_count);
  llvm_cbe_tmp__116 = (unsigned int )((unsigned int )(llvm_cbe_storemerge34&4294967295ull)) + ((unsigned int )(2u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__116&4294967295ull)));
  if ((((signed int )llvm_cbe_tmp__116) < ((signed int )255u))) {
    llvm_cbe_storemerge34__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__116;   /* for PHI node */
    goto llvm_cbe_tmp__142;
  } else {
    llvm_cbe_storemerge34_2e_1__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_1;
  }

  } while (1); /* end of syntactic loop '' */
  do {     /* Syntactic loop '.preheader.1' to make GCC happy */
llvm_cbe__2e_preheader_2e_1:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge34.1 = phi i32 [ %%70, %%.preheader.1 ], [ 0, %%53  for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_storemerge34_2e_1_count);
  llvm_cbe_storemerge34_2e_1 = (unsigned int )llvm_cbe_storemerge34_2e_1__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge34.1 = 0x%X",llvm_cbe_storemerge34_2e_1);
printf("\n = 0x%X",llvm_cbe_tmp__124);
printf("\n = 0x%X",0u);
}
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_601_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%63 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_608_count);
  llvm_cbe_tmp__117 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__117);
if (AESL_DEBUG_TRACE)
printf("\n  %%64 = sext i32 %%storemerge34.1 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_609_count);
  llvm_cbe_tmp__118 = (unsigned long long )((signed long long )(signed int )llvm_cbe_storemerge34_2e_1);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__118);
if (AESL_DEBUG_TRACE)
printf("\n  %%65 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 1, i64 %%64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_610_count);
  llvm_cbe_tmp__119 = (signed int *)(&sbox[(((signed long long )1ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__118))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__118));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )1ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__118) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%63, i32* %%65, align 8, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_611_count);
  *llvm_cbe_tmp__119 = llvm_cbe_tmp__117;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__117);
if (AESL_DEBUG_TRACE)
printf("\n  %%66 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_618_count);
  llvm_cbe_tmp__120 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__120);
if (AESL_DEBUG_TRACE)
printf("\n  %%67 = or i32 %%storemerge34.1, 1, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_619_count);
  llvm_cbe_tmp__121 = (unsigned int )llvm_cbe_storemerge34_2e_1 | 1u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__121);
if (AESL_DEBUG_TRACE)
printf("\n  %%68 = sext i32 %%67 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_620_count);
  llvm_cbe_tmp__122 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__121);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__122);
if (AESL_DEBUG_TRACE)
printf("\n  %%69 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 1, i64 %%68, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_621_count);
  llvm_cbe_tmp__123 = (signed int *)(&sbox[(((signed long long )1ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__122))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__122));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )1ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__122) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%66, i32* %%69, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_622_count);
  *llvm_cbe_tmp__123 = llvm_cbe_tmp__120;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__120);
if (AESL_DEBUG_TRACE)
printf("\n  %%70 = add nsw i32 %%storemerge34.1, 2, !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_623_count);
  llvm_cbe_tmp__124 = (unsigned int )((unsigned int )(llvm_cbe_storemerge34_2e_1&4294967295ull)) + ((unsigned int )(2u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__124&4294967295ull)));
  if ((((signed int )llvm_cbe_tmp__124) < ((signed int )255u))) {
    llvm_cbe_storemerge34_2e_1__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__124;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_1;
  } else {
    llvm_cbe_storemerge34_2e_2__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_2;
  }

  } while (1); /* end of syntactic loop '.preheader.1' */
  do {     /* Syntactic loop '.preheader.2' to make GCC happy */
llvm_cbe__2e_preheader_2e_2:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge34.2 = phi i32 [ %%79, %%.preheader.2 ], [ 0, %%.preheader.1  for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_storemerge34_2e_2_count);
  llvm_cbe_storemerge34_2e_2 = (unsigned int )llvm_cbe_storemerge34_2e_2__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge34.2 = 0x%X",llvm_cbe_storemerge34_2e_2);
printf("\n = 0x%X",llvm_cbe_tmp__132);
printf("\n = 0x%X",0u);
}
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_631_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%72 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_638_count);
  llvm_cbe_tmp__125 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__125);
if (AESL_DEBUG_TRACE)
printf("\n  %%73 = sext i32 %%storemerge34.2 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_639_count);
  llvm_cbe_tmp__126 = (unsigned long long )((signed long long )(signed int )llvm_cbe_storemerge34_2e_2);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__126);
if (AESL_DEBUG_TRACE)
printf("\n  %%74 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 2, i64 %%73, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_640_count);
  llvm_cbe_tmp__127 = (signed int *)(&sbox[(((signed long long )2ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__126))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__126));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )2ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__126) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%72, i32* %%74, align 8, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_641_count);
  *llvm_cbe_tmp__127 = llvm_cbe_tmp__125;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__125);
if (AESL_DEBUG_TRACE)
printf("\n  %%75 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_648_count);
  llvm_cbe_tmp__128 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__128);
if (AESL_DEBUG_TRACE)
printf("\n  %%76 = or i32 %%storemerge34.2, 1, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_649_count);
  llvm_cbe_tmp__129 = (unsigned int )llvm_cbe_storemerge34_2e_2 | 1u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__129);
if (AESL_DEBUG_TRACE)
printf("\n  %%77 = sext i32 %%76 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_650_count);
  llvm_cbe_tmp__130 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__129);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__130);
if (AESL_DEBUG_TRACE)
printf("\n  %%78 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 2, i64 %%77, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_651_count);
  llvm_cbe_tmp__131 = (signed int *)(&sbox[(((signed long long )2ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__130))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__130));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )2ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__130) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%75, i32* %%78, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_652_count);
  *llvm_cbe_tmp__131 = llvm_cbe_tmp__128;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__128);
if (AESL_DEBUG_TRACE)
printf("\n  %%79 = add nsw i32 %%storemerge34.2, 2, !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_653_count);
  llvm_cbe_tmp__132 = (unsigned int )((unsigned int )(llvm_cbe_storemerge34_2e_2&4294967295ull)) + ((unsigned int )(2u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__132&4294967295ull)));
  if ((((signed int )llvm_cbe_tmp__132) < ((signed int )255u))) {
    llvm_cbe_storemerge34_2e_2__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__132;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_2;
  } else {
    llvm_cbe_storemerge34_2e_3__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_3;
  }

  } while (1); /* end of syntactic loop '.preheader.2' */
  do {     /* Syntactic loop '.preheader.3' to make GCC happy */
llvm_cbe__2e_preheader_2e_3:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge34.3 = phi i32 [ %%88, %%.preheader.3 ], [ 0, %%.preheader.2  for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_storemerge34_2e_3_count);
  llvm_cbe_storemerge34_2e_3 = (unsigned int )llvm_cbe_storemerge34_2e_3__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge34.3 = 0x%X",llvm_cbe_storemerge34_2e_3);
printf("\n = 0x%X",llvm_cbe_tmp__140);
printf("\n = 0x%X",0u);
}
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_661_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%81 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_668_count);
  llvm_cbe_tmp__133 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__133);
if (AESL_DEBUG_TRACE)
printf("\n  %%82 = sext i32 %%storemerge34.3 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_669_count);
  llvm_cbe_tmp__134 = (unsigned long long )((signed long long )(signed int )llvm_cbe_storemerge34_2e_3);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__134);
if (AESL_DEBUG_TRACE)
printf("\n  %%83 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 3, i64 %%82, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_670_count);
  llvm_cbe_tmp__135 = (signed int *)(&sbox[(((signed long long )3ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__134))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__134));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )3ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__134) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%81, i32* %%83, align 8, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_671_count);
  *llvm_cbe_tmp__135 = llvm_cbe_tmp__133;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__133);
if (AESL_DEBUG_TRACE)
printf("\n  %%84 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_678_count);
  llvm_cbe_tmp__136 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__136);
if (AESL_DEBUG_TRACE)
printf("\n  %%85 = or i32 %%storemerge34.3, 1, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_679_count);
  llvm_cbe_tmp__137 = (unsigned int )llvm_cbe_storemerge34_2e_3 | 1u;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__137);
if (AESL_DEBUG_TRACE)
printf("\n  %%86 = sext i32 %%85 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_680_count);
  llvm_cbe_tmp__138 = (unsigned long long )((signed long long )(signed int )llvm_cbe_tmp__137);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__138);
if (AESL_DEBUG_TRACE)
printf("\n  %%87 = getelementptr inbounds [4 x [256 x i32]]* @sbox, i64 0, i64 3, i64 %%86, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_681_count);
  llvm_cbe_tmp__139 = (signed int *)(&sbox[(((signed long long )3ull))
#ifdef AESL_BC_SIM
 % 4
#endif
][(((signed long long )llvm_cbe_tmp__138))
#ifdef AESL_BC_SIM
 % 256
#endif
]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__138));
}

#ifdef AESL_BC_SIM
  assert(((signed long long )3ull) < 4 && "Write access out of array 'sbox' bound?");
  assert(((signed long long )llvm_cbe_tmp__138) < 256 && "Write access out of array 'sbox' bound?");

#endif
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%84, i32* %%87, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_682_count);
  *llvm_cbe_tmp__139 = llvm_cbe_tmp__136;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__136);
if (AESL_DEBUG_TRACE)
printf("\n  %%88 = add nsw i32 %%storemerge34.3, 2, !dbg !11 for 0x%I64xth hint within @blowfish_init  --> \n", ++aesl_llvm_cbe_683_count);
  llvm_cbe_tmp__140 = (unsigned int )((unsigned int )(llvm_cbe_storemerge34_2e_3&4294967295ull)) + ((unsigned int )(2u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__140&4294967295ull)));
  if ((((signed int )llvm_cbe_tmp__140) < ((signed int )255u))) {
    llvm_cbe_storemerge34_2e_3__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__140;   /* for PHI node */
    goto llvm_cbe__2e_preheader_2e_3;
  } else {
    goto llvm_cbe_tmp__143;
  }

  } while (1); /* end of syntactic loop '.preheader.3' */
llvm_cbe_tmp__143:
  if (AESL_DEBUG_TRACE)
      printf("\nEND @blowfish_init}\n");
  return;
}


 char *blowfish_encrypt( char *llvm_cbe_data, signed int llvm_cbe_padsize) {
  static  unsigned long long aesl_llvm_cbe_left_count = 0;
  signed int llvm_cbe_left;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_right_count = 0;
  signed int llvm_cbe_right;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_708_count = 0;
  static  unsigned long long aesl_llvm_cbe_709_count = 0;
  static  unsigned long long aesl_llvm_cbe_710_count = 0;
  static  unsigned long long aesl_llvm_cbe_711_count = 0;
  static  unsigned long long aesl_llvm_cbe_712_count = 0;
  static  unsigned long long aesl_llvm_cbe_713_count = 0;
  unsigned long long llvm_cbe_tmp__144;
  static  unsigned long long aesl_llvm_cbe_714_count = 0;
   char *llvm_cbe_tmp__145;
  static  unsigned long long aesl_llvm_cbe_715_count = 0;
  static  unsigned long long aesl_llvm_cbe_716_count = 0;
  static  unsigned long long aesl_llvm_cbe_717_count = 0;
  static  unsigned long long aesl_llvm_cbe_718_count = 0;
  static  unsigned long long aesl_llvm_cbe_719_count = 0;
  static  unsigned long long aesl_llvm_cbe_720_count = 0;
  static  unsigned long long aesl_llvm_cbe_721_count = 0;
  static  unsigned long long aesl_llvm_cbe_722_count = 0;
  static  unsigned long long aesl_llvm_cbe_723_count = 0;
  static  unsigned long long aesl_llvm_cbe_724_count = 0;
  static  unsigned long long aesl_llvm_cbe_725_count = 0;
  static  unsigned long long aesl_llvm_cbe_726_count = 0;
  static  unsigned long long aesl_llvm_cbe_727_count = 0;
  static  unsigned long long aesl_llvm_cbe_728_count = 0;
  static  unsigned long long aesl_llvm_cbe_729_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge2_count = 0;
  unsigned int llvm_cbe_storemerge2;
  unsigned int llvm_cbe_storemerge2__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_730_count = 0;
  static  unsigned long long aesl_llvm_cbe_731_count = 0;
  static  unsigned long long aesl_llvm_cbe_732_count = 0;
  unsigned long long llvm_cbe_tmp__146;
  static  unsigned long long aesl_llvm_cbe_733_count = 0;
   char *llvm_cbe_tmp__147;
  static  unsigned long long aesl_llvm_cbe_734_count = 0;
  signed long long *llvm_cbe_tmp__148;
  static  unsigned long long aesl_llvm_cbe_srcval1_count = 0;
  unsigned long long llvm_cbe_srcval1;
  static  unsigned long long aesl_llvm_cbe_735_count = 0;
  static  unsigned long long aesl_llvm_cbe_736_count = 0;
  static  unsigned long long aesl_llvm_cbe_737_count = 0;
  static  unsigned long long aesl_llvm_cbe_738_count = 0;
  static  unsigned long long aesl_llvm_cbe_739_count = 0;
  static  unsigned long long aesl_llvm_cbe_740_count = 0;
  static  unsigned long long aesl_llvm_cbe_741_count = 0;
  unsigned long long llvm_cbe_tmp__149;
  static  unsigned long long aesl_llvm_cbe_742_count = 0;
  unsigned int llvm_cbe_tmp__150;
  static  unsigned long long aesl_llvm_cbe_743_count = 0;
  static  unsigned long long aesl_llvm_cbe_744_count = 0;
  static  unsigned long long aesl_llvm_cbe_745_count = 0;
  static  unsigned long long aesl_llvm_cbe_746_count = 0;
  static  unsigned long long aesl_llvm_cbe_747_count = 0;
  static  unsigned long long aesl_llvm_cbe_748_count = 0;
  static  unsigned long long aesl_llvm_cbe_749_count = 0;
  static  unsigned long long aesl_llvm_cbe_750_count = 0;
  unsigned int llvm_cbe_tmp__151;
  static  unsigned long long aesl_llvm_cbe_751_count = 0;
  static  unsigned long long aesl_llvm_cbe_752_count = 0;
  static  unsigned long long aesl_llvm_cbe_753_count = 0;
  static  unsigned long long aesl_llvm_cbe_754_count = 0;
  static  unsigned long long aesl_llvm_cbe_755_count = 0;
  static  unsigned long long aesl_llvm_cbe_756_count = 0;
  static  unsigned long long aesl_llvm_cbe_757_count = 0;
  static  unsigned long long aesl_llvm_cbe_758_count = 0;
  static  unsigned long long aesl_llvm_cbe_759_count = 0;
  static  unsigned long long aesl_llvm_cbe_760_count = 0;
  static  unsigned long long aesl_llvm_cbe_761_count = 0;
  static  unsigned long long aesl_llvm_cbe_762_count = 0;
  static  unsigned long long aesl_llvm_cbe_763_count = 0;
  static  unsigned long long aesl_llvm_cbe_764_count = 0;
  static  unsigned long long aesl_llvm_cbe_765_count = 0;
  static  unsigned long long aesl_llvm_cbe_766_count = 0;
  static  unsigned long long aesl_llvm_cbe_767_count = 0;
  unsigned int llvm_cbe_tmp__152;
  static  unsigned long long aesl_llvm_cbe_768_count = 0;
  unsigned long long llvm_cbe_tmp__153;
  static  unsigned long long aesl_llvm_cbe_769_count = 0;
  static  unsigned long long aesl_llvm_cbe_770_count = 0;
  unsigned long long llvm_cbe_tmp__154;
  static  unsigned long long aesl_llvm_cbe_771_count = 0;
  static  unsigned long long aesl_llvm_cbe_772_count = 0;
  static  unsigned long long aesl_llvm_cbe_773_count = 0;
  static  unsigned long long aesl_llvm_cbe_774_count = 0;
  static  unsigned long long aesl_llvm_cbe_775_count = 0;
  static  unsigned long long aesl_llvm_cbe_776_count = 0;
  static  unsigned long long aesl_llvm_cbe_777_count = 0;
  static  unsigned long long aesl_llvm_cbe_778_count = 0;
  static  unsigned long long aesl_llvm_cbe_779_count = 0;
  unsigned int llvm_cbe_tmp__155;
  static  unsigned long long aesl_llvm_cbe_780_count = 0;
  unsigned long long llvm_cbe_tmp__156;
  static  unsigned long long aesl_llvm_cbe_781_count = 0;
  unsigned long long llvm_cbe_tmp__157;
  static  unsigned long long aesl_llvm_cbe_782_count = 0;
  static  unsigned long long aesl_llvm_cbe_783_count = 0;
  static  unsigned long long aesl_llvm_cbe_784_count = 0;
   char *llvm_cbe_tmp__158;
  static  unsigned long long aesl_llvm_cbe_785_count = 0;
  signed long long *llvm_cbe_tmp__159;
  static  unsigned long long aesl_llvm_cbe_786_count = 0;
  static  unsigned long long aesl_llvm_cbe_787_count = 0;
  unsigned int llvm_cbe_tmp__160;
  static  unsigned long long aesl_llvm_cbe_788_count = 0;
  static  unsigned long long aesl_llvm_cbe_789_count = 0;
  static  unsigned long long aesl_llvm_cbe_790_count = 0;
  static  unsigned long long aesl_llvm_cbe_791_count = 0;
  static  unsigned long long aesl_llvm_cbe_792_count = 0;
  static  unsigned long long aesl_llvm_cbe_793_count = 0;
  static  unsigned long long aesl_llvm_cbe_794_count = 0;
  static  unsigned long long aesl_llvm_cbe_795_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @blowfish_encrypt\n");
if (AESL_DEBUG_TRACE)
printf("\n  %%1 = sext i32 %%padsize to i64, !dbg !8 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_713_count);
  llvm_cbe_tmp__144 = (unsigned long long )((signed long long )(signed int )llvm_cbe_padsize);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__144);
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = call i8* @malloc(i64 %%1), !dbg !8 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_714_count);
  llvm_cbe_tmp__145 = ( char *)( char *)malloc(llvm_cbe_tmp__144);
if (AESL_DEBUG_TRACE) {
printf("\nArgument  = 0x%I64X",llvm_cbe_tmp__144);
printf("\nReturn  = 0x%X",llvm_cbe_tmp__145);
}
  if (((llvm_cbe_padsize&4294967295U) == (0u&4294967295U))) {
    goto llvm_cbe__2e__crit_edge;
  } else {
    llvm_cbe_storemerge2__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
    goto llvm_cbe__2e_lr_2e_ph;
  }

  do {     /* Syntactic loop '.lr.ph' to make GCC happy */
llvm_cbe__2e_lr_2e_ph:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge2 = phi i32 [ %%18, %%.lr.ph ], [ 0, %%0  for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_storemerge2_count);
  llvm_cbe_storemerge2 = (unsigned int )llvm_cbe_storemerge2__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge2 = 0x%X",llvm_cbe_storemerge2);
printf("\n = 0x%X",llvm_cbe_tmp__160);
printf("\n = 0x%X",0u);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = zext i32 %%storemerge2 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_732_count);
  llvm_cbe_tmp__146 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_storemerge2&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__146);
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = getelementptr inbounds i8* %%data, i64 %%4, !dbg !7 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_733_count);
  llvm_cbe_tmp__147 = ( char *)(&llvm_cbe_data[(((signed long long )llvm_cbe_tmp__146))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__146));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = bitcast i8* %%5 to i64*, !dbg !7 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_734_count);
  llvm_cbe_tmp__148 = (signed long long *)((signed long long *)llvm_cbe_tmp__147);
if (AESL_DEBUG_TRACE)
printf("\n  %%srcval1 = load i64* %%6, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_srcval1_count);
  llvm_cbe_srcval1 = (unsigned long long )*llvm_cbe_tmp__148;
if (AESL_DEBUG_TRACE)
printf("\nsrcval1 = 0x%I64X\n", llvm_cbe_srcval1);
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = lshr i64 %%srcval1, 32, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_741_count);
  llvm_cbe_tmp__149 = (unsigned long long )((unsigned long long )(((unsigned long long )(llvm_cbe_srcval1&18446744073709551615ull)) >> ((unsigned long long )(32ull&18446744073709551615ull))));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", ((unsigned long long )(llvm_cbe_tmp__149&18446744073709551615ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = trunc i64 %%7 to i32, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_742_count);
  llvm_cbe_tmp__150 = (unsigned int )((unsigned int )llvm_cbe_tmp__149&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__150);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%8, i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_749_count);
  *(&llvm_cbe_left) = llvm_cbe_tmp__150;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__150);
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = trunc i64 %%srcval1 to i32, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_750_count);
  llvm_cbe_tmp__151 = (unsigned int )((unsigned int )llvm_cbe_srcval1&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__151);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_757_count);
  *(&llvm_cbe_right) = llvm_cbe_tmp__151;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__151);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_encrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_758_count);
  _encrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_767_count);
  llvm_cbe_tmp__152 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__152);
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = zext i32 %%10 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_768_count);
  llvm_cbe_tmp__153 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_tmp__152&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__153);
if (AESL_DEBUG_TRACE)
printf("\n  %%12 = shl nuw i64 %%11, 32, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_770_count);
  llvm_cbe_tmp__154 = (unsigned long long )llvm_cbe_tmp__153 << 32ull;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__154);
if (AESL_DEBUG_TRACE)
printf("\n  %%13 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_779_count);
  llvm_cbe_tmp__155 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__155);
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = zext i32 %%13 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_780_count);
  llvm_cbe_tmp__156 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_tmp__155&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__156);
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = or i64 %%12, %%14, !dbg !10 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_781_count);
  llvm_cbe_tmp__157 = (unsigned long long )llvm_cbe_tmp__154 | llvm_cbe_tmp__156;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__157);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = getelementptr inbounds i8* %%2, i64 %%4, !dbg !8 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_784_count);
  llvm_cbe_tmp__158 = ( char *)(&llvm_cbe_tmp__145[(((signed long long )llvm_cbe_tmp__146))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__146));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = bitcast i8* %%16 to i64*, !dbg !8 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_785_count);
  llvm_cbe_tmp__159 = (signed long long *)((signed long long *)llvm_cbe_tmp__158);
if (AESL_DEBUG_TRACE)
printf("\n  store i64 %%15, i64* %%17, align 1, !dbg !8 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_786_count);
  *llvm_cbe_tmp__159 = llvm_cbe_tmp__157;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__157);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = add i32 %%storemerge2, 8, !dbg !9 for 0x%I64xth hint within @blowfish_encrypt  --> \n", ++aesl_llvm_cbe_787_count);
  llvm_cbe_tmp__160 = (unsigned int )((unsigned int )(llvm_cbe_storemerge2&4294967295ull)) + ((unsigned int )(8u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__160&4294967295ull)));
  if ((((unsigned int )llvm_cbe_tmp__160&4294967295U) < ((unsigned int )llvm_cbe_padsize&4294967295U))) {
    llvm_cbe_storemerge2__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__160;   /* for PHI node */
    goto llvm_cbe__2e_lr_2e_ph;
  } else {
    goto llvm_cbe__2e__crit_edge;
  }

  } while (1); /* end of syntactic loop '.lr.ph' */
llvm_cbe__2e__crit_edge:
  if (AESL_DEBUG_TRACE)
      printf("\nEND @blowfish_encrypt}\n");
  return llvm_cbe_tmp__145;
}


 char *blowfish_decrypt( char *llvm_cbe_crypt_data, signed int llvm_cbe_padsize) {
  static  unsigned long long aesl_llvm_cbe_left_count = 0;
  signed int llvm_cbe_left;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_right_count = 0;
  signed int llvm_cbe_right;    /* Address-exposed local */
  static  unsigned long long aesl_llvm_cbe_796_count = 0;
  static  unsigned long long aesl_llvm_cbe_797_count = 0;
  static  unsigned long long aesl_llvm_cbe_798_count = 0;
  static  unsigned long long aesl_llvm_cbe_799_count = 0;
  static  unsigned long long aesl_llvm_cbe_800_count = 0;
  static  unsigned long long aesl_llvm_cbe_801_count = 0;
  unsigned long long llvm_cbe_tmp__161;
  static  unsigned long long aesl_llvm_cbe_802_count = 0;
   char *llvm_cbe_tmp__162;
  static  unsigned long long aesl_llvm_cbe_803_count = 0;
  static  unsigned long long aesl_llvm_cbe_804_count = 0;
  static  unsigned long long aesl_llvm_cbe_805_count = 0;
  static  unsigned long long aesl_llvm_cbe_806_count = 0;
  static  unsigned long long aesl_llvm_cbe_807_count = 0;
  static  unsigned long long aesl_llvm_cbe_808_count = 0;
  static  unsigned long long aesl_llvm_cbe_809_count = 0;
  static  unsigned long long aesl_llvm_cbe_810_count = 0;
  static  unsigned long long aesl_llvm_cbe_811_count = 0;
  static  unsigned long long aesl_llvm_cbe_812_count = 0;
  static  unsigned long long aesl_llvm_cbe_813_count = 0;
  static  unsigned long long aesl_llvm_cbe_814_count = 0;
  static  unsigned long long aesl_llvm_cbe_815_count = 0;
  static  unsigned long long aesl_llvm_cbe_816_count = 0;
  static  unsigned long long aesl_llvm_cbe_817_count = 0;
  static  unsigned long long aesl_llvm_cbe_storemerge2_count = 0;
  unsigned int llvm_cbe_storemerge2;
  unsigned int llvm_cbe_storemerge2__PHI_TEMPORARY;
  static  unsigned long long aesl_llvm_cbe_818_count = 0;
  static  unsigned long long aesl_llvm_cbe_819_count = 0;
  static  unsigned long long aesl_llvm_cbe_820_count = 0;
  unsigned long long llvm_cbe_tmp__163;
  static  unsigned long long aesl_llvm_cbe_821_count = 0;
   char *llvm_cbe_tmp__164;
  static  unsigned long long aesl_llvm_cbe_822_count = 0;
  signed long long *llvm_cbe_tmp__165;
  static  unsigned long long aesl_llvm_cbe_srcval1_count = 0;
  unsigned long long llvm_cbe_srcval1;
  static  unsigned long long aesl_llvm_cbe_823_count = 0;
  static  unsigned long long aesl_llvm_cbe_824_count = 0;
  static  unsigned long long aesl_llvm_cbe_825_count = 0;
  static  unsigned long long aesl_llvm_cbe_826_count = 0;
  static  unsigned long long aesl_llvm_cbe_827_count = 0;
  static  unsigned long long aesl_llvm_cbe_828_count = 0;
  static  unsigned long long aesl_llvm_cbe_829_count = 0;
  unsigned long long llvm_cbe_tmp__166;
  static  unsigned long long aesl_llvm_cbe_830_count = 0;
  unsigned int llvm_cbe_tmp__167;
  static  unsigned long long aesl_llvm_cbe_831_count = 0;
  static  unsigned long long aesl_llvm_cbe_832_count = 0;
  static  unsigned long long aesl_llvm_cbe_833_count = 0;
  static  unsigned long long aesl_llvm_cbe_834_count = 0;
  static  unsigned long long aesl_llvm_cbe_835_count = 0;
  static  unsigned long long aesl_llvm_cbe_836_count = 0;
  static  unsigned long long aesl_llvm_cbe_837_count = 0;
  static  unsigned long long aesl_llvm_cbe_838_count = 0;
  unsigned int llvm_cbe_tmp__168;
  static  unsigned long long aesl_llvm_cbe_839_count = 0;
  static  unsigned long long aesl_llvm_cbe_840_count = 0;
  static  unsigned long long aesl_llvm_cbe_841_count = 0;
  static  unsigned long long aesl_llvm_cbe_842_count = 0;
  static  unsigned long long aesl_llvm_cbe_843_count = 0;
  static  unsigned long long aesl_llvm_cbe_844_count = 0;
  static  unsigned long long aesl_llvm_cbe_845_count = 0;
  static  unsigned long long aesl_llvm_cbe_846_count = 0;
  static  unsigned long long aesl_llvm_cbe_847_count = 0;
  static  unsigned long long aesl_llvm_cbe_848_count = 0;
  static  unsigned long long aesl_llvm_cbe_849_count = 0;
  static  unsigned long long aesl_llvm_cbe_850_count = 0;
  static  unsigned long long aesl_llvm_cbe_851_count = 0;
  static  unsigned long long aesl_llvm_cbe_852_count = 0;
  static  unsigned long long aesl_llvm_cbe_853_count = 0;
  static  unsigned long long aesl_llvm_cbe_854_count = 0;
  static  unsigned long long aesl_llvm_cbe_855_count = 0;
  unsigned int llvm_cbe_tmp__169;
  static  unsigned long long aesl_llvm_cbe_856_count = 0;
  unsigned long long llvm_cbe_tmp__170;
  static  unsigned long long aesl_llvm_cbe_857_count = 0;
  static  unsigned long long aesl_llvm_cbe_858_count = 0;
  unsigned long long llvm_cbe_tmp__171;
  static  unsigned long long aesl_llvm_cbe_859_count = 0;
  static  unsigned long long aesl_llvm_cbe_860_count = 0;
  static  unsigned long long aesl_llvm_cbe_861_count = 0;
  static  unsigned long long aesl_llvm_cbe_862_count = 0;
  static  unsigned long long aesl_llvm_cbe_863_count = 0;
  static  unsigned long long aesl_llvm_cbe_864_count = 0;
  static  unsigned long long aesl_llvm_cbe_865_count = 0;
  static  unsigned long long aesl_llvm_cbe_866_count = 0;
  static  unsigned long long aesl_llvm_cbe_867_count = 0;
  unsigned int llvm_cbe_tmp__172;
  static  unsigned long long aesl_llvm_cbe_868_count = 0;
  unsigned long long llvm_cbe_tmp__173;
  static  unsigned long long aesl_llvm_cbe_869_count = 0;
  unsigned long long llvm_cbe_tmp__174;
  static  unsigned long long aesl_llvm_cbe_870_count = 0;
  static  unsigned long long aesl_llvm_cbe_871_count = 0;
  static  unsigned long long aesl_llvm_cbe_872_count = 0;
   char *llvm_cbe_tmp__175;
  static  unsigned long long aesl_llvm_cbe_873_count = 0;
  signed long long *llvm_cbe_tmp__176;
  static  unsigned long long aesl_llvm_cbe_874_count = 0;
  static  unsigned long long aesl_llvm_cbe_875_count = 0;
  unsigned int llvm_cbe_tmp__177;
  static  unsigned long long aesl_llvm_cbe_876_count = 0;
  static  unsigned long long aesl_llvm_cbe_877_count = 0;
  static  unsigned long long aesl_llvm_cbe_878_count = 0;
  static  unsigned long long aesl_llvm_cbe_879_count = 0;
  static  unsigned long long aesl_llvm_cbe_880_count = 0;
  static  unsigned long long aesl_llvm_cbe_881_count = 0;
  static  unsigned long long aesl_llvm_cbe_882_count = 0;
  static  unsigned long long aesl_llvm_cbe_883_count = 0;

const char* AESL_DEBUG_TRACE = getenv("DEBUG_TRACE");
if (AESL_DEBUG_TRACE)
printf("\n\{ BEGIN @blowfish_decrypt\n");
if (AESL_DEBUG_TRACE)
printf("\n  %%1 = sext i32 %%padsize to i64, !dbg !8 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_801_count);
  llvm_cbe_tmp__161 = (unsigned long long )((signed long long )(signed int )llvm_cbe_padsize);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__161);
if (AESL_DEBUG_TRACE)
printf("\n  %%2 = call i8* @malloc(i64 %%1), !dbg !8 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_802_count);
  llvm_cbe_tmp__162 = ( char *)( char *)malloc(llvm_cbe_tmp__161);
if (AESL_DEBUG_TRACE) {
printf("\nArgument  = 0x%I64X",llvm_cbe_tmp__161);
printf("\nReturn  = 0x%X",llvm_cbe_tmp__162);
}
  if (((llvm_cbe_padsize&4294967295U) == (0u&4294967295U))) {
    goto llvm_cbe__2e__crit_edge;
  } else {
    llvm_cbe_storemerge2__PHI_TEMPORARY = (unsigned int )0u;   /* for PHI node */
    goto llvm_cbe__2e_lr_2e_ph;
  }

  do {     /* Syntactic loop '.lr.ph' to make GCC happy */
llvm_cbe__2e_lr_2e_ph:
if (AESL_DEBUG_TRACE)
printf("\n  %%storemerge2 = phi i32 [ %%18, %%.lr.ph ], [ 0, %%0  for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_storemerge2_count);
  llvm_cbe_storemerge2 = (unsigned int )llvm_cbe_storemerge2__PHI_TEMPORARY;
if (AESL_DEBUG_TRACE) {
printf("\nstoremerge2 = 0x%X",llvm_cbe_storemerge2);
printf("\n = 0x%X",llvm_cbe_tmp__177);
printf("\n = 0x%X",0u);
}
if (AESL_DEBUG_TRACE)
printf("\n  %%4 = zext i32 %%storemerge2 to i64, !dbg !7 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_820_count);
  llvm_cbe_tmp__163 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_storemerge2&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__163);
if (AESL_DEBUG_TRACE)
printf("\n  %%5 = getelementptr inbounds i8* %%crypt_data, i64 %%4, !dbg !7 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_821_count);
  llvm_cbe_tmp__164 = ( char *)(&llvm_cbe_crypt_data[(((signed long long )llvm_cbe_tmp__163))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__163));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%6 = bitcast i8* %%5 to i64*, !dbg !7 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_822_count);
  llvm_cbe_tmp__165 = (signed long long *)((signed long long *)llvm_cbe_tmp__164);
if (AESL_DEBUG_TRACE)
printf("\n  %%srcval1 = load i64* %%6, align 1, !dbg !7 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_srcval1_count);
  llvm_cbe_srcval1 = (unsigned long long )*llvm_cbe_tmp__165;
if (AESL_DEBUG_TRACE)
printf("\nsrcval1 = 0x%I64X\n", llvm_cbe_srcval1);
if (AESL_DEBUG_TRACE)
printf("\n  %%7 = lshr i64 %%srcval1, 32, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_829_count);
  llvm_cbe_tmp__166 = (unsigned long long )((unsigned long long )(((unsigned long long )(llvm_cbe_srcval1&18446744073709551615ull)) >> ((unsigned long long )(32ull&18446744073709551615ull))));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", ((unsigned long long )(llvm_cbe_tmp__166&18446744073709551615ull)));
if (AESL_DEBUG_TRACE)
printf("\n  %%8 = trunc i64 %%7 to i32, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_830_count);
  llvm_cbe_tmp__167 = (unsigned int )((unsigned int )llvm_cbe_tmp__166&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__167);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%8, i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_837_count);
  *(&llvm_cbe_left) = llvm_cbe_tmp__167;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__167);
if (AESL_DEBUG_TRACE)
printf("\n  %%9 = trunc i64 %%srcval1 to i32, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_838_count);
  llvm_cbe_tmp__168 = (unsigned int )((unsigned int )llvm_cbe_srcval1&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__168);
if (AESL_DEBUG_TRACE)
printf("\n  store i32 %%9, i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_845_count);
  *(&llvm_cbe_right) = llvm_cbe_tmp__168;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__168);
if (AESL_DEBUG_TRACE)
printf("\n  call void @_decrypt(i32* %%left, i32* %%right), !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_846_count);
  _decrypt((signed int *)(&llvm_cbe_left), (signed int *)(&llvm_cbe_right));
if (AESL_DEBUG_TRACE) {
}
if (AESL_DEBUG_TRACE)
printf("\n  %%10 = load i32* %%left, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_855_count);
  llvm_cbe_tmp__169 = (unsigned int )*(&llvm_cbe_left);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__169);
if (AESL_DEBUG_TRACE)
printf("\n  %%11 = zext i32 %%10 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_856_count);
  llvm_cbe_tmp__170 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_tmp__169&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__170);
if (AESL_DEBUG_TRACE)
printf("\n  %%12 = shl nuw i64 %%11, 32, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_858_count);
  llvm_cbe_tmp__171 = (unsigned long long )llvm_cbe_tmp__170 << 32ull;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__171);
if (AESL_DEBUG_TRACE)
printf("\n  %%13 = load i32* %%right, align 4, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_867_count);
  llvm_cbe_tmp__172 = (unsigned int )*(&llvm_cbe_right);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", llvm_cbe_tmp__172);
if (AESL_DEBUG_TRACE)
printf("\n  %%14 = zext i32 %%13 to i64, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_868_count);
  llvm_cbe_tmp__173 = (unsigned long long )((unsigned long long )(unsigned int )llvm_cbe_tmp__172&4294967295U);
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__173);
if (AESL_DEBUG_TRACE)
printf("\n  %%15 = or i64 %%12, %%14, !dbg !10 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_869_count);
  llvm_cbe_tmp__174 = (unsigned long long )llvm_cbe_tmp__171 | llvm_cbe_tmp__173;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__174);
if (AESL_DEBUG_TRACE)
printf("\n  %%16 = getelementptr inbounds i8* %%2, i64 %%4, !dbg !8 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_872_count);
  llvm_cbe_tmp__175 = ( char *)(&llvm_cbe_tmp__162[(((signed long long )llvm_cbe_tmp__163))]);
if (AESL_DEBUG_TRACE) {
printf("\n = 0x%I64X",((signed long long )llvm_cbe_tmp__163));
}
if (AESL_DEBUG_TRACE)
printf("\n  %%17 = bitcast i8* %%16 to i64*, !dbg !8 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_873_count);
  llvm_cbe_tmp__176 = (signed long long *)((signed long long *)llvm_cbe_tmp__175);
if (AESL_DEBUG_TRACE)
printf("\n  store i64 %%15, i64* %%17, align 1, !dbg !8 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_874_count);
  *llvm_cbe_tmp__176 = llvm_cbe_tmp__174;
if (AESL_DEBUG_TRACE)
printf("\n = 0x%I64X\n", llvm_cbe_tmp__174);
if (AESL_DEBUG_TRACE)
printf("\n  %%18 = add i32 %%storemerge2, 8, !dbg !9 for 0x%I64xth hint within @blowfish_decrypt  --> \n", ++aesl_llvm_cbe_875_count);
  llvm_cbe_tmp__177 = (unsigned int )((unsigned int )(llvm_cbe_storemerge2&4294967295ull)) + ((unsigned int )(8u&4294967295ull));
if (AESL_DEBUG_TRACE)
printf("\n = 0x%X\n", ((unsigned int )(llvm_cbe_tmp__177&4294967295ull)));
  if ((((unsigned int )llvm_cbe_tmp__177&4294967295U) < ((unsigned int )llvm_cbe_padsize&4294967295U))) {
    llvm_cbe_storemerge2__PHI_TEMPORARY = (unsigned int )llvm_cbe_tmp__177;   /* for PHI node */
    goto llvm_cbe__2e_lr_2e_ph;
  } else {
    goto llvm_cbe__2e__crit_edge;
  }

  } while (1); /* end of syntactic loop '.lr.ph' */
llvm_cbe__2e__crit_edge:
  if (AESL_DEBUG_TRACE)
      printf("\nEND @blowfish_decrypt}\n");
  return llvm_cbe_tmp__162;
}

