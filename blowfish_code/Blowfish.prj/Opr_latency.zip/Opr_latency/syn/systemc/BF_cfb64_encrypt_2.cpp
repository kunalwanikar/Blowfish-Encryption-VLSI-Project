#include "BF_cfb64_encrypt.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void BF_cfb64_encrypt::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_return_preg = ap_const_lv32_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
             esl_seteq<1,1,1>(icmp_ln103_fu_851_p2.read(), ap_const_lv1_1))) {
            ap_return_preg = num_write_assign_reg_786.read();
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        l_0_reg_796 = sext_ln119_fu_835_p1.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state55.read())) {
        l_0_reg_796 = l_reg_5085.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        num_write_assign_reg_786 = num_read.read();
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state55.read())) {
        num_write_assign_reg_786 = zext_ln124_reg_6423.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
         esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
        p_01_rec_reg_805 = ap_const_lv32_0;
    } else if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state55.read())) {
        p_01_rec_reg_805 = add_ln122_reg_5093.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read())) {
        reg_822 = ivec_q1.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) || 
                esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()))) {
        reg_822 = ivec_q0.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read())) {
        add_ln100_3_reg_5477 = add_ln100_3_fu_1995_p2.read();
        add_ln100_8_reg_5482 = add_ln100_8_fu_2001_p2.read();
        add_ln100_9_reg_5487 = add_ln100_9_fu_2007_p2.read();
        xor_ln99_21_reg_5467 = xor_ln99_21_fu_1954_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state18.read())) {
        add_ln100_4_reg_5503 = add_ln100_4_fu_2081_p2.read();
        lshr_ln20_reg_5524 = r_12_fu_2122_p2.read().range(31, 24);
        r_12_reg_5509 = r_12_fu_2122_p2.read();
        trunc_ln100_28_reg_5497 = trunc_ln100_28_fu_2077_p1.read();
        trunc_ln101_1_reg_5534 = xor_ln100_19_fu_2128_p2.read().range(15, 8);
        trunc_ln101_s_reg_5529 = xor_ln100_20_fu_2134_p2.read().range(23, 16);
        xor_ln100_19_reg_5514 = xor_ln100_19_fu_2128_p2.read();
        xor_ln100_20_reg_5519 = xor_ln100_20_fu_2134_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state20.read())) {
        add_ln101_3_reg_5559 = add_ln101_3_fu_2231_p2.read();
        add_ln101_8_reg_5564 = add_ln101_8_fu_2237_p2.read();
        add_ln101_9_reg_5569 = add_ln101_9_fu_2243_p2.read();
        xor_ln100_21_reg_5549 = xor_ln100_21_fu_2190_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state21.read())) {
        add_ln101_4_reg_5585 = add_ln101_4_fu_2317_p2.read();
        l_13_reg_5591 = l_13_fu_2358_p2.read();
        lshr_ln21_reg_5606 = l_13_fu_2358_p2.read().range(31, 24);
        trunc_ln101_28_reg_5579 = trunc_ln101_28_fu_2313_p1.read();
        trunc_ln102_1_reg_5616 = xor_ln101_19_fu_2364_p2.read().range(15, 8);
        trunc_ln102_s_reg_5611 = xor_ln101_20_fu_2370_p2.read().range(23, 16);
        xor_ln101_19_reg_5596 = xor_ln101_19_fu_2364_p2.read();
        xor_ln101_20_reg_5601 = xor_ln101_20_fu_2370_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state23.read())) {
        add_ln102_3_reg_5641 = add_ln102_3_fu_2467_p2.read();
        add_ln102_8_reg_5646 = add_ln102_8_fu_2473_p2.read();
        add_ln102_9_reg_5651 = add_ln102_9_fu_2479_p2.read();
        xor_ln101_21_reg_5631 = xor_ln101_21_fu_2426_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state26.read())) {
        add_ln103_10_reg_5727 = add_ln103_10_fu_2759_p2.read();
        add_ln103_4_reg_5717 = add_ln103_4_fu_2747_p2.read();
        add_ln103_9_reg_5722 = add_ln103_9_fu_2753_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state27.read())) {
        add_ln103_5_reg_5737 = add_ln103_5_fu_2832_p2.read();
        l_14_reg_5742 = l_14_fu_2878_p2.read();
        lshr_ln23_reg_5763 = l_14_fu_2878_p2.read().range(31, 24);
        trunc_ln104_1_reg_5773 = xor_ln103_19_fu_2884_p2.read().range(15, 8);
        trunc_ln104_s_reg_5768 = xor_ln103_20_fu_2890_p2.read().range(23, 16);
        xor_ln103_19_reg_5747 = xor_ln103_19_fu_2884_p2.read();
        xor_ln103_20_reg_5752 = xor_ln103_20_fu_2890_p2.read();
        xor_ln103_21_reg_5757 = xor_ln103_21_fu_2896_p2.read();
        xor_ln117_7_reg_5778 = xor_ln117_7_fu_2961_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state29.read())) {
        add_ln104_3_reg_5798 = add_ln104_3_fu_3019_p2.read();
        add_ln104_8_reg_5803 = add_ln104_8_fu_3025_p2.read();
        add_ln104_9_reg_5808 = add_ln104_9_fu_3031_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state30.read())) {
        add_ln104_4_reg_5824 = add_ln104_4_fu_3104_p2.read();
        lshr_ln24_reg_5845 = r_14_fu_3145_p2.read().range(31, 24);
        r_14_reg_5830 = r_14_fu_3145_p2.read();
        trunc_ln104_28_reg_5818 = trunc_ln104_28_fu_3100_p1.read();
        trunc_ln105_1_reg_5855 = xor_ln104_19_fu_3151_p2.read().range(15, 8);
        trunc_ln105_s_reg_5850 = xor_ln104_20_fu_3157_p2.read().range(23, 16);
        xor_ln104_19_reg_5835 = xor_ln104_19_fu_3151_p2.read();
        xor_ln104_20_reg_5840 = xor_ln104_20_fu_3157_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read())) {
        add_ln105_3_reg_5880 = add_ln105_3_fu_3254_p2.read();
        add_ln105_8_reg_5885 = add_ln105_8_fu_3260_p2.read();
        add_ln105_9_reg_5890 = add_ln105_9_fu_3266_p2.read();
        xor_ln104_21_reg_5870 = xor_ln104_21_fu_3213_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state33.read())) {
        add_ln105_4_reg_5906 = add_ln105_4_fu_3340_p2.read();
        l_15_reg_5912 = l_15_fu_3381_p2.read();
        lshr_ln25_reg_5927 = l_15_fu_3381_p2.read().range(31, 24);
        trunc_ln105_28_reg_5900 = trunc_ln105_28_fu_3336_p1.read();
        trunc_ln106_1_reg_5937 = xor_ln105_19_fu_3387_p2.read().range(15, 8);
        trunc_ln106_s_reg_5932 = xor_ln105_20_fu_3393_p2.read().range(23, 16);
        xor_ln105_19_reg_5917 = xor_ln105_19_fu_3387_p2.read();
        xor_ln105_20_reg_5922 = xor_ln105_20_fu_3393_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state35.read())) {
        add_ln106_3_reg_5962 = add_ln106_3_fu_3490_p2.read();
        add_ln106_8_reg_5967 = add_ln106_8_fu_3496_p2.read();
        add_ln106_9_reg_5972 = add_ln106_9_fu_3502_p2.read();
        xor_ln105_21_reg_5952 = xor_ln105_21_fu_3449_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state36.read())) {
        add_ln106_4_reg_5988 = add_ln106_4_fu_3576_p2.read();
        lshr_ln26_reg_6009 = r_15_fu_3617_p2.read().range(31, 24);
        r_15_reg_5994 = r_15_fu_3617_p2.read();
        trunc_ln106_28_reg_5982 = trunc_ln106_28_fu_3572_p1.read();
        trunc_ln107_1_reg_6019 = xor_ln106_19_fu_3623_p2.read().range(15, 8);
        trunc_ln107_s_reg_6014 = xor_ln106_20_fu_3629_p2.read().range(23, 16);
        xor_ln106_19_reg_5999 = xor_ln106_19_fu_3623_p2.read();
        xor_ln106_20_reg_6004 = xor_ln106_20_fu_3629_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state38.read())) {
        add_ln107_3_reg_6044 = add_ln107_3_fu_3726_p2.read();
        add_ln107_8_reg_6049 = add_ln107_8_fu_3732_p2.read();
        add_ln107_9_reg_6054 = add_ln107_9_fu_3738_p2.read();
        xor_ln106_21_reg_6034 = xor_ln106_21_fu_3685_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state39.read())) {
        add_ln107_4_reg_6070 = add_ln107_4_fu_3812_p2.read();
        l_16_reg_6076 = l_16_fu_3853_p2.read();
        lshr_ln27_reg_6091 = l_16_fu_3853_p2.read().range(31, 24);
        trunc_ln107_28_reg_6064 = trunc_ln107_28_fu_3808_p1.read();
        trunc_ln108_1_reg_6101 = xor_ln107_19_fu_3859_p2.read().range(15, 8);
        trunc_ln108_s_reg_6096 = xor_ln107_20_fu_3865_p2.read().range(23, 16);
        xor_ln107_19_reg_6081 = xor_ln107_19_fu_3859_p2.read();
        xor_ln107_20_reg_6086 = xor_ln107_20_fu_3865_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state41.read())) {
        add_ln108_3_reg_6126 = add_ln108_3_fu_3962_p2.read();
        add_ln108_8_reg_6131 = add_ln108_8_fu_3968_p2.read();
        add_ln108_9_reg_6136 = add_ln108_9_fu_3974_p2.read();
        xor_ln107_21_reg_6116 = xor_ln107_21_fu_3921_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state42.read())) {
        add_ln108_4_reg_6152 = add_ln108_4_fu_4048_p2.read();
        lshr_ln28_reg_6173 = r_16_fu_4089_p2.read().range(31, 24);
        r_16_reg_6158 = r_16_fu_4089_p2.read();
        trunc_ln108_28_reg_6146 = trunc_ln108_28_fu_4044_p1.read();
        trunc_ln109_1_reg_6183 = xor_ln108_19_fu_4095_p2.read().range(15, 8);
        trunc_ln109_s_reg_6178 = xor_ln108_20_fu_4101_p2.read().range(23, 16);
        xor_ln108_19_reg_6163 = xor_ln108_19_fu_4095_p2.read();
        xor_ln108_20_reg_6168 = xor_ln108_20_fu_4101_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state44.read())) {
        add_ln109_3_reg_6208 = add_ln109_3_fu_4198_p2.read();
        add_ln109_8_reg_6213 = add_ln109_8_fu_4204_p2.read();
        add_ln109_9_reg_6218 = add_ln109_9_fu_4210_p2.read();
        xor_ln108_21_reg_6198 = xor_ln108_21_fu_4157_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state45.read())) {
        add_ln109_4_reg_6234 = add_ln109_4_fu_4284_p2.read();
        l_17_reg_6240 = l_17_fu_4325_p2.read();
        lshr_ln29_reg_6255 = l_17_fu_4325_p2.read().range(31, 24);
        trunc_ln109_28_reg_6228 = trunc_ln109_28_fu_4280_p1.read();
        trunc_ln110_1_reg_6265 = xor_ln109_19_fu_4331_p2.read().range(15, 8);
        trunc_ln110_s_reg_6260 = xor_ln109_20_fu_4337_p2.read().range(23, 16);
        xor_ln109_19_reg_6245 = xor_ln109_19_fu_4331_p2.read();
        xor_ln109_20_reg_6250 = xor_ln109_20_fu_4337_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read())) {
        add_ln110_3_reg_6285 = add_ln110_3_fu_4434_p2.read();
        add_ln110_8_reg_6290 = add_ln110_8_fu_4440_p2.read();
        add_ln110_9_reg_6295 = add_ln110_9_fu_4446_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state48.read())) {
        add_ln110_4_reg_6311 = add_ln110_4_fu_4520_p2.read();
        lshr_ln30_reg_6332 = r_17_fu_4561_p2.read().range(31, 24);
        r_17_reg_6317 = r_17_fu_4561_p2.read();
        trunc_ln110_28_reg_6305 = trunc_ln110_28_fu_4516_p1.read();
        trunc_ln111_5_reg_6337 = xor_ln110_20_fu_4573_p2.read().range(23, 16);
        trunc_ln111_s_reg_6342 = xor_ln110_19_fu_4567_p2.read().range(15, 8);
        xor_ln110_19_reg_6322 = xor_ln110_19_fu_4567_p2.read();
        xor_ln110_20_reg_6327 = xor_ln110_20_fu_4573_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state50.read())) {
        add_ln111_3_reg_6377 = add_ln111_3_fu_4774_p2.read();
        add_ln111_5_reg_6382 = add_ln111_5_fu_4780_p2.read();
        add_ln111_6_reg_6387 = add_ln111_6_fu_4786_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        add_ln122_reg_5093 = add_ln122_fu_857_p2.read();
        in_addr_reg_5075 =  (sc_lv<6>) (p_01_rec_cast_fu_839_p1.read());
        l_reg_5085 = l_fu_845_p2.read();
        out_addr_reg_5080 =  (sc_lv<6>) (p_01_rec_cast_fu_839_p1.read());
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read())) {
        add_ln96_10_reg_5175 = add_ln96_10_fu_1106_p2.read();
        add_ln96_11_reg_5180 = add_ln96_11_fu_1112_p2.read();
        add_ln96_2_reg_5164 = add_ln96_2_fu_1094_p2.read();
        add_ln96_4_reg_5169 = add_ln96_4_fu_1100_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state5.read())) {
        add_ln96_3_reg_5144 = add_ln96_3_fu_1019_p2.read();
        add_ln96_8_reg_5149 = add_ln96_8_fu_1025_p2.read();
        add_ln96_9_reg_5154 = add_ln96_9_fu_1031_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read())) {
        add_ln97_3_reg_5231 = add_ln97_3_fu_1287_p2.read();
        add_ln97_8_reg_5236 = add_ln97_8_fu_1293_p2.read();
        add_ln97_9_reg_5241 = add_ln97_9_fu_1299_p2.read();
        xor_ln96_21_reg_5221 = xor_ln96_21_fu_1246_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state9.read())) {
        add_ln97_4_reg_5257 = add_ln97_4_fu_1373_p2.read();
        l_11_reg_5263 = l_11_fu_1414_p2.read();
        lshr_ln17_reg_5278 = l_11_fu_1414_p2.read().range(31, 24);
        trunc_ln97_28_reg_5251 = trunc_ln97_28_fu_1369_p1.read();
        trunc_ln98_1_reg_5288 = xor_ln97_19_fu_1420_p2.read().range(15, 8);
        trunc_ln98_s_reg_5283 = xor_ln97_20_fu_1426_p2.read().range(23, 16);
        xor_ln97_19_reg_5268 = xor_ln97_19_fu_1420_p2.read();
        xor_ln97_20_reg_5273 = xor_ln97_20_fu_1426_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state11.read())) {
        add_ln98_3_reg_5313 = add_ln98_3_fu_1523_p2.read();
        add_ln98_8_reg_5318 = add_ln98_8_fu_1529_p2.read();
        add_ln98_9_reg_5323 = add_ln98_9_fu_1535_p2.read();
        xor_ln97_21_reg_5303 = xor_ln97_21_fu_1482_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state12.read())) {
        add_ln98_4_reg_5339 = add_ln98_4_fu_1609_p2.read();
        lshr_ln18_reg_5360 = r_11_fu_1650_p2.read().range(31, 24);
        r_11_reg_5345 = r_11_fu_1650_p2.read();
        trunc_ln98_28_reg_5333 = trunc_ln98_28_fu_1605_p1.read();
        trunc_ln99_1_reg_5370 = xor_ln98_19_fu_1656_p2.read().range(15, 8);
        trunc_ln99_s_reg_5365 = xor_ln98_20_fu_1662_p2.read().range(23, 16);
        xor_ln98_19_reg_5350 = xor_ln98_19_fu_1656_p2.read();
        xor_ln98_20_reg_5355 = xor_ln98_20_fu_1662_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state14.read())) {
        add_ln99_3_reg_5395 = add_ln99_3_fu_1759_p2.read();
        add_ln99_8_reg_5400 = add_ln99_8_fu_1765_p2.read();
        add_ln99_9_reg_5405 = add_ln99_9_fu_1771_p2.read();
        xor_ln98_21_reg_5385 = xor_ln98_21_fu_1718_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state15.read())) {
        add_ln99_4_reg_5421 = add_ln99_4_fu_1845_p2.read();
        l_12_reg_5427 = l_12_fu_1886_p2.read();
        lshr_ln19_reg_5442 = l_12_fu_1886_p2.read().range(31, 24);
        trunc_ln100_1_reg_5452 = xor_ln99_19_fu_1892_p2.read().range(15, 8);
        trunc_ln100_s_reg_5447 = xor_ln99_20_fu_1898_p2.read().range(23, 16);
        trunc_ln99_28_reg_5415 = trunc_ln99_28_fu_1841_p1.read();
        xor_ln99_19_reg_5432 = xor_ln99_19_fu_1892_p2.read();
        xor_ln99_20_reg_5437 = xor_ln99_20_fu_1898_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(icmp_ln103_fu_851_p2.read(), ap_const_lv1_0))) {
        icmp_ln106_reg_5098 = icmp_ln106_fu_863_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state53.read())) {
        ivec_addr14_reg_6417 =  (sc_lv<3>) (sext_ln121_fu_4994_p1.read());
        zext_ln124_reg_6423 = zext_ln124_fu_5009_p1.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read())) {
        l_10_reg_5102 = l_10_fu_911_p2.read();
        trunc_ln96_1_reg_5134 = xor_ln94_4_fu_917_p2.read().range(15, 8);
        xor_ln94_4_reg_5107 = xor_ln94_4_fu_917_p2.read();
        xor_ln94_5_reg_5112 = xor_ln94_5_fu_923_p2.read();
        xor_ln94_6_reg_5117 = xor_ln94_6_fu_929_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state24.read())) {
        lshr_ln22_reg_5682 = r_13_fu_2599_p2.read().range(31, 24);
        r_13_reg_5661 = r_13_fu_2599_p2.read();
        trunc_ln103_1_reg_5692 = xor_ln102_19_fu_2605_p2.read().range(15, 8);
        trunc_ln103_s_reg_5687 = xor_ln102_20_fu_2611_p2.read().range(23, 16);
        xor_ln102_19_reg_5666 = xor_ln102_19_fu_2605_p2.read();
        xor_ln102_20_reg_5671 = xor_ln102_20_fu_2611_p2.read();
        xor_ln102_21_reg_5676 = xor_ln102_21_fu_2617_p2.read();
        xor_ln115_8_reg_5697 = xor_ln115_8_fu_2689_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state7.read())) {
        r_10_reg_5191 = r_10_fu_1175_p2.read();
        trunc_ln96_31_reg_5185 = trunc_ln96_31_fu_1130_p1.read();
        trunc_ln97_1_reg_5216 = xor_ln96_19_fu_1181_p2.read().range(15, 8);
        xor_ln96_19_reg_5196 = xor_ln96_19_fu_1181_p2.read();
        xor_ln96_20_reg_5201 = xor_ln96_20_fu_1187_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state6.read()))) {
        reg_827 = ivec_q1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state5.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state11.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state14.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state17.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state20.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state23.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state26.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state29.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state32.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state35.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state38.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state41.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state44.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state47.read()) || esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state50.read()))) {
        reg_831 = grp_fu_816_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state49.read())) {
        trunc_ln115_2_reg_6362 = xor_ln112_1_fu_4651_p2.read().range(15, 8);
        xor_ln110_21_reg_6347 = xor_ln110_21_fu_4613_p2.read();
        xor_ln115_reg_6367 = xor_ln115_fu_4733_p2.read();
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state51.read())) {
        trunc_ln117_1_reg_6402 = xor_ln111_11_fu_4912_p2.read().range(23, 16);
        trunc_ln117_2_reg_6407 = xor_ln111_10_fu_4906_p2.read().range(15, 8);
        trunc_ln16_reg_6397 = l_19_fu_4900_p2.read().range(31, 24);
        xor_ln117_reg_6412 = xor_ln117_fu_4989_p2.read();
    }
}

void BF_cfb64_encrypt::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && esl_seteq<1,1,1>(ap_start.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(icmp_ln103_fu_851_p2.read(), ap_const_lv1_1))) {
                ap_NS_fsm = ap_ST_fsm_state1;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(icmp_ln103_fu_851_p2.read(), ap_const_lv1_0) && esl_seteq<1,1,1>(icmp_ln106_fu_863_p2.read(), ap_const_lv1_0))) {
                ap_NS_fsm = ap_ST_fsm_state53;
            } else {
                ap_NS_fsm = ap_ST_fsm_state3;
            }
            break;
        case 4 : 
            ap_NS_fsm = ap_ST_fsm_state4;
            break;
        case 8 : 
            ap_NS_fsm = ap_ST_fsm_state5;
            break;
        case 16 : 
            ap_NS_fsm = ap_ST_fsm_state6;
            break;
        case 32 : 
            ap_NS_fsm = ap_ST_fsm_state7;
            break;
        case 64 : 
            ap_NS_fsm = ap_ST_fsm_state8;
            break;
        case 128 : 
            ap_NS_fsm = ap_ST_fsm_state9;
            break;
        case 256 : 
            ap_NS_fsm = ap_ST_fsm_state10;
            break;
        case 512 : 
            ap_NS_fsm = ap_ST_fsm_state11;
            break;
        case 1024 : 
            ap_NS_fsm = ap_ST_fsm_state12;
            break;
        case 2048 : 
            ap_NS_fsm = ap_ST_fsm_state13;
            break;
        case 4096 : 
            ap_NS_fsm = ap_ST_fsm_state14;
            break;
        case 8192 : 
            ap_NS_fsm = ap_ST_fsm_state15;
            break;
        case 16384 : 
            ap_NS_fsm = ap_ST_fsm_state16;
            break;
        case 32768 : 
            ap_NS_fsm = ap_ST_fsm_state17;
            break;
        case 65536 : 
            ap_NS_fsm = ap_ST_fsm_state18;
            break;
        case 131072 : 
            ap_NS_fsm = ap_ST_fsm_state19;
            break;
        case 262144 : 
            ap_NS_fsm = ap_ST_fsm_state20;
            break;
        case 524288 : 
            ap_NS_fsm = ap_ST_fsm_state21;
            break;
        case 1048576 : 
            ap_NS_fsm = ap_ST_fsm_state22;
            break;
        case 2097152 : 
            ap_NS_fsm = ap_ST_fsm_state23;
            break;
        case 4194304 : 
            ap_NS_fsm = ap_ST_fsm_state24;
            break;
        case 8388608 : 
            ap_NS_fsm = ap_ST_fsm_state25;
            break;
        case 16777216 : 
            ap_NS_fsm = ap_ST_fsm_state26;
            break;
        case 33554432 : 
            ap_NS_fsm = ap_ST_fsm_state27;
            break;
        case 67108864 : 
            ap_NS_fsm = ap_ST_fsm_state28;
            break;
        case 134217728 : 
            ap_NS_fsm = ap_ST_fsm_state29;
            break;
        case 268435456 : 
            ap_NS_fsm = ap_ST_fsm_state30;
            break;
        case 536870912 : 
            ap_NS_fsm = ap_ST_fsm_state31;
            break;
        case 1073741824 : 
            ap_NS_fsm = ap_ST_fsm_state32;
            break;
        case 2147483648 : 
            ap_NS_fsm = ap_ST_fsm_state33;
            break;
        case 4294967296 : 
            ap_NS_fsm = ap_ST_fsm_state34;
            break;
        case 8589934592 : 
            ap_NS_fsm = ap_ST_fsm_state35;
            break;
        case 17179869184 : 
            ap_NS_fsm = ap_ST_fsm_state36;
            break;
        case 34359738368 : 
            ap_NS_fsm = ap_ST_fsm_state37;
            break;
        case 68719476736 : 
            ap_NS_fsm = ap_ST_fsm_state38;
            break;
        case 137438953472 : 
            ap_NS_fsm = ap_ST_fsm_state39;
            break;
        case 274877906944 : 
            ap_NS_fsm = ap_ST_fsm_state40;
            break;
        case 549755813888 : 
            ap_NS_fsm = ap_ST_fsm_state41;
            break;
        case 1099511627776 : 
            ap_NS_fsm = ap_ST_fsm_state42;
            break;
        case 2199023255552 : 
            ap_NS_fsm = ap_ST_fsm_state43;
            break;
        case 4398046511104 : 
            ap_NS_fsm = ap_ST_fsm_state44;
            break;
        case 8796093022208 : 
            ap_NS_fsm = ap_ST_fsm_state45;
            break;
        case 17592186044416 : 
            ap_NS_fsm = ap_ST_fsm_state46;
            break;
        case 35184372088832 : 
            ap_NS_fsm = ap_ST_fsm_state47;
            break;
        case 70368744177664 : 
            ap_NS_fsm = ap_ST_fsm_state48;
            break;
        case 140737488355328 : 
            ap_NS_fsm = ap_ST_fsm_state49;
            break;
        case 281474976710656 : 
            ap_NS_fsm = ap_ST_fsm_state50;
            break;
        case 562949953421312 : 
            ap_NS_fsm = ap_ST_fsm_state51;
            break;
        case 1125899906842624 : 
            ap_NS_fsm = ap_ST_fsm_state52;
            break;
        case 2251799813685248 : 
            ap_NS_fsm = ap_ST_fsm_state53;
            break;
        case 4503599627370496 : 
            ap_NS_fsm = ap_ST_fsm_state54;
            break;
        case 9007199254740992 : 
            ap_NS_fsm = ap_ST_fsm_state55;
            break;
        case 18014398509481984 : 
            ap_NS_fsm = ap_ST_fsm_state2;
            break;
        default : 
            ap_NS_fsm =  (sc_lv<55>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
            break;
    }
}

}

